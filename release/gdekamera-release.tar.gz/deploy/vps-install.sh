#!/usr/bin/env bash
set -Eeuo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "Запустите установщик от имени root." >&2
  exit 1
fi

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APP_ROOT="/var/www/gdekamera"
RELEASE_ID="$(date -u +%Y%m%d-%H%M%S)"
RELEASE_DIR="$APP_ROOT/releases/$RELEASE_ID"
CURRENT_LINK="$APP_ROOT/current"
BACKUP_ROOT="/root/gdekamera-backups/$RELEASE_ID"
DOMAIN="xn--80aahefb7ar1b.xn--p1ai"
WWW_DOMAIN="www.xn--80aahefb7ar1b.xn--p1ai"
NGINX_CONFIG="/etc/nginx/sites-available/gdekamera"
NGINX_ENABLED="/etc/nginx/sites-enabled/gdekamera"
NGINX_APP_SNIPPET="/etc/nginx/snippets/gdekamera-app.conf"
SERVICE_FILE="/etc/systemd/system/gdekamera.service"

echo "[1/7] Подготовка системных пакетов"
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq curl ca-certificates gnupg nginx certbot python3-certbot-nginx

NODE_MAJOR="$(node -p 'Number(process.versions.node.split(".")[0])' 2>/dev/null || echo 0)"
if [ "$NODE_MAJOR" -lt 22 ]; then
  echo "Установка Node.js 24"
  curl -fsSL https://deb.nodesource.com/setup_24.x -o /tmp/gdekamera-nodesource.sh
  bash /tmp/gdekamera-nodesource.sh
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq nodejs
fi

echo "[2/7] Создание новой версии"
mkdir -p "$RELEASE_DIR" "$BACKUP_ROOT"
cp -a "$SOURCE_DIR/." "$RELEASE_DIR/"
rm -rf "$RELEASE_DIR/node_modules" "$RELEASE_DIR/dist" "$RELEASE_DIR/.git" "$RELEASE_DIR/.sites-runtime"

echo "[3/7] Установка зависимостей и сборка"
cd "$RELEASE_DIR"
npm ci
npm run build

PREVIOUS_RELEASE=""
if [ -L "$CURRENT_LINK" ]; then
  PREVIOUS_RELEASE="$(readlink -f "$CURRENT_LINK")"
elif [ -e "$CURRENT_LINK" ]; then
  mv "$CURRENT_LINK" "$BACKUP_ROOT/current-before-symlink"
fi

echo "[4/7] Настройка службы сайта"
if [ -f "$SERVICE_FILE" ]; then cp -a "$SERVICE_FILE" "$BACKUP_ROOT/gdekamera.service"; fi
ln -sfn "$RELEASE_DIR" "$CURRENT_LINK"
install -m 0644 /dev/null "$SERVICE_FILE"
cat > "$SERVICE_FILE" <<'UNIT'
[Unit]
Description=Где камера — веб-сайт
After=network.target

[Service]
Type=simple
WorkingDirectory=/var/www/gdekamera/current
Environment=NODE_ENV=production
Environment=PORT=3000
Environment=FEEDBACK_STORAGE_DIR=/var/lib/gdekamera/feedback
EnvironmentFile=-/etc/gdekamera-feedback.env
ExecStart=/usr/bin/npm run start -- --hostname 127.0.0.1 --port 3000
Restart=always
RestartSec=4
User=www-data
Group=www-data

[Install]
WantedBy=multi-user.target
UNIT
install -d -o www-data -g www-data -m 0750 /var/lib/gdekamera/feedback /var/lib/gdekamera/feedback/files
if [ ! -e /etc/gdekamera-feedback.env ]; then
  install -m 0600 /dev/null /etc/gdekamera-feedback.env
fi
if ! grep -q '^ADMIN_FEEDBACK_TOKEN=' /etc/gdekamera-feedback.env; then
  ADMIN_FEEDBACK_TOKEN="$(od -An -N24 -tx1 /dev/urandom | tr -d ' \n')"
  printf 'ADMIN_FEEDBACK_TOKEN=%s\n' "$ADMIN_FEEDBACK_TOKEN" >> /etc/gdekamera-feedback.env
fi
chown -R www-data:www-data "$RELEASE_DIR"
systemctl daemon-reload
systemctl enable gdekamera.service >/dev/null
systemctl restart gdekamera.service

echo "[5/7] Проверка приложения"
APP_OK=0
for _ in $(seq 1 30); do
  if curl -fsS --max-time 3 http://127.0.0.1:3000/ >/dev/null; then APP_OK=1; break; fi
  sleep 1
done
if [ "$APP_OK" -ne 1 ]; then
  echo "Новая версия не запустилась. Выполняется откат." >&2
  if [ -n "$PREVIOUS_RELEASE" ]; then
    ln -sfn "$PREVIOUS_RELEASE" "$CURRENT_LINK"
    systemctl restart gdekamera.service || true
  fi
  journalctl -u gdekamera.service -n 80 --no-pager >&2 || true
  exit 1
fi

echo "[6/7] Настройка Nginx"
if [ -f "$NGINX_CONFIG" ]; then cp -a "$NGINX_CONFIG" "$BACKUP_ROOT/nginx-gdekamera.conf"; fi
cat > "$NGINX_APP_SNIPPET" <<'NGINX_APP'
    client_max_body_size 12m;
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/json application/javascript application/xml application/xml+rss application/rss+xml font/ttf font/otf application/vnd.ms-fontobject image/svg+xml;
    etag on;

    location ~ ^/(?:official-regions|official-mobile|weight-control)/.*\.json$ {
        root /var/www/gdekamera/current/dist/client;
        try_files $uri =404;
        expires 1h;
        add_header Cache-Control "public, max-age=3600, stale-while-revalidate=86400" always;
        access_log off;
    }

    location ^~ /assets/ {
        root /var/www/gdekamera/current/dist/client;
        try_files $uri =404;
        expires 365d;
        add_header Cache-Control "public, max-age=31536000, immutable" always;
        access_log off;
    }

    location ~* \.(?:jpg|jpeg|png|webp|gif|ico|svg|woff|woff2|json)$ {
        root /var/www/gdekamera/current/dist/client;
        try_files $uri =404;
        expires 7d;
        add_header Cache-Control "public, max-age=604800" always;
        access_log off;
    }

    location ~ ^/(?:sitemap\.xml|robots\.txt|site\.webmanifest|camera-search-index\.json)$ {
        root /var/www/gdekamera/current/dist/client;
        try_files $uri =404;
        expires 1h;
        add_header Cache-Control "public, max-age=3600" always;
        access_log off;
    }

    location = /moskovskaya-oblast { return 301 https://xn--80aahefb7ar1b.xn--p1ai/region/50; }
    location = /penzenskaya-oblast { return 301 https://xn--80aahefb7ar1b.xn--p1ai/region/58; }

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host xn--80aahefb7ar1b.xn--p1ai;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_read_timeout 90s;
    }
NGINX_APP

if [ -e "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" ]; then
cat > "$NGINX_CONFIG" <<NGINX
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN $WWW_DOMAIN;
    return 301 https://$DOMAIN\$request_uri;
}

server {
    listen 443 ssl;
    listen [::]:443 ssl;
    server_name $WWW_DOMAIN;
    ssl_certificate /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;
    return 301 https://$DOMAIN\$request_uri;
}

server {
    listen 443 ssl;
    listen [::]:443 ssl;
    server_name $DOMAIN;
    ssl_certificate /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;
    include /etc/letsencrypt/options-ssl-nginx.conf;
    ssl_dhparam /etc/letsencrypt/ssl-dhparams.pem;
    include $NGINX_APP_SNIPPET;
}
NGINX
else
cat > "$NGINX_CONFIG" <<NGINX
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN $WWW_DOMAIN;
    include $NGINX_APP_SNIPPET;
}
NGINX
fi
ln -sfn "$NGINX_CONFIG" "$NGINX_ENABLED"

if ! nginx -t; then
  echo "Ошибка конфигурации Nginx. Восстанавливается прежняя конфигурация." >&2
  if [ -f "$BACKUP_ROOT/nginx-gdekamera.conf" ]; then
    cp -a "$BACKUP_ROOT/nginx-gdekamera.conf" "$NGINX_CONFIG"
  else
    unlink "$NGINX_ENABLED" 2>/dev/null || true
    rm -f "$NGINX_CONFIG"
  fi
  nginx -t || true
  exit 1
fi
systemctl enable nginx >/dev/null
systemctl reload nginx

echo "[7/7] Итоговая проверка"
curl -fsS --max-time 5 -H "Host: $DOMAIN" http://127.0.0.1/ >/dev/null
echo
echo "Готово: новая версия сайта запущена."
echo "HTTP: http://гдекамера.рф"
echo "Резервные копии: $BACKUP_ROOT"
echo "Новая версия: $RELEASE_DIR"
echo
if [ ! -e "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" ]; then
  echo "Для HTTPS выполните после проверки сайта:"
  echo "certbot --nginx -d $DOMAIN -d $WWW_DOMAIN"
else
  echo "HTTPS подключён. HTTP и www перенаправляются на основной домен кодом 301."
fi
