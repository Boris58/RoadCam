import { mkdir, readFile, readdir, writeFile } from "node:fs/promises";
import { join } from "node:path";

const publicDir = new URL("../public/", import.meta.url);
const summary = JSON.parse(await readFile(new URL("official-regions-summary.json", publicDir), "utf8"));
const entries = [];
for (const filename of await readdir(new URL("official-regions/", publicDir))) {
  if (!filename.endsWith(".json")) continue;
  const data = JSON.parse(await readFile(new URL(`official-regions/${filename}`, publicDir), "utf8"));
  for (const camera of data.cameras ?? []) entries.push({ c: data.code, r: data.name, i: camera.id, a: camera.address, x: camera.lat, y: camera.lng, v: camera.violations?.slice(0, 4) ?? [] });
}
for (const [code, filename, name] of [["50", "cameras-moscow-oblast.json", "Московская область"], ["58", "cameras-penza.json", "Пензенская область"]]) {
  const cameras = JSON.parse(await readFile(new URL(filename, publicDir), "utf8"));
  for (const camera of cameras) entries.push({ c: code, r: summary[code]?.name ?? name, i: camera.id, a: camera.address, x: camera.lat, y: camera.lng, v: camera.violations?.slice(0, 4) ?? [] });
}
for (const filename of await readdir(new URL("weight-control/", publicDir))) {
  if (!filename.endsWith(".json")) continue;
  const data = JSON.parse(await readFile(new URL(`weight-control/${filename}`, publicDir), "utf8"));
  for (const camera of data.cameras ?? []) entries.push({ c: data.regionCode, r: data.regionName, i: camera.id, a: camera.address, x: camera.lat, y: camera.lng, v: camera.violations?.slice(0, 4) ?? [] });
}
await mkdir(publicDir, { recursive: true });
await writeFile(join(publicDir.pathname, "camera-search-index.json"), JSON.stringify(entries));
console.log(`Generated camera-search-index.json with ${entries.length} cameras`);
