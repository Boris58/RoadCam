#!/usr/bin/env node

import { readFile, writeFile, mkdir } from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";
import XLSX from "xlsx";

const args = parseArgs(process.argv.slice(2));
if (!args.input || !args.date) {
  console.error("Пример: npm run cameras:update-penza -- --input private-data/24.09.2026_Stacionarnye.xlsx --date 2026-09-24");
  process.exit(1);
}

const projectDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const inputPath = path.resolve(args.input);
const camerasPath = path.resolve(args.public ?? path.join(projectDir, "public/cameras-penza.json"));
const reportPath = path.resolve(args.report ?? path.join(projectDir, "data/imports/58/update-report.json"));
const outputPath = path.resolve(args.output ?? camerasPath.replace(/\.json$/i, ".candidate.json"));
const sourceUrl = args.source ?? "https://xn--80aebkobnwfcnsfk1e0h.xn--p1ai/r/58";
const sourceName = "Официальный перечень Госавтоинспекции Пензенской области";

const official = readOfficialWorkbook(inputPath);
if (official.length < 1 || official.some((item) => !validPoint(item))) {
  throw new Error(`Файл содержит некорректные строки. Распознано: ${official.length}.`);
}

const all = JSON.parse(await readFile(camerasPath, "utf8"));
const stationary = all.filter((camera) => !camera.cameraType || camera.cameraType === "stationary");
const other = all.filter((camera) => camera.cameraType && camera.cameraType !== "stationary");
const { matched, unmatchedOld, unmatchedNew } = matchCameras(stationary, official);

if (matched.length < Math.min(stationary.length, official.length) * 0.75) {
  throw new Error(`Сопоставлено только ${matched.length} из ${stationary.length} прежних и ${official.length} новых точек. Автоматическое обновление остановлено.`);
}

const usedIds = new Set(all.map((camera) => camera.id));
let nextId = 580000;
const allocateId = () => { while (usedIds.has(nextId)) nextId += 1; usedIds.add(nextId); return nextId++; };
const updated = matched.map(({ oldIndex, newIndex }) => mergeOfficial(stationary[oldIndex], official[newIndex]));
const added = unmatchedNew.map((newIndex) => mergeOfficial({ id: allocateId() }, official[newIndex]));
const retained = unmatchedOld.map((oldIndex) => ({
  ...stationary[oldIndex],
  cameraType: "stationary",
  sourceKind: "official-previous",
  sourceName: "Ранее присутствовала в официальном перечне; в актуальном перечне отсутствует",
  sourceUrl,
  verification: "official",
}));

const result = [...updated, ...added, ...retained, ...other].sort((left, right) => left.id - right.id);
const changes = matched.flatMap(({ oldIndex, newIndex, meters }) => describeChanges(stationary[oldIndex], official[newIndex], meters));
const warnings = validateIncoming(official);
const report = {
  regionCode: "58",
  sourceDate: args.date,
  sourceName,
  sourceUrl,
  generatedAt: new Date().toISOString(),
  applied: Boolean(args.apply),
  totals: {
    incoming: official.length,
    previousStationary: stationary.length,
    matched: matched.length,
    added: added.length,
    changed: changes.length,
    absentFromLatestRetained: retained.length,
    outputTotal: result.length,
  },
  added: added.map(summary),
  changed: changes,
  absentFromLatestRetained: retained.map(summary),
  warnings,
};

await mkdir(path.dirname(reportPath), { recursive: true });
await writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`, "utf8");
if (!args.apply || args.output) await writeFile(outputPath, `${JSON.stringify(result, null, 2)}\n`, "utf8");
if (args.apply) await writeFile(camerasPath, `${JSON.stringify(result, null, 2)}\n`, "utf8");
console.log(JSON.stringify({ ...report.totals, warnings: warnings.length, report: reportPath, output: args.apply ? camerasPath : outputPath, applied: Boolean(args.apply) }, null, 2));

function readOfficialWorkbook(filePath) {
  const workbook = XLSX.readFile(filePath, { raw: false });
  const rows = workbook.SheetNames.flatMap((name) => XLSX.utils.sheet_to_json(workbook.Sheets[name], { header: 1, defval: "", raw: false }));
  const start = rows.findIndex((row) => row.some((cell) => /адрес места установки/i.test(String(cell))));
  if (start < 0) throw new Error("Не найден заголовок «Адрес места установки». Структура файла изменилась.");
  return rows.slice(start + 2).filter((row) => String(row[0] ?? "").trim()).map((row, index) => ({
    listNumber: index + 1,
    address: String(row[0]).trim(),
    lat: number(row[1]),
    lng: number(row[2]),
    schedule: String(row[3] ?? "").trim(),
    rawViolations: String(row[4] ?? "").trim(),
  }));
}

function mergeOfficial(previous, next) {
  return {
    ...previous,
    address: next.address,
    lat: next.lat,
    lng: next.lng,
    violations: [next.rawViolations],
    schedule: next.schedule,
    cameraType: "stationary",
    sourceKind: "official-current",
    sourceDate: args.date,
    sourceName,
    sourceUrl,
    verification: "official",
  };
}

function matchCameras(oldItems, newItems) {
  const candidates = [];
  for (let oldIndex = 0; oldIndex < oldItems.length; oldIndex += 1) {
    for (let newIndex = 0; newIndex < newItems.length; newIndex += 1) {
      const old = oldItems[oldIndex], next = newItems[newIndex], meters = distance(old, next);
      const exactAddress = normalize(old.address) === normalize(next.address), textScore = similarity(old.address, next.address);
      if (exactAddress || meters < 120 || textScore > 0.72) {
        candidates.push({ oldIndex, newIndex, meters, score: (exactAddress ? 1000 : 0) + (meters < 3 ? 500 : 0) + (meters < 30 ? 300 : 0) + (meters < 120 ? 100 : 0) + textScore * 100 - meters / 100 });
      }
    }
  }
  candidates.sort((left, right) => right.score - left.score);
  const usedOld = new Set(), usedNew = new Set(), matched = [];
  for (const candidate of candidates) {
    if (!usedOld.has(candidate.oldIndex) && !usedNew.has(candidate.newIndex)) {
      usedOld.add(candidate.oldIndex); usedNew.add(candidate.newIndex); matched.push(candidate);
    }
  }
  return {
    matched,
    unmatchedOld: oldItems.map((_, index) => index).filter((index) => !usedOld.has(index)),
    unmatchedNew: newItems.map((_, index) => index).filter((index) => !usedNew.has(index)),
  };
}

function describeChanges(previous, next, meters) {
  const fields = [];
  if (normalize(previous.address) !== normalize(next.address)) fields.push("address");
  if (meters > 2) fields.push("coordinates");
  if (String(previous.schedule ?? "") !== next.schedule) fields.push("schedule");
  if (String((previous.violations ?? []).join(", ")) !== next.rawViolations) fields.push("violations");
  return fields.length ? [{ id: previous.id, listNumber: next.listNumber, fields, distanceMeters: Number(meters.toFixed(1)), oldAddress: previous.address, newAddress: next.address }] : [];
}

function validateIncoming(items) {
  const warnings = [];
  for (const item of items) {
    if (/\d+\s*км\s*\+\s*\d+\s*км/i.test(item.address)) warnings.push({ type: "possible-distance-unit-typo", listNumber: item.listNumber, address: item.address });
  }
  for (let left = 0; left < items.length; left += 1) {
    for (let right = left + 1; right < items.length; right += 1) {
      const meters = distance(items[left], items[right]);
      if (meters < 2) warnings.push({ type: "co-located-records", distanceMeters: Number(meters.toFixed(1)), records: [items[left].listNumber, items[right].listNumber], addresses: [items[left].address, items[right].address] });
    }
  }
  return warnings;
}

function summary(camera) { return { id: camera.id, address: camera.address, lat: camera.lat, lng: camera.lng, sourceKind: camera.sourceKind }; }
function validPoint(item) { return Number.isFinite(item.lat) && Number.isFinite(item.lng) && item.lat >= 51 && item.lat <= 55 && item.lng >= 42 && item.lng <= 48; }
function number(value) { const result = Number(String(value).replace(",", ".").replace(/[^\d.-]/g, "")); return Number.isFinite(result) ? result : NaN; }
function normalize(value) { return String(value).toLocaleLowerCase("ru").replaceAll("ё", "е").replaceAll("«", '"').replaceAll("»", '"').replace(/[—–]/g, "-").replace(/пензенская\s+обл(?:асть)?\.?/gi, "").replace(/[^а-яa-z0-9]+/gi, " ").trim(); }
function similarity(left, right) { const a = new Set(normalize(left).split(" ")), b = new Set(normalize(right).split(" ")); return [...a].filter((item) => b.has(item)).length / Math.max(a.size, b.size, 1); }
function distance(a, b) { const rad = (value) => value * Math.PI / 180, p1 = rad(a.lat), p2 = rad(b.lat), dp = p2 - p1, dl = rad(b.lng - a.lng); const h = Math.sin(dp / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2; return 6371000 * 2 * Math.asin(Math.sqrt(h)); }
function parseArgs(values) { const result = {}; for (let index = 0; index < values.length; index += 1) { if (values[index] === "--apply") result.apply = true; else if (values[index].startsWith("--")) { result[values[index].slice(2)] = values[index + 1]; index += 1; } } return result; }
