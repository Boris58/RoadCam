import { readFile, writeFile } from "node:fs/promises";

const inputPath = new URL("../data/penza-stationary-official-2026-09-01.csv", import.meta.url);
const camerasPath = new URL("../public/cameras-penza.json", import.meta.url);
const archivePath = new URL("../data/penza-stationary-demounted-2026-09-01.json", import.meta.url);
const sourceUrl = "https://xn--80aebkobnwfcnsfk1e0h.xn--p1ai/r/58";

function parseCsv(text) {
  const rows = [];
  let row = [], value = "", quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (char === '"') {
      if (quoted && text[index + 1] === '"') { value += '"'; index += 1; }
      else quoted = !quoted;
    } else if (char === "," && !quoted) { row.push(value); value = ""; }
    else if ((char === "\n" || char === "\r") && !quoted) {
      if (char === "\r" && text[index + 1] === "\n") index += 1;
      row.push(value); if (row.some((cell) => cell.trim())) rows.push(row); row = []; value = "";
    } else value += char;
  }
  if (value || row.length) { row.push(value); if (row.some((cell) => cell.trim())) rows.push(row); }
  return rows;
}

function normalize(value) {
  return value.toLocaleLowerCase("ru").replaceAll("ё", "е").replaceAll("«", '"').replaceAll("»", '"')
    .replace(/[—–]/g, "-").replace(/пензенская\s+обл(?:асть)?\.?/gi, "").replace(/[^а-яa-z0-9]+/gi, " ").trim();
}

function distance(a, b) {
  const rad = (value) => value * Math.PI / 180;
  const radius = 6371000, p1 = rad(a.lat), p2 = rad(b.lat), dp = p2 - p1, dl = rad(b.lng - a.lng);
  const h = Math.sin(dp / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
  return 2 * radius * Math.asin(Math.sqrt(h));
}

function similarity(left, right) {
  const a = new Set(normalize(left).split(" ")), b = new Set(normalize(right).split(" "));
  const common = [...a].filter((item) => b.has(item)).length;
  return common / Math.max(a.size, b.size, 1);
}

const rawRows = parseCsv(await readFile(inputPath, "utf8")).slice(3);
const official = rawRows.filter((row) => row[0]?.trim()).map((row, index) => ({
  listNumber: index + 1,
  address: row[0].trim(), lat: Number(row[1]), lng: Number(row[2]), schedule: row[3].trim(), rawViolations: row[4].trim(),
}));
if (official.length !== 139 || official.some((item) => !Number.isFinite(item.lat) || !Number.isFinite(item.lng))) {
  throw new Error(`Ожидалось 139 корректных строк, получено ${official.length}.`);
}

const all = JSON.parse(await readFile(camerasPath, "utf8"));
const stationary = all.filter((camera) => !camera.cameraType || camera.cameraType === "stationary");
const other = all.filter((camera) => camera.cameraType && camera.cameraType !== "stationary");
const candidates = [];
for (let oldIndex = 0; oldIndex < stationary.length; oldIndex += 1) {
  for (let newIndex = 0; newIndex < official.length; newIndex += 1) {
    const old = stationary[oldIndex], next = official[newIndex], meters = distance(old, next);
    const exactAddress = normalize(old.address) === normalize(next.address), textScore = similarity(old.address, next.address);
    if (exactAddress || meters < 100 || textScore > 0.72) {
      candidates.push({ oldIndex, newIndex, meters, score: (exactAddress ? 1000 : 0) + (meters < 3 ? 500 : 0) + (meters < 30 ? 300 : 0) + (meters < 100 ? 100 : 0) + textScore * 100 - meters / 100 });
    }
  }
}
candidates.sort((a, b) => b.score - a.score);
const usedOld = new Set(), usedNew = new Set(), matched = [];
for (const candidate of candidates) {
  if (!usedOld.has(candidate.oldIndex) && !usedNew.has(candidate.newIndex)) {
    usedOld.add(candidate.oldIndex); usedNew.add(candidate.newIndex); matched.push(candidate);
  }
}
if (matched.length !== 133) throw new Error(`Ожидалось 133 совпадения, получено ${matched.length}.`);

const current = matched.map(({ oldIndex, newIndex }) => {
  const previous = stationary[oldIndex], next = official[newIndex];
  return {
    ...previous,
    address: next.address,
    lat: next.lat,
    lng: next.lng,
    violations: [next.rawViolations],
    schedule: next.schedule,
    cameraType: "stationary",
    sourceKind: "official-current",
    sourceDate: "2026-09-01",
    sourceName: "Официальный перечень Госавтоинспекции Пензенской области",
    sourceUrl,
    verification: "official",
  };
});

const byListNumber = new Map(official.map((item) => [item.listNumber, item]));
const newDetails = new Map([
  [25, { cameraCodes: ["VNB190086K"], speedLimit: 60 }],
  [26, { cameraCodes: ["VNB190090K"], speedLimit: 60 }],
  [80, { cameraCodes: ["ВСМ-2 22099003"], speedLimit: 50 }],
  [97, { cameraCodes: ["PM0787"], speedLimit: 60 }],
  [136, { cameraCodes: ["BM25B655"], speedLimit: 90, truckSpeedLimit: 70, address: 'а/д «Тамбов - Пенза» - пгт Беково, 46 км + 720 м, Пензенская обл.' }],
  [139, { cameraCodes: ["SPm110370726S"], speedLimit: 60, cameraModel: "Стрелка-Плюс" }],
]);
let nextId = 580013;
for (const listNumber of [25, 26, 80, 97, 136, 139]) {
  const item = byListNumber.get(listNumber), details = newDetails.get(listNumber);
  current.push({
    id: nextId++, address: details.address ?? item.address, lat: item.lat, lng: item.lng, violations: [item.rawViolations], schedule: item.schedule,
    cameraType: "stationary", ...details, sourceKind: "official-current", sourceDate: "2026-09-01",
    sourceName: "Официальный перечень Госавтоинспекции Пензенской области", sourceUrl, verification: "official",
  });
}

// Подтверждённые служебные номера и направления.
for (const camera of current) {
  if (normalize(camera.address).includes(normalize("ул.Аустрина, д.143е"))) {
    camera.cameraCodes = ["MXR-10/20-58-003"]; camera.speedLimit ??= 60;
  }
  if (camera.address.includes("Генерала Глазунова") && camera.address.includes("Яшиной")) {
    camera.cameraCodes = ["MXR-10/20-58-014"]; camera.cameraModel = "Орлан 2.0"; camera.directions = ["В сторону ул. Яшиной"];
  }
  if (camera.address.includes("Генерала Глазунова") && camera.address.includes("Строителей")) {
    camera.cameraCodes = ["MXR-10/20-58-005"]; camera.cameraModel = "Орлан 2.0"; camera.directions = ["В сторону проспекта Строителей"];
  }
}

const unmatchedOld = stationary.filter((_, index) => !usedOld.has(index));
const demountedIds = new Set([3, 7, 9]);
const retainIds = new Set([18, 25, 42]);
const demounted = unmatchedOld.filter((camera) => demountedIds.has(camera.id)).map((camera) => ({ ...camera, archivedAt: "2026-09-01", archiveReason: "Демонтаж подтверждён сотрудником" }));
const retained = unmatchedOld.filter((camera) => retainIds.has(camera.id)).map((camera) => ({
  ...camera, cameraType: "stationary", sourceKind: "official-previous", sourceDate: "2026-09-01",
  sourceName: "Ранее присутствовала в официальном перечне Госавтоинспекции; в актуальном перечне отсутствует",
  sourceUrl, verification: "official",
}));
if (demounted.length !== 3 || retained.length !== 3) throw new Error("Не удалось однозначно обработать шесть отсутствующих камер.");

const output = [...current, ...retained, ...other].sort((a, b) => a.id - b.id);
await writeFile(camerasPath, `${JSON.stringify(output, null, 2)}\n`);
await writeFile(archivePath, `${JSON.stringify(demounted, null, 2)}\n`);
console.log(JSON.stringify({ total: output.length, stationary: current.length + retained.length, officialCurrent: current.length, officialPrevious: retained.length, demounted: demounted.length }, null, 2));
