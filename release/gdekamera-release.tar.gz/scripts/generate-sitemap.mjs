import { readFile, writeFile } from "node:fs/promises";

const baseUrl = "https://xn--80aahefb7ar1b.xn--p1ai";
const summary = JSON.parse(await readFile(new URL("../public/official-regions-summary.json", import.meta.url), "utf8"));
const cameraIndex = JSON.parse(await readFile(new URL("../public/camera-search-index.json", import.meta.url), "utf8"));
const today = new Date().toISOString().slice(0, 10);
const seoRegions = {};

function isoDate(value) {
  if (typeof value !== "string") return today;
  const direct = value.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (direct) return `${direct[1]}-${direct[2]}-${direct[3]}`;
  const russian = value.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
  if (russian) return `${russian[3]}-${russian[2]}-${russian[1]}`;
  return today;
}

function regionStats(cameras) {
  const types = { stationary: 0, portable: 0, dummy: 0, unspecified: 0 };
  const violationCounts = new Map();
  for (const camera of cameras) {
    const type = camera.cameraType ?? "stationary";
    if (type in types) types[type] += 1;
    for (const violation of camera.violations ?? []) violationCounts.set(violation, (violationCounts.get(violation) ?? 0) + 1);
  }
  return {
    types,
    topViolations: [...violationCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6).map(([name, count]) => ({ name, count })),
  };
}

for (const code of Object.keys(summary)) {
  const region = JSON.parse(await readFile(new URL(`../public/official-regions/${code}.json`, import.meta.url), "utf8"));
  seoRegions[code] = {
    cameras: region.cameras.slice(0, 20).map(({ address, lat, lng }) => ({ address, lat, lng })),
    sourceDate: region.sourceDate ?? summary[code]?.sourceDate ?? "",
    sourceUrl: region.sourceUrl ?? "",
    ...regionStats(region.cameras),
  };
}

const pages = [
  { path: "/", priority: "1.0", changefreq: "daily" },
  { path: "/obzhalovanie", priority: "0.8", changefreq: "monthly" },
  { path: "/spravochnik", priority: "0.9", changefreq: "monthly" },
  { path: "/notifications", priority: "0.8", changefreq: "monthly" },
  { path: "/updates", priority: "0.8", changefreq: "weekly" },
  { path: "/privacy", priority: "0.3", changefreq: "yearly" },
  { path: "/region/50", priority: "0.9", changefreq: "weekly" },
  { path: "/region/58", priority: "0.9", changefreq: "weekly" },
  ...Object.keys(summary)
    .sort((a, b) => Number(a) - Number(b))
    .map((code) => ({ path: `/region/${code}`, priority: "0.8", changefreq: "weekly" })),
];

const appealSlugs = ["za-rulem-drugoy-voditel","avtomobil-prodan","oshibka-gosnomera","ne-soglasen-s-narusheniem","vynuzhdennaya-ostanovka","avtomobil-ugnan","povtorniy-shtraf","vosstanovlenie-sroka"];
pages.push(...appealSlugs.map((slug) => ({ path: `/obzhalovanie/${slug}`, priority: "0.8", changefreq: "monthly" })));

const guideSlugs = ["proverka-poverki-kamery-gibdd","kak-nayti-kameru-po-adresu","proverit-kameru-v-oficialnom-perechne","kakie-narusheniya-fiksiruyut-kamery-gibdd","kak-proverit-zakonnost-kamery-gibdd"];
pages.push(...guideSlugs.map((slug) => ({ path: `/spravochnik/${slug}`, priority: slug === "proverka-poverki-kamery-gibdd" ? "0.9" : "0.8", changefreq: "monthly" })));

const citySlugs = ["moskva","sankt-peterburg","penza","kazan","ufa","novosibirsk","ekaterinburg","nizhniy-novgorod","krasnoyarsk","chelyabinsk","samara","omsk","rostov-na-donu","krasnodar","voronezh","perm","volgograd","saratov","tyumen","tula"];
pages.push(...citySlugs.map((slug) => ({ path: `/city/${slug}`, priority: "0.8", changefreq: "weekly" })));
pages.push(...cameraIndex.map((camera) => ({ path: `/camera/${camera.c}/${camera.i}`, priority: "0.6", changefreq: "monthly", lastmod: isoDate(summary[camera.c]?.sourceDate) })));

const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${pages.map((page) => `  <url>
    <loc>${baseUrl}${page.path}</loc>
    <lastmod>${page.lastmod ?? (page.path.startsWith("/region/") ? isoDate(summary[page.path.slice(8)]?.sourceDate) : today)}</lastmod>
    <changefreq>${page.changefreq}</changefreq>
    <priority>${page.priority}</priority>
  </url>`).join("\n")}
</urlset>
`;

await writeFile(new URL("../public/sitemap.xml", import.meta.url), xml, "utf8");
await writeFile(new URL("../public/official-regions-seo.json", import.meta.url), `${JSON.stringify(seoRegions, null, 2)}\n`, "utf8");
console.log(`Generated sitemap.xml with ${pages.length} URLs`);
