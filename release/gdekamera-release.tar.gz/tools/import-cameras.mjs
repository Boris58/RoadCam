#!/usr/bin/env node

import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";
import * as XLSX from "xlsx";
import { XMLParser } from "fast-xml-parser";
import * as pdfjs from "pdfjs-dist/legacy/build/pdf.mjs";

const toolDir = path.dirname(fileURLToPath(import.meta.url));
const projectDir = path.resolve(toolDir, "..");
const regions = JSON.parse(await fs.readFile(path.join(toolDir, "regions.json"), "utf8"));
const args = parseArgs(process.argv.slice(2));

if (!args.region || !regions[args.region]) {
  console.error("Укажите регион из tools/regions.json, например: npm run cameras:import -- --region 77");
  process.exit(1);
}

const region = regions[args.region];
const outputDir = path.join(projectDir, "data", "imports", args.region);
await fs.mkdir(outputDir, { recursive: true });

const html = args.page
  ? await fs.readFile(path.resolve(args.page), "utf8")
  : await fetchText(region.page);
const candidates = discoverFiles(html, region.page);

if (!candidates.length) {
  throw new Error("В разделе не найдены ссылки на файлы камер. Структура страницы могла измениться.");
}

const latest = selectLatestFiles(candidates);
const report = {
  regionCode: args.region,
  regionName: region.name,
  sourcePage: region.page,
  checkedAt: new Date().toISOString(),
  discoveredFiles: candidates.length,
  selectedFiles: [],
  totals: { stationary: 0, portable: 0, combined: 0, excludedMobile: 0 },
};

for (const candidate of latest) {
  if (args.dryRun) {
    report.selectedFiles.push({ ...candidate, dryRun: true });
    continue;
  }

  const downloaded = await downloadFile(candidate.url, outputDir, candidate.label);
  const parsed = await parseSource(downloaded.path, downloaded.contentType);
  const normalized = normalizeRecords(parsed.records, candidate.kind, candidate.url);
  const mobileCount = normalized.filter((item) => item.cameraType === "mobile").length;
  const accepted = normalized.filter((item) => item.cameraType !== "mobile");
  report.totals.excludedMobile += mobileCount;
  report.totals[candidate.kind] += accepted.length;

  const jsonName = `${candidate.kind}-${path.parse(downloaded.fileName).name}.json`;
  await fs.writeFile(path.join(outputDir, jsonName), JSON.stringify(accepted, null, 2), "utf8");
  report.selectedFiles.push({
    kind: candidate.kind,
    label: candidate.label,
    url: candidate.url,
    publishedAt: candidate.publishedAt,
    downloadedAs: downloaded.fileName,
    parsedRows: parsed.records.length,
    acceptedCameras: accepted.length,
    excludedMobile: mobileCount,
    warnings: parsed.warnings ?? [],
    output: jsonName,
  });
}

await fs.writeFile(path.join(outputDir, "import-report.json"), JSON.stringify(report, null, 2), "utf8");
console.log(JSON.stringify(report, null, 2));

function parseArgs(values) {
  const result = {};
  for (let index = 0; index < values.length; index += 1) {
    const value = values[index];
    if (value === "--dry-run") result.dryRun = true;
    else if (value.startsWith("--")) {
      result[value.slice(2)] = values[index + 1];
      index += 1;
    }
  }
  return result;
}

async function fetchText(url) {
  const response = await fetch(url, { headers: { "user-agent": "RoadCam/0.3 (+public road safety data importer)" } });
  if (!response.ok) throw new Error(`Не удалось открыть страницу региона: HTTP ${response.status}`);
  const buffer = await response.arrayBuffer();
  const contentType = response.headers.get("content-type") ?? "";
  const charset = contentType.match(/charset=([^;]+)/i)?.[1]?.trim() ?? "utf-8";
  try { return new TextDecoder(charset).decode(buffer); }
  catch { return new TextDecoder("utf-8").decode(buffer); }
}

function discoverFiles(html, baseUrl) {
  const sectionNeedle = "о размещении информации о местах установки средств фотовидеофиксации";
  const cleanHtml = html.replace(/<!--[\s\S]*?-->/g, "");
  const anchorPattern = /<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  const result = [];
  let match;
  while ((match = anchorPattern.exec(cleanHtml))) {
    const href = decodeEntities(match[1]);
    const label = stripTags(match[2]);
    const context = stripTags(cleanHtml.slice(Math.max(0, match.index - 1400), match.index + match[0].length + 350));
    const linkText = `${label} ${href}`.toLocaleLowerCase("ru");
    const haystack = `${linkText} ${context.toLocaleLowerCase("ru")}`;
    const looksLikeFile = /\.(xlsx?|csv|xml|pdf|ods|zip)(?:$|[?#])/i.test(href) || /скачать|файл|перечень|комплекс/i.test(label);
    const inTargetSection = haystack.includes(sectionNeedle) || /мест.*установк.*фото.*видео.*фиксац/i.test(haystack);
    if (!looksLikeFile || !inTargetSection) continue;
    const kind = classifyKind(linkText);
    if (kind === "mobile") continue;
    result.push({
      url: new URL(href, baseUrl).href,
      label: label || path.basename(new URL(href, baseUrl).pathname) || "camera-data",
      kind,
      publishedAt: extractDate(`${label} ${context} ${href}`),
      order: result.length,
    });
  }
  return deduplicate(result, (item) => item.url);
}

function classifyKind(text) {
  if (/мобильн/.test(text)) return "mobile";
  if (/передвижн|переносн/.test(text)) return "portable";
  if (/стационарн/.test(text)) return "stationary";
  return "combined";
}

function selectLatestFiles(candidates) {
  return ["stationary", "portable", "combined"]
    .map((kind) => candidates.filter((item) => item.kind === kind).sort(compareNewest)[0])
    .filter(Boolean);
}

function compareNewest(left, right) {
  if (left.publishedAt && right.publishedAt) return right.publishedAt.localeCompare(left.publishedAt);
  if (left.publishedAt) return -1;
  if (right.publishedAt) return 1;
  return right.order - left.order;
}

function extractDate(text) {
  const matches = [...text.matchAll(/(?:^|\D)(0?[1-9]|[12]\d|3[01])[.\/-](0?[1-9]|1[0-2])[.\/-](20\d{2})(?:\D|$)/g)];
  if (!matches.length) return null;
  const [, day, month, year] = matches.at(-1);
  return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
}

async function downloadFile(url, directory, label) {
  const response = await fetch(url, { headers: { "user-agent": "RoadCam/0.3 (+public road safety data importer)" } });
  if (!response.ok) throw new Error(`Не удалось скачать ${url}: HTTP ${response.status}`);
  const contentType = response.headers.get("content-type") ?? "application/octet-stream";
  const disposition = response.headers.get("content-disposition") ?? "";
  const headerName = disposition.match(/filename\*?=(?:UTF-8''|["']?)([^"';]+)/i)?.[1];
  let fileName = safeName(headerName ? decodeURIComponent(headerName) : path.basename(new URL(url).pathname));
  if (!path.extname(fileName)) fileName += extensionFor(contentType, label);
  const target = path.join(directory, fileName || `camera-data${extensionFor(contentType, label)}`);
  await fs.writeFile(target, new Uint8Array(await response.arrayBuffer()));
  return { path: target, fileName: path.basename(target), contentType };
}

async function parseSource(filePath, contentType) {
  const extension = path.extname(filePath).toLowerCase();
  if ([".xlsx", ".xls", ".ods"].includes(extension)) return parseWorkbook(filePath);
  if (extension === ".pdf" || contentType.includes("pdf")) return parsePdf(filePath);
  if (extension === ".xml" || contentType.includes("xml")) return parseXml(filePath);
  if ([".csv", ".txt"].includes(extension) || contentType.includes("csv") || contentType.startsWith("text/")) return parseDelimited(filePath);
  throw new Error(`Формат ${extension || contentType} пока не распознан`);
}

function parseWorkbook(filePath) {
  const workbook = XLSX.readFile(filePath, { cellDates: true });
  const records = workbook.SheetNames.flatMap((name) => XLSX.utils.sheet_to_json(workbook.Sheets[name], { header: 1, defval: "", raw: false }));
  return { records, warnings: [] };
}

async function parsePdf(filePath) {
  const data = new Uint8Array(await fs.readFile(filePath));
  const document = await pdfjs.getDocument({ data, useWorkerFetch: false, isEvalSupported: false }).promise;
  const records = [];
  for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber += 1) {
    const page = await document.getPage(pageNumber);
    const content = await page.getTextContent();
    records.push(content.items.map((item) => item.str).filter(Boolean));
  }
  const characterCount = records.flat().join("").length;
  const warnings = characterCount < document.numPages * 80
    ? ["PDF почти не содержит текстового слоя; вероятно, это скан и требуется OCR/ручная проверка."]
    : [];
  return { records, warnings };
}

async function parseXml(filePath) {
  const xml = await fs.readFile(filePath, "utf8");
  const parsed = new XMLParser({ ignoreAttributes: false, trimValues: true }).parse(xml);
  const records = [];
  collectXmlRecords(parsed, records);
  return { records, warnings: [] };
}

async function parseDelimited(filePath) {
  const text = await fs.readFile(filePath, "utf8");
  const delimiter = text.split(/\r?\n/, 1)[0].split(";").length >= text.split(/\r?\n/, 1)[0].split(",").length ? ";" : ",";
  return { records: text.split(/\r?\n/).filter(Boolean).map((line) => line.split(delimiter).map((cell) => cell.trim())), warnings: [] };
}

function collectXmlRecords(value, records) {
  if (Array.isArray(value)) {
    value.forEach((item) => typeof item === "object" ? records.push(flattenObject(item)) : records.push([String(item)]));
    return;
  }
  if (value && typeof value === "object") Object.values(value).forEach((item) => collectXmlRecords(item, records));
}

function flattenObject(value, result = []) {
  Object.values(value ?? {}).forEach((item) => {
    if (item && typeof item === "object") flattenObject(item, result);
    else if (item !== "") result.push(String(item));
  });
  return result;
}

function normalizeRecords(records, sourceKind, sourceUrl) {
  return records.map((row, index) => {
    const cells = Array.isArray(row) ? row.map((cell) => String(cell ?? "").trim()).filter(Boolean) : [String(row)];
    const text = cells.join(" | ");
    const coordinates = findCoordinates(text);
    if (!coordinates) return null;
    const cameraType = classifyKind(text.toLocaleLowerCase("ru"));
    const violations = cells.filter((cell) => /скорост|встречн|светофор|ремн|разметк|остановк|полос|пешеход|телефон/i.test(cell));
    const address = cells.find((cell) => /ул\.|улиц|шоссе|просп|дорог|км|пересеч|район|обл\.|г\./i.test(cell)) ?? cells[0] ?? "Место установки не указано";
    return {
      id: `${sourceKind}-${index + 1}`,
      address,
      violations: deduplicate(violations.flatMap((item) => item.split(/[;|]/).map((part) => part.trim()).filter(Boolean)), (item) => item),
      lat: coordinates.lat,
      lng: coordinates.lng,
      cameraType: cameraType === "combined" ? sourceKind : cameraType,
      source: sourceUrl,
    };
  }).filter(Boolean);
}

function findCoordinates(text) {
  const normalized = text.replace(/,/g, ".");
  const labeled = normalized.match(/(?:широт|lat|ш\.)\D{0,12}(\d{2}\.\d{3,})[\s\S]{0,30}(?:долгот|lon|lng|д\.)\D{0,12}(\d{2,3}\.\d{3,})/i);
  const pair = labeled ?? normalized.match(/(?:^|\D)([4-8]\d\.\d{3,})\s*[,;\s]+([2-9]\d\.\d{3,})(?:\D|$)/);
  if (!pair) return null;
  const lat = Number(pair[1]);
  const lng = Number(pair[2]);
  if (lat < 40 || lat > 82 || lng < 19 || lng > 181) return null;
  return { lat, lng };
}

function stripTags(value) { return decodeEntities(value.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ")).trim(); }
function decodeEntities(value) { return value.replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">"); }
function safeName(value) { return (value || "camera-data").replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").slice(0, 180); }
function extensionFor(contentType, label) {
  const probe = `${contentType} ${label}`.toLowerCase();
  if (probe.includes("pdf")) return ".pdf";
  if (probe.includes("spreadsheet") || probe.includes("excel") || probe.includes("xlsx")) return ".xlsx";
  if (probe.includes("xml")) return ".xml";
  if (probe.includes("csv")) return ".csv";
  return ".bin";
}
function deduplicate(items, key) { return [...new Map(items.map((item) => [key(item), item])).values()]; }
