#!/usr/bin/env node

import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const toolDir = path.dirname(fileURLToPath(import.meta.url));
const projectDir = path.resolve(toolDir, "..");
const regionDir = path.join(projectDir, "public", "official-regions");
const reportPath = path.join(projectDir, "data", "camera-type-classification-report.json");
const roundTheClockPattern = /круглосут/iu;

const files = (await fs.readdir(regionDir)).filter((file) => /^\d{2}\.json$/.test(file)).sort();
const report = {
  rule: "Запись с полным или обрезанным словом, начинающимся на «круглосут», считается стационарной",
  classifiedAsStationary: 0,
  unspecifiedBefore: 0,
  unspecifiedAfter: 0,
  regions: [],
};

for (const file of files) {
  const filePath = path.join(regionDir, file);
  const region = JSON.parse(await fs.readFile(filePath, "utf8"));
  let before = 0;
  let classified = 0;

  for (const camera of region.cameras) {
    if (camera.cameraType !== "unspecified") continue;
    before += 1;
    const evidence = [camera.address, ...(camera.directions ?? []), camera.schedule ?? ""].join(" ");
    if (!roundTheClockPattern.test(evidence)) continue;
    camera.cameraType = "stationary";
    classified += 1;
  }

  const remaining = region.cameras.filter((camera) => camera.cameraType === "unspecified").length;
  report.unspecifiedBefore += before;
  report.classifiedAsStationary += classified;
  report.unspecifiedAfter += remaining;
  if (before > 0) {
    report.regions.push({
      code: region.code,
      name: region.name,
      unspecifiedBefore: before,
      classifiedAsStationary: classified,
      unspecifiedAfter: remaining,
    });
  }

  if (classified > 0) await fs.writeFile(filePath, JSON.stringify(region), "utf8");
}

await fs.mkdir(path.dirname(reportPath), { recursive: true });
await fs.writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`, "utf8");
console.log(JSON.stringify(report, null, 2));
