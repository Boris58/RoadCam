import fs from "node:fs/promises";

const input = process.argv[2];
const rows = JSON.parse(await fs.readFile(input, "utf8"));
const groups = new Map();

for (const row of rows) {
  const lat = Number(row.lat), lng = Number(row.lon);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue;
  const cameraType = row.type === "mobile" ? "portable" : "stationary";
  const key = `${cameraType}|${lat.toFixed(6)}|${lng.toFixed(6)}`;
  const group = groups.get(key) ?? { lat, lng, cameraType, addresses: new Set(), violations: new Set(), schedules: new Set(), recordCount: 0 };
  const address = clean(row.address);
  if (address) group.addresses.add(address);
  for (const violation of normalizeViolations(row.violations)) group.violations.add(violation);
  const schedule = extractSchedule(row.mode);
  if (schedule) group.schedules.add(schedule);
  group.recordCount += 1;
  groups.set(key, group);
}

const cameras = [...groups.values()].sort((a,b) => a.cameraType.localeCompare(b.cameraType) || a.lat-b.lat || a.lng-b.lng).map((group,index) => {
  const directions = [...group.addresses];
  const address = chooseAddress(directions, group.lat, group.lng);
  return { id:500001+index, address, violations:[...group.violations], lat:group.lat, lng:group.lng, cameraType:group.cameraType,
    ...(directions.length>1?{directions}:{}), ...(group.schedules.size?{schedule:[...group.schedules].join("; ")} : {}), sourceDate:"Август 2026", recordCount:group.recordCount };
});
await fs.writeFile("public/cameras-moscow-oblast.json", JSON.stringify(cameras)+"\n");
console.log(JSON.stringify({published:cameras.length,stationary:cameras.filter(x=>x.cameraType==="stationary").length,portable:cameras.filter(x=>x.cameraType==="portable").length}));

function clean(value){ return String(value??"").replace(/[«»“”„]/g,'"').replace(/\s+/g," ").replace(/\s+([,.;])/g,"$1").trim(); }
function chooseAddress(addresses,lat,lng){
  if(!addresses.length){ const restored={"55.564417,39.009068":'8 км + 500 м, а/д "Куровское — Шатура — Дмитровский Погост — Самойлиха"'}[`${lat.toFixed(6)},${lng.toFixed(6)}`]; return restored??`Место установки ${lat.toFixed(6)}, ${lng.toFixed(6)}`; }
  return [...addresses].sort((a,b)=>score(b)-score(a)||a.length-b.length)[0];
}
function score(v){ return (/\b(?:г\.|н\.п\.|д\.|ул\.)/i.test(v)?4:0)+(/\b\d+\s*км/i.test(v)?3:0)+(/московск/i.test(v)?1:0)-(/к камере|от камеры/i.test(v)?1:0); }
function extractSchedule(value){ const t=clean(value); if(/круглосуточно/i.test(t)) return "Круглосуточно"; const s=t.match(/\b\d{2}:\d{2}-\d{2}:\d{2}\b/)?.[0]??""; return s==="00:00-00:00"?"Требует уточнения":s; }
function normalizeViolations(value){
  const t=clean(value).toLocaleLowerCase("ru").replace(/ё/g,"е"), out=[];
  const add=(re,label)=>{if(re.test(t)&&!out.includes(label)) out.push(label)};
  add(/скорост/,"Превышение скорости"); add(/встречн/,"Выезд на сторону встречного движения"); add(/сплошн|разметк[аи]?\s*1\.1|пазметк[аи]?\s*1\.1/,"Пересечение сплошной линии (разметка 1.1)");
  if(!/стоп\s*[- ]?лини|знак\s*6\.16/.test(t)) add(/запрещающ.*сигнал.*светофор|сфетофор/,"Проезд на запрещающий сигнал светофора"); add(/знак\s*2[.,]5|движен[а-яё]*\s+без\s+(?:полной\s+)?остановк/,"Проезд без остановки перед знаком 2.5 «STOP»"); if(!/знак\s*2[.,]5|движен[а-яё]*\s+без\s+(?:полной\s+)?остановк/.test(t)) add(/стоп\s*[- ]?лини|знак\s*6\.16/,"Выезд за стоп-линию на запрещающий сигнал"); add(/ремн/,"Нарушение правил применения ремней безопасности"); add(/телефон/,"Использование телефона водителем");
  add(/обочин/,"Движение по обочине"); add(/полос.*маршрутн|маршрутн.*транспорт/,"Движение по полосе общественного транспорта"); add(/пешеход/,"Непредоставление преимущества пешеходу"); if(!/стоп\s*[- ]?лини|знак\s*(?:6\.16|2[.,]5)|движен[а-яё]*\s+без\s+(?:полной\s+)?остановк/.test(t)) add(/нарушен.*правил.*(?:остановк|стоянк)|парков/,"Нарушение правил остановки или стоянки");
  add(/железнодорожн/,"Нарушение правил движения через железнодорожные пути"); add(/мотошлем/,"Нарушение правил применения мотошлема"); add(/островок/,"Пересечение разметки 1.2 (островок безопасности)"); add(/поворот|разворот/,"Поворот или разворот с нарушением требований знаков или разметки");
  if(/грузов/.test(t)&&/2[,.]5/.test(t)) add(/./,"Движение грузового ТС массой более 2,5 т в левой полосе");
  if(/грузов/.test(t)&&/3[,.]5/.test(t)&&/второго ряда/.test(t)) add(/./,"Движение грузового ТС массой более 3,5 т далее второго ряда");
  if(/знак/.test(t)&&/грузов/.test(t)&&/запрещ/.test(t)) add(/./,"Несоблюдение требований знаков, запрещающих движение грузовых ТС");
  return out.length?out:["Требует уточнения"];
}
