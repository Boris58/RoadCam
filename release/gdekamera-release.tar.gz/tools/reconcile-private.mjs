#!/usr/bin/env node
import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import * as XLSX from "xlsx";

const args = parseArgs(process.argv.slice(2));
if (!args.private || !args.public) {
  console.error("Пример: npm run cameras:reconcile -- --private private-data/current.xlsx --public public/cameras-penza.json");
  process.exit(1);
}
const privatePath = path.resolve(args.private);
const publicPath = path.resolve(args.public);
const publicCameras = JSON.parse(await fs.readFile(publicPath, "utf8"));
const privatePoints = await readPrivatePoints(privatePath);
const radiusMeters = Number(args.radius ?? 180);
const kept = [];
const removed = [];

for (const camera of publicCameras) {
  const match = privatePoints.some((point) => {
    if (Number.isFinite(camera.lat) && Number.isFinite(camera.lng) && point.lat && point.lng && distanceMeters(camera.lat, camera.lng, point.lat, point.lng) <= radiusMeters) return true;
    return point.address && camera.address && addressesMatch(camera.address, point.address);
  });
  (match ? kept : removed).push(camera);
}

const summary = { publicCameras: publicCameras.length, privateRowsRead: privatePoints.length, retainedPublicCameras: kept.length, proposedRemovals: removed.length, radiusMeters, privateDataSaved: false };
if (args.apply) {
  const outputPath = path.resolve(args.output ?? publicPath.replace(/\.json$/i, ".reconciled.json"));
  await fs.writeFile(outputPath, JSON.stringify(kept, null, 2), "utf8");
  summary.output = outputPath;
}
console.log(JSON.stringify(summary, null, 2));

async function readPrivatePoints(filePath) {
  const extension = path.extname(filePath).toLowerCase();
  if ([".xlsx", ".xls", ".ods"].includes(extension)) {
    const workbook = XLSX.readFile(filePath, { raw: false });
    return workbook.SheetNames.flatMap((name) => rowsToPoints(XLSX.utils.sheet_to_json(workbook.Sheets[name], { header: 1, defval: "", raw: false })));
  }
  if (extension === ".json") return jsonToPoints(JSON.parse(await fs.readFile(filePath, "utf8")));
  if ([".csv", ".txt"].includes(extension)) {
    const text = await fs.readFile(filePath, "utf8");
    return rowsToPoints(text.split(/\r?\n/).filter(Boolean).map((line) => line.split(/[;,\t]/)));
  }
  throw new Error(`Неподдерживаемый формат приватного списка: ${extension}`);
}

function rowsToPoints(rows) {
  if (!rows.length) return [];
  const headerIndex = rows.findIndex((row) => row.some((cell) => /широт|latitude|lat|координат/i.test(String(cell))));
  const first = headerIndex >= 0 ? headerIndex : 0;
  const header = (rows[first] ?? []).map((cell) => normalizeHeader(cell));
  return rows.slice(first + 1).map((row) => {
    const record = Object.fromEntries(header.map((name, index) => [name, row[index]]));
    const detected = findCoordinates(row.join(" "));
    return {
      lat: numberValue(record.latitude ?? record.lat) ?? detected?.lat,
      lng: numberValue(record.longitude ?? record.lng ?? record.lon) ?? detected?.lng,
      address: String(record.address ?? record.location ?? row.find((cell) => /ул\.|улиц|шоссе|дорог|км|просп/i.test(String(cell))) ?? ""),
    };
  }).filter((item) => (item.lat && item.lng) || item.address);
}

function jsonToPoints(value) {
  const rows = Array.isArray(value) ? value : value.cameras ?? value.items ?? [];
  return rows.map((item) => ({ lat: numberValue(item.latitude ?? item.lat), lng: numberValue(item.longitude ?? item.lng ?? item.lon), address: String(item.address ?? item.location ?? "") })).filter((item) => (item.lat && item.lng) || item.address);
}

function findCoordinates(value) {
  const match = String(value).replace(/,/g, ".").match(/([4-8]\d\.\d{3,})\D{1,20}([2-9]\d\.\d{3,})/);
  return match ? { lat: Number(match[1]), lng: Number(match[2]) } : null;
}
function addressesMatch(left, right) {
  const a = normalizeAddress(left); const b = normalizeAddress(right);
  return a.length > 14 && b.length > 14 && (a.includes(b) || b.includes(a));
}
function normalizeAddress(value) { return String(value).toLocaleLowerCase("ru").replace(/ё/g, "е").replace(/\b(область|обл|район|р-н|город|г)\b/g, " ").replace(/[^а-я0-9]+/g, " ").replace(/\s+/g, " ").trim(); }
function normalizeHeader(value) {
  const text = String(value).toLocaleLowerCase("ru").trim();
  if (/широт|latitude/.test(text)) return "latitude";
  if (/долгот|longitude/.test(text)) return "longitude";
  if (/^lat$/.test(text)) return "lat";
  if (/^(lng|lon)$/.test(text)) return "lng";
  if (/адрес/.test(text)) return "address";
  if (/мест/.test(text)) return "location";
  return text.replace(/\W+/g, "_");
}
function distanceMeters(lat1, lng1, lat2, lng2) {
  const rad = Math.PI / 180;
  const a = Math.sin((lat2 - lat1) * rad / 2) ** 2 + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin((lng2 - lng1) * rad / 2) ** 2;
  return 6371000 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
function numberValue(value) {
  if (value === undefined || value === null || value === "") return null;
  const number = Number(String(value).replace(",", ".").replace(/[^\d.-]/g, ""));
  return Number.isFinite(number) ? number : null;
}
function parseArgs(values) {
  const result = {};
  for (let index = 0; index < values.length; index += 1) {
    if (values[index] === "--apply") result.apply = true;
    else if (values[index].startsWith("--")) { result[values[index].slice(2)] = values[index + 1]; index += 1; }
  }
  return result;
}
