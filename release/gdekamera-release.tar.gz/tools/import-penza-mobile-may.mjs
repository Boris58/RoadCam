import fs from "node:fs";
import XLSX from "xlsx";

const inputPath = process.argv[2];
if (!inputPath) throw new Error("Укажите путь к исходному XLSX");

const outputPath = new URL("../public/cameras-penza.json", import.meta.url);
const workbook = XLSX.readFile(inputPath);
const sheet = workbook.Sheets[workbook.SheetNames[0]];
const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: null });

const acceptedRows = new Set([
  ...Array.from({ length: 23 }, (_, index) => index + 8),
  33, 39, 40, 41, 43, 44, 45, 47, 48, 49, 51, 52, 53,
  55, 56, 57, 58, 59, 60, 61, 63,
]);

const corrections = new Map([
  [41, { lat: 53.082778, lng: 46.604167, note: "Координата 754 км + 600 м подтверждена существующей точкой перечня" }],
]);

const parseCoordinates = (value) => {
  const numbers = String(value ?? "")
    .replace(/(\d)\s+\.(\d)/g, "$1.$2")
    .replace(/\.\s+(\d)/g, ".$1")
    .match(/\d{2}\.\d+/g)?.map(Number) ?? [];
  if (numbers.length < 2) throw new Error(`Не удалось прочитать координаты: ${value}`);
  return { lat: numbers[0], lng: numbers[1] };
};

const normalizeAddress = (value) => String(value)
  .replace(/\s+/g, " ")
  .replace(/\s+,/g, ",")
  .trim();

const normalizeViolations = (value) => {
  const items = String(value || "Превышение скорости")
    .split(/,\s*/)
    .map((item) => item.trim())
    .filter(Boolean);
  return [...new Set(items)];
};

const existing = JSON.parse(fs.readFileSync(outputPath, "utf8"));
const stationary = existing.filter((camera) => camera.sourceDate !== "Май 2026 — передвижные");

let nextId = 200001;
const mobile = [];
for (const rowNumber of [...acceptedRows].sort((a, b) => a - b)) {
  const [address, violations, rawCoordinates] = rows[rowNumber - 1];
  const coordinates = corrections.get(rowNumber) ?? parseCoordinates(rawCoordinates);
  mobile.push({
    id: nextId++,
    address: normalizeAddress(address),
    violations: normalizeViolations(violations),
    lat: coordinates.lat,
    lng: coordinates.lng,
    cameraType: "portable",
    schedule: "07:00-20:00",
    sourceDate: "Май 2026 — передвижные",
    sourceRow: rowNumber,
    ...(coordinates.note ? { coordinateNote: coordinates.note } : {}),
  });
}

fs.writeFileSync(outputPath, `${JSON.stringify([...stationary, ...mobile])}\n`);
console.log(JSON.stringify({ stationary: stationary.length, addedPortable: mobile.length, total: stationary.length + mobile.length }));
