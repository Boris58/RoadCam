import assert from "node:assert/strict";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

const workerUrl = new URL("../dist/server/index.js", import.meta.url);
workerUrl.searchParams.set("test", String(process.pid) + "-" + String(Date.now()));
const { default: worker } = await import(workerUrl.href);

async function render(path) {
  return worker.fetch(
    new Request("http://localhost" + path, { headers: { accept: "text/html" } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

test("home page renders website metadata and structured data", async () => {
  const response = await render("/");
  const html = await response.text();
  assert.equal(response.status, 200);
  assert.match(html, /<title>Где камера — карта дорожных камер России<\/title>/i);
  assert.match(html, /<h1[^>]*>.*Выберите регион/s);
  assert.match(html, /application\/ld\+json/i);
  assert.match(html, /SearchAction/);
  assert.match(html, /class="home-support-link"/);
  assert.match(html, /class="appeal-link"/);
  assert.match(html, /Предложить улучшение/);
  assert.match(html, /\/support\?amount=other/);
  assert.match(html, /mc\.yandex\.ru\/watch\/112081610/);
  assert.ok(Buffer.byteLength(html) < 100_000, `home HTML is ${Buffer.byteLength(html)} bytes`);
  assert.doesNotMatch(html, /codex-preview/);
});

test("regional page has unique H1, metadata, breadcrumbs and JSON-LD", async () => {
  const response = await render("/region/77");
  const html = await response.text();
  assert.equal(response.status, 200);
  assert.match(html, /<title>Камеры ГИБДД в Москве \| Где камера<\/title>/i);
  assert.match(html, /<h1[^>]*>Камеры ГИБДД в Москве<\/h1>/i);
  assert.doesNotMatch(html, /<h1[^>]*>[^<]*<!-- -->/i);
  assert.equal((html.match(/<h1\b/gi) ?? []).length, 1);
  assert.match(html, /aria-label="Хлебные крошки"/i);
  assert.match(html, /BreadcrumbList/);
  assert.match(html, /ItemList/);
  assert.match(html, /og:title/i);
  assert.doesNotMatch(html, /Регион 77/);
});

test("sitemap contains SEO fields for region pages", async () => {
  const xml = await readFile(new URL("../public/sitemap.xml", import.meta.url), "utf8");
  assert.match(xml, /<loc>https:\/\/xn--80aahefb7ar1b\.xn--p1ai\/region\/77<\/loc>/);
  assert.match(xml, /<lastmod>\d{4}-\d{2}-\d{2}<\/lastmod>/);
  assert.match(xml, /<changefreq>weekly<\/changefreq>/);
  assert.match(xml, /<priority>0\.8<\/priority>/);
  assert.match(xml, /<loc>https:\/\/xn--80aahefb7ar1b\.xn--p1ai\/region\/50<\/loc>/);
  assert.match(xml, /<loc>https:\/\/xn--80aahefb7ar1b\.xn--p1ai\/region\/58<\/loc>/);
  assert.doesNotMatch(xml, /moskovskaya-oblast|penzenskaya-oblast/);
  assert.match(xml, /<loc>https:\/\/xn--80aahefb7ar1b\.xn--p1ai\/city\/penza<\/loc>/);
  assert.match(xml, /<loc>https:\/\/xn--80aahefb7ar1b\.xn--p1ai\/camera\/58\/580012<\/loc>/);
  assert.match(xml, /<loc>https:\/\/xn--80aahefb7ar1b\.xn--p1ai\/spravochnik<\/loc>/);
  assert.match(xml, /<loc>https:\/\/xn--80aahefb7ar1b\.xn--p1ai\/spravochnik\/proverka-poverki-kamery-gibdd<\/loc>/);
});

test("driver guide index and verification article render structured content", async () => {
  const indexResponse = await render("/spravochnik");
  const indexHtml = await indexResponse.text();
  assert.equal(indexResponse.status, 200);
  assert.match(indexHtml, /Справочник водителя/);
  assert.match(indexHtml, /CollectionPage/);

  const response = await render("/spravochnik/proverka-poverki-kamery-gibdd");
  const html = await response.text();
  assert.equal(response.status, 200);
  assert.match(html, /Как проверить поверку камеры ГИБДД/);
  assert.match(html, /fundmetrology\/cm\/mits/);
  assert.match(html, /fundmetrology\/cm\/results/);
  assert.match(html, /заводск(?:ому|ой|ий) номер/i);
  assert.match(html, /FAQPage/);
});

test("city page exposes crawlable camera address links", async () => {
  const response = await render("/city/penza");
  const html = await response.text();
  assert.equal(response.status, 200);
  assert.match(html, /Камеры ГИБДД в Пензе/);
  assert.match(html, /\/camera\/58\/\d+/);
  assert.match(html, /ItemList/);
});

test("camera page renders address, violations and focused map link", async () => {
  const response = await render("/camera/58/580012");
  const html = await response.text();
  assert.equal(response.status, 200);
  assert.match(html, /г\. Пенза - р\.п\. Шемышейка/);
  assert.match(html, /Какие нарушения фиксирует камера/);
  assert.match(html, /\/region\/58\?camera=580012/);
  assert.match(html, /GeoCoordinates/);
});

test("Penza stationary data uses the confirmed 24 September official list", async () => {
  const cameras = JSON.parse(await readFile(new URL("../public/cameras-penza.json", import.meta.url), "utf8"));
  assert.equal(cameras.filter((camera) => camera.sourceKind === "official-current").length, 151);
  assert.equal(cameras.filter((camera) => camera.sourceKind === "official-previous").length, 4);
  assert.ok([3, 7, 9].every((id) => !cameras.some((camera) => camera.id === id)));
  assert.ok([18, 25, 42, 43].every((id) => cameras.some((camera) => camera.id === id && camera.sourceKind === "official-previous")));
  assert.ok(cameras.some((camera) => /ул\.Мира, д\.68/.test(camera.address) && camera.sourceDate === "2026-09-24"));
  assert.ok(cameras.some((camera) => camera.cameraCodes?.includes("MXR-10/20-58-003") && /Аустрина/.test(camera.address)));
  assert.ok(cameras.some((camera) => camera.cameraCodes?.includes("MXR-10/20-58-014") && /Яшиной/.test(camera.address)));
  assert.ok(cameras.some((camera) => camera.cameraCodes?.includes("MXR-10/20-58-005") && /Строителей/.test(camera.address)));
  assert.ok(cameras.some((camera) => camera.cameraCodes?.includes("BM25B655") && camera.speedLimit === 90 && camera.truckSpeedLimit === 70));
});

test("camera cards distinguish official and community data", async () => {
  const mapSource = await readFile(new URL("../app/roadcam-app.tsx", import.meta.url), "utf8");
  const apiSource = await readFile(new URL("../app/api/cameras/route.ts", import.meta.url), "utf8");
  assert.match(mapSource, /В актуальном официальном перечне не найдена/);
  assert.match(mapSource, /Добавлено пользователем/);
  assert.match(mapSource, /Как зафиксировать и обжаловать/);
  assert.match(apiSource, /sourceKind: "community"/);
  assert.doesNotMatch(apiSource, /verification: "official"/);
});

test("region camera query is passed to the interactive map", async () => {
  const response = await render("/region/58?camera=93");
  assert.equal(response.status, 200);
  const html = await response.text();
  assert.match(html, /camera=93|focusCameraId[^\d]*93/);
});

test("regional map keeps SEO headings hidden from the map surface", async () => {
  const response = await render("/region/58");
  const html = await response.text();
  assert.match(html, /region-server-heading/);
  assert.match(html, /Камеры ГИБДД в Пензенской области/);
});

test("legacy region URLs use permanent 301 redirects", async () => {
  for (const [path, destination] of [["/moskovskaya-oblast", "/region/50"], ["/penzenskaya-oblast", "/region/58"]]) {
    const response = await render(path);
    assert.equal(response.status, 301);
    assert.equal(new URL(response.headers.get("location")).pathname, destination);
  }
});

test("appeal guide renders instructions and the original DOCX template", async () => {
  const response = await render("/obzhalovanie");
  assert.equal(response.status, 200);
  const html = await response.text();
  assert.match(html, /Как зафиксировать отсутствие камеры/);
  assert.match(html, /shablon-zhaloby-kamera-otsutstvuet\.docx/);
  assert.match(html, /официальн(?:ого|ый) сайт/i);
  assert.match(html, /За рулём был другой человек/);

  const document = await readFile(new URL("../public/shablon-zhaloby-kamera-otsutstvuet.docx", import.meta.url));
  assert.ok(document.byteLength > 40_000);
});

test("appeal scenario pages render unique evidence and an editable complaint", async () => {
  const response = await render("/obzhalovanie/za-rulem-drugoy-voditel");
  assert.equal(response.status, 200);
  const html = await response.text();
  assert.match(html, /Жалоба на штраф, если за рулём был другой человек/);
  assert.match(html, /Полис ОСАГО/);
  assert.match(html, /Жалоба на постановление/);
  assert.match(html, /Статья 2\.6\.1 КоАП РФ/);
  assert.match(html, /рассмотреть настоящую жалобу в моё отсутствие/i);
});

test("missed deadline page renders a restoration petition", async () => {
  const response = await render("/obzhalovanie/vosstanovlenie-sroka");
  assert.equal(response.status, 200);
  const html = await response.text();
  assert.match(html, /Ходатайство о восстановлении срока обжалования постановления/);
  assert.match(html, /части 2 статьи 30\.3 КоАП РФ/);
  assert.match(html, /уважительной причине/);
  assert.match(html, /рассмотреть настоящее ходатайство и приложенную жалобу в моё отсутствие/i);
});

test("support buttons redirect to the project's CloudTips page", async () => {
  const response = await worker.fetch(
    new Request("http://localhost/support?amount=300"),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
  assert.equal(response.status, 302);
  assert.equal(response.headers.get("location"), "https://pay.cloudtips.ru/p/3cfb3e14");
});

test("feedback API validates and stores a camera report", async () => {
  const directory = await mkdtemp(join(tmpdir(), "gdekamera-feedback-"));
  process.env.FEEDBACK_STORAGE_DIR = directory;
  const form = new FormData();
  form.set("kind", "camera-report");
  form.set("captcha", "11");
  form.set("type", "Неверные координаты");
  form.set("description", "Проверочное обращение");
  form.set("region", "Москва");
  form.set("cameraId", "7700001");
  form.set("cameraAddress", "Тестовый адрес");
  form.set("coordinates", "55.1, 37.1");
  const response = await worker.fetch(
    new Request("http://localhost/api/feedback", { method: "POST", body: form, headers: { "x-forwarded-for": "test-" + String(Date.now()) } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
  assert.equal(response.status, 200);
  const saved = await readFile(join(directory, "inbox.jsonl"), "utf8");
  assert.match(saved, /"status":"new"/);
  assert.match(saved, /Неверные координаты/);
  await rm(directory, { recursive: true, force: true });
});

test("feedback API stores a proposed camera for moderation", async () => {
  const directory = await mkdtemp(join(tmpdir(), "gdekamera-camera-add-"));
  process.env.FEEDBACK_STORAGE_DIR = directory;
  const form = new FormData();
  form.set("kind", "camera-add");
  form.set("captcha", "11");
  form.set("region", "Москва");
  form.set("cameraAddress", "Ленинский проспект, 15");
  form.set("coordinates", "55.123456, 37.123456");
  form.set("cameraType", "Стационарная");
  form.set("violations", "Превышение скорости");
  form.set("speedLimit", "60");
  const response = await worker.fetch(
    new Request("http://localhost/api/feedback", { method: "POST", body: form, headers: { "x-forwarded-for": "camera-add-" + String(Date.now()) } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.match(body.requestId, /^\d{8}-/);
  const saved = await readFile(join(directory, "inbox.jsonl"), "utf8");
  assert.match(saved, /"kind":"camera-add"/);
  assert.match(saved, /Ленинский проспект/);
  await rm(directory, { recursive: true, force: true });
});

test("feedback API stores a service suggestion for the admin queue", async () => {
  const directory = await mkdtemp(join(tmpdir(), "gdekamera-suggestion-"));
  process.env.FEEDBACK_STORAGE_DIR = directory;
  const form = new FormData();
  form.set("kind", "service-suggestion");
  form.set("captcha", "11");
  form.set("type", "Предложение по улучшению");
  form.set("description", "Добавьте новый полезный режим карты для водителей.");
  const response = await worker.fetch(
    new Request("http://localhost/api/feedback", { method: "POST", body: form, headers: { "x-forwarded-for": "suggestion-" + String(Date.now()) } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
  assert.equal(response.status, 200);
  const saved = await readFile(join(directory, "inbox.jsonl"), "utf8");
  assert.match(saved, /"kind":"service-suggestion"/);
  assert.match(saved, /Предложение по улучшению/);
  await rm(directory, { recursive: true, force: true });
});

test("regional subscriptions can be created and cancelled", async () => {
  const directory = await mkdtemp(join(tmpdir(), "gdekamera-subscriptions-"));
  process.env.FEEDBACK_STORAGE_DIR = directory;
  const response = await worker.fetch(new Request("http://localhost/api/subscriptions", { method: "POST", headers: { "content-type": "application/json", "x-forwarded-for": "subscription-" + String(Date.now()) }, body: JSON.stringify({ email: "driver@example.ru", regionCode: "58", regionName: "Пензенская область", consent: true }) }), { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } }, { waitUntil() {}, passThroughOnException() {} });
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.match(body.unsubscribeUrl, /^\/notifications\/unsubscribe\?token=/);
  const stored = JSON.parse(await readFile(join(directory, "subscriptions.json"), "utf8"));
  assert.equal(stored[0].status, "pending");
  const token = new URL(body.unsubscribeUrl, "http://localhost").searchParams.get("token");
  const confirmed = await worker.fetch(new Request(`http://localhost/api/subscriptions?token=${token}`, { method: "PUT" }), { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } }, { waitUntil() {}, passThroughOnException() {} });
  assert.equal(confirmed.status, 200);
  const cancelled = await worker.fetch(new Request(`http://localhost/api/subscriptions?token=${token}`, { method: "DELETE" }), { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } }, { waitUntil() {}, passThroughOnException() {} });
  assert.equal(cancelled.status, 200);
  const updated = JSON.parse(await readFile(join(directory, "subscriptions.json"), "utf8"));
  assert.equal(updated[0].status, "unsubscribed");
  await rm(directory, { recursive: true, force: true });
});

test("regional update is reviewed before publication and recorded in history", async () => {
  const directory = await mkdtemp(join(tmpdir(), "gdekamera-updates-"));
  process.env.FEEDBACK_STORAGE_DIR = directory;
  process.env.ADMIN_FEEDBACK_TOKEN = "test-admin-token";
  process.env.RESEND_API_KEY = "test-resend-key";
  process.env.NOTIFICATION_FROM_EMAIL = "Где камера <updates@gdekamera.ru>";
  const headers = { authorization: "Bearer test-admin-token", "content-type": "application/json" };
  const env = { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } };
  const ctx = { waitUntil() {}, passThroughOnException() {} };
  const created = await worker.fetch(new Request("http://localhost/api/admin/updates", { method: "POST", headers, body: JSON.stringify({ regionCode: "58", regionName: "Пензенская область", added: 12, changed: 5, removed: 2, sourceDate: "2026-09-02", sourceName: "Официальный перечень Госавтоинспекции", sourceUrl: "https://гибдд.рф/" }) }), env, ctx);
  assert.equal(created.status, 200);
  const createdBody = await created.json();
  assert.equal(createdBody.update.status, "draft");
  const published = await worker.fetch(new Request("http://localhost/api/admin/updates", { method: "PATCH", headers, body: JSON.stringify({ id: createdBody.update.id, action: "publish" }) }), env, ctx);
  assert.equal(published.status, 200);
  const saved = JSON.parse(await readFile(join(directory, "region-updates.json"), "utf8"));
  assert.equal(saved[0].status, "published");
  assert.equal(saved[0].added, 12);
  assert.equal(saved[0].changed, 5);
  assert.equal(saved[0].removed, 2);
  await rm(directory, { recursive: true, force: true });
});

test("mobile map controls stay compact and include a collapse control", async () => {
  const source = await readFile(new URL("../app/roadcam-app.tsx", import.meta.url), "utf8");
  const css = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
  assert.match(source, /panel-collapse-button/);
  assert.match(source, /Свернуть настройки карты/);
  assert.doesNotMatch(source, /<small>Обычные камеры<\/small>/);
  assert.match(css, /\.filter-toggle \{[\s\S]*min-height:76px/);
  assert.match(css, /max-width:calc\(100vw - 20px\)/);
});

test("driver assistant contains two spoken thresholds and camera guidance", async () => {
  const source = await readFile(new URL("../app/roadcam-app.tsx", import.meta.url), "utf8");
  assert.match(source, /distance <= 300/);
  assert.match(source, /Через 300 метров камера/);
  assert.match(source, /distance <= 100/);
  assert.match(source, /Через 100 метров камера/);
  assert.match(source, /L\.polyline\(\[\[latitude, longitude\], \[camera\.lat, camera\.lng\]\]/);
  assert.doesNotMatch(source, /createOscillator/);
});

test("violation catalog separates sign 2.5 from the traffic-light stop line", async () => {
  const source = await readFile(new URL("../app/violation-catalog.ts", import.meta.url), "utf8");
  const mapSource = await readFile(new URL("../app/roadcam-app.tsx", import.meta.url), "utf8");
  assert.match(source, /Проезд без остановки перед знаком 2\.5 «STOP»/);
  assert.match(source, /Выезд за стоп-линию на запрещающий сигнал/);
  assert.match(source, /знак\[а-яё\]\*\\s\*2\[\.,\]5/);
  assert.match(source, /excludes: \[\/знак\\s\*2/);
  assert.doesNotMatch(source, /"Выезд за стоп-линию",/);
  assert.match(mapSource, /key: "stop-sign"/);
  assert.match(mapSource, /label: "Знак 2\.5 STOP"/);
});

test("home page has responsive search and native sharing", async () => {
  const response = await render("/");
  const html = await response.text();
  const css = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
  const shareSource = await readFile(new URL("../app/share-site-button.tsx", import.meta.url), "utf8");
  assert.equal(response.status, 200);
  assert.match(html, /Поделиться сайтом/);
  assert.match(shareSource, /navigator\.share/);
  assert.match(shareSource, /navigator\.clipboard\.writeText/);
  assert.match(css, /\.global-camera-search \{ grid-template-columns:minmax\(0,1fr\)/);
  assert.match(css, /\.filter-violation-option/);
  assert.match(css, /\.filter-toggle-icons/);
});

test("truck mode has verified weight-control data and spoken warnings", async () => {
  const controls = JSON.parse(await readFile(new URL("../public/weight-control/22.json", import.meta.url), "utf8"));
  assert.equal(controls.regionName, "Алтайский край");
  assert.match(controls.lastVerified, /^2026-/);
  assert.ok(controls.controls.length >= 10);
  assert.ok(controls.controls.every((item) => item.controlType === "АПВГК" && Number.isFinite(item.cameraId)));
  const source = await readFile(new URL("../app/roadcam-app.tsx", import.meta.url), "utf8");
  assert.match(source, /roadcam-vehicle-mode/);
  assert.match(source, /Через 300 метров.*весогабаритного контроля/);
  assert.match(source, /Через 100 метров весогабаритный контроль/);
});

test("moderation API requires the administrator token", async () => {
  process.env.ADMIN_FEEDBACK_TOKEN = "test-admin-token";
  const response = await worker.fetch(
    new Request("http://localhost/api/admin/feedback"),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
  assert.equal(response.status, 401);
});

test("moderator can edit, publish and unpublish a proposed camera", async () => {
  const directory = await mkdtemp(join(tmpdir(), "gdekamera-moderation-"));
  process.env.FEEDBACK_STORAGE_DIR = directory;
  process.env.ADMIN_FEEDBACK_TOKEN = "test-admin-token";
  const id = "20260829-testcam";
  await writeFile(join(directory, "inbox.jsonl"), `${JSON.stringify({ id, createdAt: new Date().toISOString(), status: "new", kind: "camera-add", region: "Москва" })}\n`);
  const fields = { region: "Москва", cameraAddress: "Тестовая камера", coordinates: "55.123456, 37.123456", cameraType: "Стационарная", violations: "Превышение скорости", speedLimit: "60" };
  const publish = await worker.fetch(new Request("http://localhost/api/admin/feedback", { method: "PATCH", headers: { authorization: "Bearer test-admin-token", "content-type": "application/json" }, body: JSON.stringify({ id, action: "publish", fields }) }), { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } }, { waitUntil() {}, passThroughOnException() {} });
  assert.equal(publish.status, 200);
  const publicResponse = await worker.fetch(new Request("http://localhost/api/cameras?region=" + encodeURIComponent("Москва")), { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } }, { waitUntil() {}, passThroughOnException() {} });
  const publicData = await publicResponse.json();
  assert.equal(publicData.cameras.length, 1);
  assert.equal(publicData.cameras[0].address, "Тестовая камера");
  const unpublish = await worker.fetch(new Request("http://localhost/api/admin/feedback", { method: "PATCH", headers: { authorization: "Bearer test-admin-token", "content-type": "application/json" }, body: JSON.stringify({ id, action: "unpublish" }) }), { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } }, { waitUntil() {}, passThroughOnException() {} });
  assert.equal(unpublish.status, 200);
  const saved = JSON.parse(await readFile(join(directory, "published-cameras.json"), "utf8"));
  assert.equal(saved[id], undefined);
  await rm(directory, { recursive: true, force: true });
});
