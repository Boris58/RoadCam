"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import officialRegionsData from "../public/official-regions-summary.json";

type LocationStatus = "offer" | "locating" | "found" | "error";
type OfficialRegionSummary = Record<string, { code: string; name: string; count: number; sourceDate: string }>;

const OFFER_KEY = "gdekamera:location-offer-v1";
const REGION_KEY = "gdekamera:location-region-v1";
const officialRegions = officialRegionsData as OfficialRegionSummary;

const availableRegionCenters: Record<string, [number, number]> = {
  "01":[44.75579,39.71366],"02":[54.46814,55.93619],"03":[51.94629,107.47103],"04":[51.68075,85.93091],"05":[42.89284,47.37692],"06":[43.27893,44.83081],"07":[43.58066,43.63283],
  "10":[62.02316,33.62996],"11":[59.97235,54.33868],"13":[54.22524,44.989],"15":[43.16676,44.55318],"16":[55.56256,50.40593],"17":[51.59128,94.0754],"19":[53.65233,89.66727],
  "22":[53.05287,83.30856],"23":[43.23327,42.7491],"25":[43.11547,131.91267],"26":[44.76304,42.56005],"27":[48.82847,135.56386],"29":[63.45687,41.73642],
  "31":[51.44013,37.91655],"32":[53.16313,34.07971],"34":[49.10905,44.28837],"35":[59.47497,45.30166],"36":[51.53205,39.45712],"37":[56.99708,41.11274],
  "38":[53.03388,75.59447],"40":[54.69042,36.24295],"41":[53.11944,158.45335],"42":[54.71939,86.58528],"43":[58.3137,49.70275],"44":[57.83508,41.79332],
  "45":[55.50756,64.87992],"46":[51.7613,36.07431],"47":[59.86025,30.08199],"48":[52.59077,39.42078],"50":[55.55,37.75],"51":[68.59695,33.07501],
  "52":[56.1822,43.8849],"53":[58.34021,32.03745],"54":[54.99459,82.80242],"55":[55.10555,73.31539],"56":[51.88337,55.18927],"57":[52.91608,36.22414],
  "58":[53.12,45.15],"59":[58.05068,56.72068],"60":[56.77782,29.74287],"61":[47.36524,40.01224],"63":[53.29332,50.01237],"65":[46.96308,142.69575],
  "66":[57.08187,60.67713],"68":[52.69114,41.3794],"69":[56.86112,35.54051],"71":[54.12822,37.75095],"72":[60.52076,63.52317],"73":[54.21545,48.4179],
  "74":[54.84184,60.76606],"75":[51.7961,113.929],"76":[57.71164,39.38013],"77":[55.751244,37.618423],"78":[59.89586,30.29784],"79":[48.72532,132.94962],
};

const legacyRegions: Record<string, { name: string; count: number }> = {
  "50": { name: "Московская область", count: 2149 },
  "58": { name: "Пензенская область", count: 210 },
};

function regionHref(code: string) {
  return `/region/${code}`;
}

function distanceKm(latitude: number, longitude: number, center: [number, number]) {
  const toRadians = (value: number) => value * Math.PI / 180;
  const latDelta = toRadians(center[0] - latitude);
  const lngDelta = toRadians(center[1] - longitude);
  const a = Math.sin(latDelta / 2) ** 2 + Math.cos(toRadians(latitude)) * Math.cos(toRadians(center[0])) * Math.sin(lngDelta / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export default function LocationOffer() {
  const [visible, setVisible] = useState(false);
  const [status, setStatus] = useState<LocationStatus>("offer");
  const [regionCode, setRegionCode] = useState<string | null>(null);

  useEffect(() => {
    try {
      if (!window.localStorage.getItem(OFFER_KEY)) {
        const timer = window.setTimeout(() => setVisible(true), 650);
        return () => window.clearTimeout(timer);
      }
    } catch {
      const timer = window.setTimeout(() => setVisible(true), 650);
      return () => window.clearTimeout(timer);
    }
  }, []);

  const rememberOffer = (value: string) => {
    try { window.localStorage.setItem(OFFER_KEY, value); } catch { /* private mode may block storage */ }
  };

  const dismiss = () => {
    rememberOffer("dismissed");
    setVisible(false);
  };

  const locate = () => {
    rememberOffer("requested");
    if (!("geolocation" in navigator)) {
      setStatus("error");
      return;
    }
    setStatus("locating");
    navigator.geolocation.getCurrentPosition((position) => {
      const nearest = Object.entries(availableRegionCenters).reduce((best, [code, center]) => {
        const distance = distanceKm(position.coords.latitude, position.coords.longitude, center);
        return distance < best.distance ? { code, distance } : best;
      }, { code: "58", distance: Number.POSITIVE_INFINITY });
      setRegionCode(nearest.code);
      setStatus("found");
      try { window.localStorage.setItem(REGION_KEY, nearest.code); } catch { /* location remains only in component state */ }
    }, () => setStatus("error"), { enableHighAccuracy: false, timeout: 10000, maximumAge: 900000 });
  };

  if (!visible) return null;
  const region = regionCode ? (officialRegions[regionCode] ?? legacyRegions[regionCode]) : null;

  return <aside className="location-offer" role="dialog" aria-modal="false" aria-labelledby="location-offer-title">
    <button className="location-offer-close" type="button" onClick={dismiss} aria-label="Закрыть предложение">×</button>
    <div className="location-offer-icon" aria-hidden="true"><span /></div>
    {status === "offer" && <div className="location-offer-copy">
      <span>Камеры рядом</span>
      <h2 id="location-offer-title">Определить ваш регион?</h2>
      <p>Покажем ближайший доступный регион с камерами. Геопозиция обрабатывается только в вашем браузере и не передаётся на сервер.</p>
      <div><button type="button" onClick={locate}>Определить местоположение</button><button type="button" onClick={dismiss}>Не определять</button></div>
    </div>}
    {status === "locating" && <div className="location-offer-copy locating"><span>Определяем местоположение</span><h2 id="location-offer-title">Подтвердите доступ в браузере</h2><p>Обычно это занимает несколько секунд.</p><i /></div>}
    {status === "found" && region && regionCode && <div className="location-offer-copy">
      <span>Ближайший доступный регион</span><h2 id="location-offer-title">{region.name}</h2><p>На карте опубликовано {region.count.toLocaleString("ru-RU")} камер и комплексов фиксации.</p>
      <div><Link href={regionHref(regionCode)} onClick={() => setVisible(false)}>Открыть карту региона</Link><button type="button" onClick={dismiss}>Остаться на главной</button></div>
    </div>}
    {status === "error" && <div className="location-offer-copy">
      <span>Местоположение не определено</span><h2 id="location-offer-title">Выберите регион вручную</h2><p>Доступ мог быть запрещён в настройках браузера. Все функции сайта продолжат работать.</p>
      <div><button type="button" onClick={dismiss}>Понятно</button></div>
    </div>}
  </aside>;
}
