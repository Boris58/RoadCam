"use client";

import { useEffect } from "react";

const COUNTER_ID = 112081610;

type YmFunction = ((id: number, method: string, ...args: unknown[]) => void) & { a?: unknown[][]; l?: number };

export default function YandexMetrika() {
  useEffect(() => {
    const metrikaWindow = window as typeof window & { ym?: YmFunction; __roadcamMetrika?: boolean };
    metrikaWindow.ym ??= Object.assign(((...args: unknown[]) => { (metrikaWindow.ym!.a ??= []).push(args); }) as YmFunction, { l: Date.now() });
    if (!document.querySelector('script[src^="https://mc.yandex.ru/metrika/tag.js"]')) {
      const script = document.createElement("script");
      script.async = true;
      script.src = `https://mc.yandex.ru/metrika/tag.js?id=${COUNTER_ID}`;
      document.head.appendChild(script);
    }
    if (!metrikaWindow.__roadcamMetrika) {
      metrikaWindow.__roadcamMetrika = true;
      metrikaWindow.ym(COUNTER_ID, "init", { defer: true, ssr: true, clickmap: true, accurateTrackBounce: true, trackLinks: true });
    }

    let previousUrl = "";
    const hit = () => window.setTimeout(() => {
      const currentUrl = window.location.href;
      if (currentUrl === previousUrl) return;
      metrikaWindow.ym?.(COUNTER_ID, "hit", currentUrl, { referer: previousUrl || document.referrer, title: document.title });
      previousUrl = currentUrl;
    }, 0);
    const originalPush = history.pushState, originalReplace = history.replaceState;
    history.pushState = function (...args) { originalPush.apply(this, args); hit(); };
    history.replaceState = function (...args) { originalReplace.apply(this, args); hit(); };
    window.addEventListener("popstate", hit);
    hit();
    return () => { history.pushState = originalPush; history.replaceState = originalReplace; window.removeEventListener("popstate", hit); };
  }, []);

  return null;
}
