import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { cameraCatalog, findCamera } from "../../../camera-catalog";
import { jsonLd } from "../../../seo";

type PageProps = { params: Promise<{ region: string; id: string }> };

export function generateStaticParams() { return []; }

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { region, id } = await params;
  const camera = findCamera(region, Number(id));
  if (!camera) return { title: "Камера не найдена", robots: { index: false, follow: false } };
  const title = `Камера ГИБДД: ${camera.a}`;
  const description = `${camera.r}. Адрес, координаты и нарушения, фиксируемые камерой: ${camera.v.join(", ")}. Открыть точку на карте.`;
  const path = `/camera/${camera.c}/${camera.i}`;
  return { title, description, alternates: { canonical: path }, openGraph: { type: "website", locale: "ru_RU", url: path, title, description }, twitter: { card: "summary", title, description } };
}

export default async function CameraPage({ params }: PageProps) {
  const { region, id } = await params;
  const camera = findCamera(region, Number(id));
  if (!camera) notFound();
  const nearby = cameraCatalog.filter((item) => item.c === camera.c && item.i !== camera.i && Math.abs(item.x - camera.x) < .03 && Math.abs(item.y - camera.y) < .04).slice(0, 6);
  const schema = { "@context": "https://schema.org", "@type": "Place", name: `Камера ГИБДД: ${camera.a}`, description: `Камера фотовидеофиксации в регионе ${camera.r}`, url: `https://xn--80aahefb7ar1b.xn--p1ai/camera/${camera.c}/${camera.i}`, geo: { "@type": "GeoCoordinates", latitude: camera.x, longitude: camera.y }, address: { "@type": "PostalAddress", addressRegion: camera.r, streetAddress: camera.a } };
  return <main className="seo-detail-page">
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd(schema) }} />
    <header className="legal-topbar"><Link className="brand" href="/"><span className="brand-mark" aria-hidden="true"><span /></span><span className="brand-name">Где <span>камера</span></span></Link><Link href={`/region/${camera.c}`}>{camera.r}</Link></header>
    <article className="seo-detail-article">
      <nav className="legal-breadcrumbs"><Link href="/">Главная</Link><span>→</span><Link href={`/region/${camera.c}`}>{camera.r}</Link><span>→</span><span>Камера № {camera.i}</span></nav>
      <span className="legal-kicker">Камера фотовидеофиксации · № {camera.i}</span>
      <h1>{camera.a}</h1>
      <p className="seo-detail-lead">Камера ГИБДД на карте: адрес, координаты и перечень контролируемых нарушений.</p>
      <section className="camera-fact-grid"><div><small>Регион</small><b>{camera.r}</b></div><div><small>Координаты</small><b>{camera.x.toFixed(6)}, {camera.y.toFixed(6)}</b></div><div><small>Количество видов контроля</small><b>{camera.v.length}</b></div></section>
      <section><h2>Какие нарушения фиксирует камера</h2><ul className="seo-violation-list">{camera.v.map((violation) => <li key={violation}>{violation}</li>)}</ul></section>
      <Link className="open-camera-map" href={`/region/${camera.c}?camera=${camera.i}`}><span>⌖</span><div><b>Показать эту камеру на карте</b><small>Карта приблизится к точке и откроет карточку камеры</small></div><strong>→</strong></Link>
      <Link className="camera-guide-card" href="/spravochnik/kak-proverit-zakonnost-kamery-gibdd"><span>Пошаговая инструкция</span><b>Как проверить законность камеры ГИБДД</b><small>Официальный перечень, заводской номер, поверка и материалы постановления →</small></Link>
      {nearby.length > 0 && <section><h2>Другие камеры рядом</h2><div className="nearby-camera-links">{nearby.map((item) => <Link key={item.i} href={`/camera/${item.c}/${item.i}`}><b>{item.a}</b><small>{item.v.slice(0, 2).join(" · ")}</small></Link>)}</div></section>}
      <p className="seo-data-note">Данные предназначены для справочной проверки. Перед использованием в обращении сверяйте сведения с актуальным официальным перечнем региона.</p>
    </article>
  </main>;
}
