import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { findGuideArticle, guideArticles } from "../../guide-articles";
import { jsonLd } from "../../seo";

type PageProps = { params: Promise<{ slug: string }> };

export function generateStaticParams() { return guideArticles.map(({ slug }) => ({ slug })); }

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const article = findGuideArticle((await params).slug);
  if (!article) return { title: "Инструкция не найдена", robots: { index: false, follow: false } };
  const path = `/spravochnik/${article.slug}`;
  return {
    title: article.title,
    description: article.description,
    alternates: { canonical: path },
    openGraph: { type: "article", locale: "ru_RU", url: path, title: article.title, description: article.description },
    twitter: { card: "summary", title: article.title, description: article.description },
  };
}

export default async function GuideArticlePage({ params }: PageProps) {
  const article = findGuideArticle((await params).slug);
  if (!article) notFound();
  const url = `https://xn--80aahefb7ar1b.xn--p1ai/spravochnik/${article.slug}`;
  const schemas = [
    { "@context": "https://schema.org", "@type": "Article", headline: article.title, description: article.description, inLanguage: "ru-RU", mainEntityOfPage: url, author: { "@type": "Organization", name: "Где камера" }, publisher: { "@type": "Organization", name: "Где камера" } },
    { "@context": "https://schema.org", "@type": "BreadcrumbList", itemListElement: [
      { "@type": "ListItem", position: 1, name: "Главная", item: "https://xn--80aahefb7ar1b.xn--p1ai/" },
      { "@type": "ListItem", position: 2, name: "Справочник", item: "https://xn--80aahefb7ar1b.xn--p1ai/spravochnik" },
      { "@type": "ListItem", position: 3, name: article.shortTitle, item: url },
    ] },
    { "@context": "https://schema.org", "@type": "FAQPage", mainEntity: article.faq.map((item) => ({ "@type": "Question", name: item.question, acceptedAnswer: { "@type": "Answer", text: item.answer } })) },
  ];

  return <main className="guide-page">
    {schemas.map((schema, index) => <script key={index} type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd(schema) }} />)}
    <header className="legal-topbar guide-topbar">
      <Link className="brand" href="/" aria-label="Где камера — главная"><span className="brand-mark" aria-hidden="true"><span /></span><span className="brand-name">Где <span>камера</span></span></Link>
      <nav><Link href="/spravochnik">Все инструкции</Link><Link href="/obzhalovanie">Обжаловать штраф</Link></nav>
    </header>

    <article className="guide-article">
      <nav className="legal-breadcrumbs" aria-label="Хлебные крошки"><Link href="/">Главная</Link><span>›</span><Link href="/spravochnik">Справочник</Link><span>›</span><span>{article.shortTitle}</span></nav>
      <span className="legal-kicker">{article.kicker}</span>
      <h1>{article.title}</h1>
      <p className="guide-lead">{article.lead}</p>
      <div className="guide-meta"><span>Время чтения: {article.readingTime}</span><span>Пошаговая инструкция</span></div>

      {article.officialLinks && <section className="official-registry-links" aria-label="Официальные реестры">
        {article.officialLinks.map((item) => <a key={item.href} href={item.href} target="_blank" rel="noreferrer"><span>Официальный источник</span><b>{item.label} ↗</b><small>{item.note}</small></a>)}
      </section>}

      {article.steps && <section><h2>Как проверить: пошагово</h2><ol className="guide-steps">{article.steps.map((step, index) => <li key={step.title}><span>{index + 1}</span><div><h3>{step.title}</h3><p>{step.text}</p></div></li>)}</ol></section>}

      {article.sections.map((section) => <section key={section.title}>
        <h2>{section.title}</h2>
        {section.paragraphs?.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
        {section.points && <ul className="guide-point-list">{section.points.map((point) => <li key={point}>{point}</li>)}</ul>}
        {section.warning && <aside className="guide-warning"><strong>Важно</strong><span>{section.warning}</span></aside>}
      </section>)}

      <section className="guide-faq"><h2>Частые вопросы</h2>{article.faq.map((item) => <details key={item.question}><summary>{item.question}</summary><p>{item.answer}</p></details>)}</section>
      <aside className="guide-next-action"><div><strong>Нужно проверить конкретную камеру?</strong><p>Найдите её на карте, сохраните адрес и координаты, затем сопоставьте сведения с постановлением и официальными источниками.</p></div><Link href="/">Найти камеру</Link></aside>
      <p className="legal-disclaimer">Материал носит информационный характер и не является индивидуальной юридической консультацией. Отсутствие записи при одном варианте поиска не доказывает отсутствие поверки или законных оснований применения комплекса.</p>
    </article>
  </main>;
}
