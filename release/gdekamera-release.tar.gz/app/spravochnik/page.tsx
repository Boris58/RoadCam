import type { Metadata } from "next";
import Link from "next/link";
import { guideArticles } from "../guide-articles";
import { jsonLd } from "../seo";

export const metadata: Metadata = {
  title: "Справочник водителя: камеры ГИБДД, поверка и штрафы",
  description: "Пошаговые инструкции: как проверить поверку камеры ГИБДД, найти камеру по адресу, сверить её с официальным перечнем и проверить штраф.",
  alternates: { canonical: "/spravochnik" },
  openGraph: {
    type: "website",
    locale: "ru_RU",
    url: "/spravochnik",
    title: "Справочник водителя | Где камера",
    description: "Практические инструкции по проверке дорожных камер, поверки и постановлений.",
  },
};

export default function GuideIndexPage() {
  const schema = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: "Справочник водителя",
    url: "https://xn--80aahefb7ar1b.xn--p1ai/spravochnik",
    hasPart: guideArticles.map((article) => ({
      "@type": "Article",
      headline: article.title,
      url: `https://xn--80aahefb7ar1b.xn--p1ai/spravochnik/${article.slug}`,
    })),
  };

  return <main className="guide-page">
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd(schema) }} />
    <header className="legal-topbar guide-topbar">
      <Link className="brand" href="/" aria-label="Где камера — главная"><span className="brand-mark" aria-hidden="true"><span /></span><span className="brand-name">Где <span>камера</span></span></Link>
      <nav><Link href="/">Карта</Link><Link href="/obzhalovanie">Обжаловать штраф</Link></nav>
    </header>

    <section className="guide-hero">
      <nav className="legal-breadcrumbs" aria-label="Хлебные крошки"><Link href="/">Главная</Link><span>›</span><span>Справочник</span></nav>
      <span className="legal-kicker">Проверка камер и штрафов</span>
      <h1>Справочник водителя</h1>
      <p>Короткие пошаговые инструкции: как найти дорожную камеру, проверить официальный перечень, метрологическую поверку и материалы постановления.</p>
    </section>

    <section className="guide-index" aria-label="Все инструкции">
      <div className="guide-card-grid">
        {guideArticles.map((article, index) => <Link key={article.slug} href={`/spravochnik/${article.slug}`}>
          <span>{String(index + 1).padStart(2, "0")} · {article.readingTime}</span>
          <h2>{article.shortTitle}</h2>
          <p>{article.description}</p>
          <b>Открыть инструкцию →</b>
        </Link>)}
      </div>
      <aside className="guide-quick-check"><div><strong>Получили штраф?</strong><p>Сначала сохраните постановление, дату получения, фотографии и сведения о комплексе. Для обжалования действует ограниченный срок.</p></div><Link href="/obzhalovanie">Перейти к шаблонам жалоб</Link></aside>
    </section>
  </main>;
}
