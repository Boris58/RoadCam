"use client";
import { useMemo, useRef, useState } from "react";
import Link from "next/link";
import { reachMetrikaGoal } from "./metrika-goal";

type SearchCamera = { c:string; r:string; i:number; a:string; x:number; y:number; v:string[] };
let indexCache: SearchCamera[] | null = null;
async function loadIndex(){ if(indexCache)return indexCache; const response=await fetch("/camera-search-index.json"); if(!response.ok)throw new Error("index"); indexCache=await response.json() as SearchCamera[]; return indexCache; }
function distance(lat:number,lng:number,camera:SearchCamera){const r=Math.PI/180;const dLat=(camera.x-lat)*r,dLng=(camera.y-lng)*r;const a=Math.sin(dLat/2)**2+Math.cos(lat*r)*Math.cos(camera.x*r)*Math.sin(dLng/2)**2;return 6371000*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));}
function formatDistance(value:number){return value<1000?`${Math.round(value)} м`:`${(value/1000).toFixed(1)} км`;}
function normalizeSearch(value:string){return value.toLocaleLowerCase("ru").replaceAll("ё","е").replace(/[^а-яa-z0-9]+/giu," ").trim();}
function searchTokens(value:string){return normalizeSearch(value).split(/\s+/).filter(token=>token.length>=2||/^\d+$/.test(token));}
function relevance(item:SearchCamera,tokens:string[]){
 const address=normalizeSearch(item.a),region=normalizeSearch(item.r),id=String(item.i),haystack=`${address} ${region} ${id}`;
 if(!tokens.every(token=>haystack.includes(token)))return -1;
 const phrase=tokens.join(" ");
 return (address.includes(phrase)?100:0)+(region.includes(phrase)?40:0)+tokens.reduce((score,token)=>score+(address.startsWith(token)?8:0)+(address.includes(` ${token}`)?3:0),0);
}

export default function CameraGlobalSearch(){
 const[query,setQuery]=useState("");const[index,setIndex]=useState<SearchCamera[]>([]);const[loading,setLoading]=useState(false);const[error,setError]=useState("");const[nearby,setNearby]=useState<Array<SearchCamera&{distance:number}>>([]);
 const searchTracked=useRef(false);
 const ensure=async()=>{if(index.length)return index;setLoading(true);try{const data=await loadIndex();setIndex(data);return data;}finally{setLoading(false);}};
 const normalized=normalizeSearch(query),tokens=useMemo(()=>searchTokens(query),[query]);
 const results=useMemo(()=>normalized.length<3||tokens.length===0?[]:index.map(item=>({item,score:relevance(item,tokens)})).filter(result=>result.score>=0).sort((a,b)=>b.score-a.score).slice(0,8).map(result=>result.item),[index,normalized,tokens]);
 const change=async(value:string)=>{setQuery(value);setNearby([]);setError("");if(value.trim().length>=3&&!searchTracked.current){searchTracked.current=true;reachMetrikaGoal("camera_search");}if(value.trim().length>=3&&!index.length)try{await ensure();}catch{setError("Не удалось загрузить поиск. Попробуйте позже.");}};
 const locate=async(mode:"locate"|"warning")=>{reachMetrikaGoal(mode==="locate"?"my_location":"camera_alerts",{surface:"home"});setError("");setQuery("");if(!navigator.geolocation)return setError("Браузер не поддерживает геолокацию.");setLoading(true);navigator.geolocation.getCurrentPosition(async pos=>{try{const data=await loadIndex();setIndex(data);const closest=data.map(item=>({...item,distance:distance(pos.coords.latitude,pos.coords.longitude,item)})).sort((a,b)=>a.distance-b.distance);setNearby(closest.slice(0,8));if(closest[0])window.location.href=`/region/${closest[0].c}?drive=${mode}`;else setError("Рядом нет опубликованных камер.");}catch{setError("Не удалось загрузить список камер.");setLoading(false);}},()=>{setLoading(false);setError("Доступ к местоположению не предоставлен.");},{timeout:15000,maximumAge:300000,enableHighAccuracy:true});};
 const shown=nearby.length?nearby:results;
 return <section className="global-camera-search" aria-labelledby="global-camera-search-title"><div><h2 id="global-camera-search-title">Найдите камеру по адресу</h2><p>Введите несколько слов в любом порядке — например, «Пенза Марта».</p></div><div className="global-camera-search-control"><label><i/><input value={query} onChange={e=>void change(e.target.value)} placeholder="Например: Пенза Марта"/>{query&&<button onClick={()=>setQuery("")} aria-label="Очистить">×</button>}</label><button className="nearby-button" onClick={()=>void locate("locate")} disabled={loading}><b>⌖</b>{loading?"Определяем…":"Моё местоположение"}</button><button className="home-warning-button" onClick={()=>void locate("warning")} disabled={loading}><b>◉</b>Предупреждать о камерах</button>{normalized.length>0&&normalized.length<3&&<small>Введите минимум 3 символа</small>}{error&&<small className="search-error">{error}</small>}{shown.length>0&&<div className="global-search-results">{shown.map(item=><Link key={`${item.c}-${item.i}`} href={`/region/${item.c}?camera=${item.i}`}><span>{item.c}</span><div><b>{item.a}</b><small>{item.r}{"distance" in item?` · ${formatDistance(item.distance)}`:""}</small><em>{item.v.slice(0,2).join(" · ")}</em></div><strong>→</strong></Link>)}</div>}{normalized.length>=3&&!loading&&index.length>0&&results.length===0&&<div className="global-search-empty">Камеры по этим словам не найдены. Попробуйте убрать одно из слов.</div>}</div></section>;
}
