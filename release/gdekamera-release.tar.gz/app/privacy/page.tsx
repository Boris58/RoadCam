import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = { title: "Обработка персональных данных", robots: { index: true, follow: true } };

export default function PrivacyPage() {
  return <main className="legal-page"><header className="legal-topbar"><Link className="brand" href="/"><span className="brand-mark" aria-hidden="true"><span /></span><span className="brand-name">Где <span>камера</span></span></Link><Link href="/">На главную</Link></header><article><span className="eyebrow">Конфиденциальность</span><h1>Обработка персональных данных</h1><p>При подписке на обновления проект «Где камера» сохраняет адрес электронной почты и выбранный регион. Эти сведения используются только для уведомлений об изменениях базы камер.</p><h2>Какие данные хранятся</h2><p>Адрес электронной почты, код и название выбранного региона, дата подписки и дата последней отправки. Пароль и платёжные данные не запрашиваются.</p><h2>Как отказаться</h2><p>В уведомлении предусмотрена персональная ссылка для отключения рассылки. После её использования подписка становится неактивной.</p><h2>Защита данных</h2><p>Список подписчиков хранится на сервере проекта и доступен только администратору. Адреса не публикуются и не используются для сторонней рекламы.</p><p><Link href="/notifications">Вернуться к подписке на обновления</Link></p></article></main>;
}
