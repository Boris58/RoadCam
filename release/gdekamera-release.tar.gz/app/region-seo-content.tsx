import Link from "next/link";
import { regionLocative } from "./seo";

type Stats = {
  sourceDate?: string;
  sourceUrl?: string;
  types?: { stationary?: number; portable?: number; dummy?: number; unspecified?: number };
  topViolations?: Array<{ name: string; count: number }>;
};

export default function RegionSeoContent({ name, code, count, sourceDate, stats }: { name:string; code:string; count:number; sourceDate:string; stats?:Stats }) {
  const stationary=stats?.types?.stationary??0; const portable=stats?.types?.portable??0; const violations=stats?.topViolations??[];
  return <section className="region-seo-content" aria-labelledby={`region-info-${code}`}>
    <div className="region-seo-heading"><span className="eyebrow">Сведения о регионе</span><h2 id={`region-info-${code}`}>Камеры фотовидеофиксации в {regionLocative(name)}</h2><p>На интерактивной карте опубликовано {count.toLocaleString("ru-RU")} камер и комплексов. Данные помогают найти точку по адресу, сверить координаты и проверить, какие нарушения указаны для конкретного комплекса.</p></div>
    <div className="region-seo-stats"><div><strong>{count.toLocaleString("ru-RU")}</strong><span>объектов в базе</span></div><div><strong>{stationary.toLocaleString("ru-RU")}</strong><span>стационарных</span></div><div><strong>{portable.toLocaleString("ru-RU")}</strong><span>передвижных</span></div><div><strong>{stats?.sourceDate||sourceDate}</strong><span>дата исходных данных</span></div></div>
    <div className="region-seo-grid"><article><h3>Что можно проверить</h3><p>Откройте карточку камеры, чтобы увидеть адрес, направление контроля, ограничение скорости и перечень фиксируемых нарушений. Сведения проекта носят справочный характер: для обжалования штрафа обязательно сохраните официальный перечень Госавтоинспекции на нужную дату.</p>{stats?.sourceUrl&&<a href={stats.sourceUrl} target="_blank" rel="noreferrer">Открыть официальный источник ↗</a>}</article><article><h3>Часто указанные нарушения</h3>{violations.length?<ul>{violations.map(item=><li key={item.name}><span>{item.name}</span><b>{item.count}</b></li>)}</ul>:<p>В карточках камер указаны нарушения из опубликованного перечня региона. Выберите фильтр на карте, чтобы увидеть доступные категории.</p>}</article><article><h3>Полезные инструкции</h3><p>Если камера отсутствует в официальном перечне или её параметры не совпадают с постановлением, соберите доказательства до подачи жалобы.</p><div><Link href="/spravochnik/proverit-kameru-v-oficialnom-perechne">Проверить официальный перечень</Link><Link href="/spravochnik/proverka-poverki-kamery-gibdd">Проверить поверку</Link><Link href="/obzhalovanie">Шаблоны жалоб</Link></div></article></div>
    <p className="region-seo-note">База обновляется по открытым официальным сведениям и подтверждённым сообщениям пользователей. <Link href="/notifications">Подписаться на изменения {name}</Link>.</p>
  </section>;
}
