"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { ruMill } from "@react-jvectormap/russia";
import officialRegionsData from "../public/official-regions-summary.json";
import CameraGlobalSearch from "./camera-global-search";
import { reachMetrikaGoal } from "./metrika-goal";
import SiteSuggestion from "./site-suggestion";
import ShareSiteButton from "./share-site-button";

type OfficialRegionSummary = Record<string, { code: string; name: string; count: number; sourceDate: string }>;
type MapPath = { path: string; name: string };

const officialRegions = officialRegionsData as OfficialRegionSummary;
const officialCameraCount = Object.values(officialRegions).reduce((total, region) => total + region.count, 0) + 2149 + 171;
const readyRegionCount = Object.keys(officialRegions).length + 2;

const regions = [
  ["01", "Республика Адыгея"], ["02", "Республика Башкортостан"], ["03", "Республика Бурятия"], ["04", "Республика Алтай"], ["05", "Республика Дагестан"],
  ["06", "Республика Ингушетия"], ["07", "Кабардино-Балкарская Республика"], ["08", "Республика Калмыкия"], ["09", "Карачаево-Черкесская Республика"], ["10", "Республика Карелия"],
  ["11", "Республика Коми"], ["12", "Республика Марий Эл"], ["13", "Республика Мордовия"], ["14", "Республика Саха (Якутия)"], ["15", "Республика Северная Осетия — Алания"],
  ["16", "Республика Татарстан"], ["17", "Республика Тыва"], ["18", "Удмуртская Республика"], ["19", "Республика Хакасия"], ["20", "Чеченская Республика"], ["21", "Чувашская Республика"],
  ["22", "Алтайский край"], ["23", "Краснодарский край"], ["24", "Красноярский край"], ["25", "Приморский край"], ["26", "Ставропольский край"], ["27", "Хабаровский край"],
  ["28", "Амурская область"], ["29", "Архангельская область"], ["30", "Астраханская область"], ["31", "Белгородская область"], ["32", "Брянская область"], ["33", "Владимирская область"],
  ["34", "Волгоградская область"], ["35", "Вологодская область"], ["36", "Воронежская область"], ["37", "Ивановская область"], ["38", "Иркутская область"], ["39", "Калининградская область"],
  ["40", "Калужская область"], ["41", "Камчатский край"], ["42", "Кемеровская область"], ["43", "Кировская область"], ["44", "Костромская область"], ["45", "Курганская область"],
  ["46", "Курская область"], ["47", "Ленинградская область"], ["48", "Липецкая область"], ["49", "Магаданская область"], ["50", "Московская область"], ["51", "Мурманская область"],
  ["52", "Нижегородская область"], ["53", "Новгородская область"], ["54", "Новосибирская область"], ["55", "Омская область"], ["56", "Оренбургская область"], ["57", "Орловская область"],
  ["58", "Пензенская область"], ["59", "Пермский край"], ["60", "Псковская область"], ["61", "Ростовская область"], ["62", "Рязанская область"], ["63", "Самарская область"],
  ["64", "Саратовская область"], ["65", "Сахалинская область"], ["66", "Свердловская область"], ["67", "Смоленская область"], ["68", "Тамбовская область"], ["69", "Тверская область"],
  ["70", "Томская область"], ["71", "Тульская область"], ["72", "Тюменская область"], ["73", "Ульяновская область"], ["74", "Челябинская область"], ["75", "Забайкальский край"],
  ["76", "Ярославская область"], ["77", "Москва"], ["78", "Санкт-Петербург"], ["79", "Еврейская автономная область"], ["83", "Ненецкий автономный округ"], ["86", "Ханты-Мансийский автономный округ"],
  ["87", "Чукотский автономный округ"], ["89", "Ямало-Ненецкий автономный округ"], ["90", "Запорожская область"], ["91", "Республика Крым"], ["92", "Севастополь"],
  ["93", "Краснодарский край"], ["94", "Территории за пределами РФ"], ["95", "Чеченская Республика"], ["80", "Донецкая Народная Республика"], ["81", "Луганская Народная Республика"], ["84", "Херсонская область"],
] as const;

const mapCodeByIso: Record<string, string> = {
  "RU-AD":"01", "RU-BA":"02", "RU-BU":"03", "RU-AL":"04", "RU-DA":"05", "RU-IN":"06", "RU-KB":"07", "RU-KL":"08", "RU-KC":"09", "RU-KR":"10",
  "RU-KO":"11", "RU-ME":"12", "RU-MO":"13", "RU-SA":"14", "RU-SE":"15", "RU-TA":"16", "RU-TY":"17", "RU-UD":"18", "RU-KK":"19", "RU-CE":"20", "RU-CU":"21",
  "RU-ALT":"22", "RU-KDA":"23", "RU-KYA":"24", "RU-PRI":"25", "RU-STA":"26", "RU-KHA":"27", "RU-AMU":"28", "RU-ARK":"29", "RU-AST":"30", "RU-BEL":"31", "RU-BRY":"32", "RU-VLA":"33",
  "RU-VGG":"34", "RU-VLG":"35", "RU-VOR":"36", "RU-IVA":"37", "RU-IRK":"38", "RU-KGD":"39", "RU-KLU":"40", "RU-KAM":"41", "RU-KEM":"42", "RU-KIR":"43", "RU-KOS":"44", "RU-KGN":"45",
  "RU-KRS":"46", "RU-LEN":"47", "RU-LIP":"48", "RU-MAG":"49", "RU-MOS":"50", "RU-MUR":"51", "RU-NIZ":"52", "RU-NGR":"53", "RU-NVS":"54", "RU-OMS":"55", "RU-ORE":"56", "RU-ORL":"57",
  "RU-PNZ":"58", "RU-PER":"59", "RU-PSK":"60", "RU-ROS":"61", "RU-RYA":"62", "RU-SAM":"63", "RU-SAR":"64", "RU-SAK":"65", "RU-SVE":"66", "RU-SMO":"67", "RU-TAM":"68", "RU-TVE":"69",
  "RU-TOM":"70", "RU-TUL":"71", "RU-TYU":"72", "RU-ULY":"73", "RU-CHE":"74", "RU-ZAB":"75", "RU-YAR":"76", "RU-MOW":"77", "RU-SPE":"78", "RU-YEV":"79", "RU-NEN":"83", "RU-KHM":"86", "RU-CHU":"87", "RU-YAN":"89",
};

const mapPaths = Object.entries((ruMill as { content: { paths: Record<string, MapPath>; width: number; height: number } }).content.paths);
const regionByCode = new Map(regions.map(([code, name]) => [code, { code, name }]));

function regionHref(code: string) {
  return `/region/${code}`;
}

function cameraCount(code: string) {
  return code === "50" ? 2149 : code === "58" ? 171 : officialRegions[code]?.count ?? 0;
}

function isReady(code: string) {
  return Boolean(officialRegions[code]) || code === "50" || code === "58";
}

export default function RegionHome({ initialQuery = "" }: { initialQuery?: string }) {
  const [mapMounted, setMapMounted] = useState(false);
  const [query, setQuery] = useState(initialQuery);
  const [selectedCode, setSelectedCode] = useState("58");
  const [hoveredCode, setHoveredCode] = useState<string | null>(null);
  const [onlyReady, setOnlyReady] = useState(true);
  const [directoryOpen, setDirectoryOpen] = useState(false);
  const normalizedQuery = query.trim().toLocaleLowerCase("ru");

  const filtered = useMemo(() => regions.filter(([code, name]) => {
    const matchesQuery = !normalizedQuery || code.includes(normalizedQuery) || name.toLocaleLowerCase("ru").includes(normalizedQuery);
    return matchesQuery && (!onlyReady || isReady(code));
  }), [normalizedQuery, onlyReady]);

  const searchSuggestions = normalizedQuery ? filtered.slice(0, 6) : [];
  const activeCode = hoveredCode ?? selectedCode;
  const activeRegion = regionByCode.get(activeCode) ?? regionByCode.get("58")!;
  const activeReady = isReady(activeRegion.code);
  const activeCount = cameraCount(activeRegion.code);

  useEffect(() => {
    const frame = window.requestAnimationFrame(() => setMapMounted(true));
    return () => window.cancelAnimationFrame(frame);
  }, []);

  const selectRegion = (code: string) => {
    setSelectedCode(code);
    setHoveredCode(null);
    setQuery("");
  };
  const openDirectory = () => { setDirectoryOpen(true); window.setTimeout(() => document.getElementById("all-regions")?.scrollIntoView({ behavior: "smooth", block: "start" }), 0); };

  return <main className="regions-page">
    <header className="regions-topbar">
      <Link className="brand" href="/" aria-label="Где камера — главная"><span className="brand-mark" aria-hidden="true"><span /></span><span className="brand-name">Где <span>камера</span></span></Link>
      <span className="regions-tagline">Камеры под контролем водителя</span>
      <Link className="guide-link" href="/spravochnik"><span aria-hidden="true">?</span><b>Справочник</b></Link>
      <Link className="appeal-link" href="/obzhalovanie" aria-label="Обжаловать штраф"><span aria-hidden="true">⚖</span><b>Обжаловать штраф</b></Link>
      <SiteSuggestion />
      <a className="home-support-link" href="/support?amount=other" target="_blank" rel="noopener noreferrer" aria-label="Поддержать проект" onClick={() => reachMetrikaGoal("support_click", { surface: "home" })}><span className="support-heart-icon" aria-hidden="true">♥</span> Поддержать</a>
      <button className="directory-jump" type="button" onClick={openDirectory}>Список регионов <span>↓</span></button>
    </header>

    <CameraGlobalSearch />

    <section className="home-notifications" aria-labelledby="home-notifications-title">
      <div><span aria-hidden="true">🔔</span><div><b>Камеры в вашем регионе изменились?</b><p>Получайте уведомления о новых камерах и важных обновлениях базы.</p></div></div>
      <div className="home-notification-actions"><Link href="/notifications" id="home-notifications-title">Уведомлять меня <span>→</span></Link><ShareSiteButton /></div>
    </section>

    <section className="regions-hero">
      <div className="regions-intro">
        <div className="hero-copy">
          <span className="eyebrow">Открытые официальные данные</span>
          <h1>Выберите регион<br /><em>на карте России</em></h1>
          <p>Наведите на регион или нажмите на него. Синим отмечены территории, для которых камеры уже опубликованы.</p>
        </div>

        <div className="region-search-wrap">
          <label className="region-search">
            <span aria-hidden="true" />
            <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Название или код региона, например 77" aria-label="Поиск региона" />
            {query ? <button type="button" onClick={() => setQuery("")} aria-label="Очистить поиск">×</button> : <kbd>⌕</kbd>}
          </label>
          {searchSuggestions.length > 0 && <div className="region-suggestions" role="listbox" aria-label="Найденные регионы">
            {searchSuggestions.map(([code, name]) => <button key={`${code}-${name}`} type="button" onClick={() => selectRegion(code)}>
              <span>{code}</span><b>{name}</b><small>{cameraCount(code).toLocaleString("ru-RU")} камер</small>
            </button>)}
          </div>}
          {normalizedQuery && searchSuggestions.length === 0 && <div className="region-suggestions empty-suggestion">Регион не найден</div>}
          <div className="hero-stats">
            <span><strong>{officialCameraCount.toLocaleString("ru-RU")}</strong><small>официальных камер</small></span>
            <span><strong>{readyRegionCount}</strong><small>регионов доступны</small></span>
          </div>
        </div>
      </div>

      <div className="regions-map-layout">
        <div className="russia-map-card">
          <div className="map-toolbar"><div><strong>Карта регионов</strong><span><i /> данные опубликованы</span></div><small>На телефоне карту можно двигать влево и вправо</small></div>
          <div className="russia-map-scroll">
            {mapMounted ? <svg className="russia-regions-map" viewBox="0 0 900 345" role="img" aria-label="Интерактивная карта субъектов России">
              {mapPaths.map(([iso, item]) => {
                const code = mapCodeByIso[iso];
                if (!code) return null;
                const region = regionByCode.get(code);
                const ready = isReady(code);
                const selected = selectedCode === code;
                return <path key={iso} d={item.path} className={`russia-region${ready ? " ready" : ""}${selected ? " selected" : ""}`}
                  role="button" tabIndex={0} aria-label={`${region?.name ?? item.name}, код ${code}${ready ? `, ${cameraCount(code)} камер` : ", данные готовятся"}`}
                  onMouseEnter={() => setHoveredCode(code)} onMouseLeave={() => setHoveredCode(null)} onFocus={() => setHoveredCode(code)} onBlur={() => setHoveredCode(null)}
                  onClick={() => selectRegion(code)} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); selectRegion(code); } }} />;
              })}
            </svg> : <div className="russia-map-placeholder" aria-label="Загрузка интерактивной карты России" />}
          </div>
        </div>

        <aside className={`selected-region-card${activeReady ? " ready" : ""}`} aria-live="polite">
          <div className="selected-region-top"><span>{activeRegion.code}</span><i>{activeReady ? "Доступен" : "Готовится"}</i></div>
          <h2>{activeRegion.name}</h2>
          {activeReady ? <>
            <p><strong>{activeCount.toLocaleString("ru-RU")}</strong> камер и комплексов фиксации</p>
            <Link href={regionHref(activeRegion.code)}>Открыть карту региона <b>→</b></Link>
            <small>Адреса, нарушения, типы камер и построение маршрута</small>
          </> : <>
            <p className="region-pending">Официальный перечень для этого региона ещё обрабатывается.</p>
            <small>Регион появится на карте после проверки адресов и координат.</small>
          </>}
          <div className="selection-hint">Выберите другой регион на карте или через поиск</div>
        </aside>
      </div>
    </section>

    <section className="camera-rights" aria-labelledby="camera-rights-title">
      <div className="rights-heading">
        <span className="rights-law">Статья 22.1 · 257-ФЗ</span>
        <h2 id="camera-rights-title">Получили штраф с камеры?<br /><em>Проверьте, законно ли она работала</em></h2>
        <p>Сведения о местах установки стационарных и передвижных камер, а также маршрутах мобильных комплексов должны быть общедоступными. Сам комплекс должен иметь сертификат и действующую метрологическую поверку.</p>
      </div>
      <div className="rights-checks">
        <div><span>01</span><b>Найдите камеру</b><p>Сверьте адрес, координаты и фиксируемые нарушения с официальным перечнем региона.</p></div>
        <div><span>02</span><b>Проверьте маршрут</b><p>Для мобильного комплекса должен быть опубликован маршрут движения автомобиля.</p></div>
        <div><span>03</span><b>Запросите документы</b><p>Проверьте сертификат, действующую поверку и решение о размещении комплекса.</p></div>
      </div>
      <div className="rights-action">
        <div><strong>Нашли несоответствие?</strong><p>Это может стать доводом в жалобе на постановление в ГИБДД или суд. Приложите сведения о камере, копии документов и другие доказательства.</p></div>
        <a href="https://www.consultant.ru/document/cons_doc_LAW_72386/18639e1fec295180beae683608702e38a9e14c47/" target="_blank" rel="noreferrer">Открыть статью 22.1 <span>↗</span></a>
      </div>
      <p className="rights-note"><b>Важно:</b> отсутствие камеры именно на сайте «Где камера» само по себе не доказывает незаконность штрафа — наш справочник может быть неполным. Проверяйте официальный перечень Госавтоинспекции. Отмена не происходит автоматически: решение принимает орган, рассматривающий жалобу, или суд. Для Москвы действуют предусмотренные законом особенности.</p>
    </section>

    <section className="home-guide" aria-labelledby="home-guide-title">
      <div className="home-guide-heading"><span className="eyebrow">Полезно водителю</span><h2 id="home-guide-title">Как проверить камеру и штраф</h2><p>Понятные инструкции без сложных формулировок: от поиска точки на карте до проверки поверки конкретного комплекса.</p></div>
      <div className="home-guide-grid">
        <Link href="/spravochnik/proverka-poverki-kamery-gibdd"><span>01</span><h3>Проверить поверку камеры</h3><p>Что вводить во ФГИС «Аршин» и как сверить срок поверки с датой нарушения.</p><b>Читать →</b></Link>
        <Link href="/spravochnik/kak-nayti-kameru-po-adresu"><span>02</span><h3>Найти камеру по адресу</h3><p>Поиск по городу, улице, перекрёстку, трассе, километру или номеру комплекса.</p><b>Читать →</b></Link>
        <Link href="/spravochnik/proverit-kameru-v-oficialnom-perechne"><span>03</span><h3>Сверить официальный перечень</h3><p>Какие параметры камеры должны совпасть со сведениями в постановлении.</p><b>Читать →</b></Link>
        <Link href="/obzhalovanie"><span>04</span><h3>Обжаловать штраф</h3><p>Пошаговая фиксация доказательств и шаблоны для основных ситуаций.</p><b>Открыть шаблоны →</b></Link>
      </div>
      <Link className="all-guides-link" href="/spravochnik">Все инструкции для водителей <span>→</span></Link>
    </section>

    <section className={`region-directory${directoryOpen ? " directory-open" : ""}`} id="all-regions">
      <button className="directory-toggle" type="button" aria-expanded={directoryOpen} aria-controls="region-directory-content" onClick={() => setDirectoryOpen(value => !value)}>
        <span><b>Все регионы России</b><small>{readyRegionCount} регионов с опубликованными камерами</small></span><strong>{directoryOpen ? "Свернуть" : "Показать список"} <i>{directoryOpen ? "↑" : "↓"}</i></strong>
      </button>
      {directoryOpen && <div id="region-directory-content" className="directory-content"><div className="directory-heading">
        <div><span className="eyebrow">Все регионы</span><h2>Выбор из списка</h2></div>
        <div className="directory-controls">
          <label><input type="checkbox" checked={onlyReady} onChange={(event) => setOnlyReady(event.target.checked)} /><span />Только доступные</label>
          <p>{onlyReady ? "Показаны регионы, где камеры уже опубликованы." : "Показаны также регионы, данные по которым готовятся."}</p>
        </div>
      </div>
      <div className="regions-grid">
        {filtered.map(([code, name]) => {
          const ready = isReady(code);
          const count = `${cameraCount(code).toLocaleString("ru-RU")} камер`;
          return ready
            ? <Link key={`${code}-${name}`} className="region-card ready" href={regionHref(code)}><span className="region-code">{code}</span><span><strong>{name}</strong><small>{count}</small></span><b>→</b></Link>
            : <button key={`${code}-${name}`} type="button" className="region-card" onClick={() => { setSelectedCode(code); window.scrollTo({ top: 80, behavior: "smooth" }); }}><span className="region-code">{code}</span><span><strong>{name}</strong><small>данные готовятся</small></span></button>;
        })}
      </div>
      {!filtered.length && <div className="no-regions">Регион не найден. Попробуйте ввести название без сокращений.</div>}
      </div>}
    </section>
  </main>;
}
