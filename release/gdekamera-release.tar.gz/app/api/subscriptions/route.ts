import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { join } from "node:path";

export const runtime = "nodejs";

type Subscription = {
  id: string;
  email: string;
  regionCode: string;
  regionName: string;
  status: "pending" | "active" | "unsubscribed";
  createdAt: string;
  updatedAt: string;
  unsubscribeToken: string;
  lastNotifiedAt?: string;
};

const recentRequests = new Map<string, number>();
let writeQueue = Promise.resolve();

function storagePath() {
  return join(process.env.FEEDBACK_STORAGE_DIR || "/var/lib/gdekamera/feedback", "subscriptions.json");
}

async function readSubscriptions() {
  try { return JSON.parse(await readFile(storagePath(), "utf8")) as Subscription[]; }
  catch { return []; }
}

async function saveSubscriptions(records: Subscription[]) {
  const path = storagePath();
  await mkdir(process.env.FEEDBACK_STORAGE_DIR || "/var/lib/gdekamera/feedback", { recursive: true });
  const temporary = `${path}.${process.pid}.${randomUUID()}.tmp`;
  await writeFile(temporary, `${JSON.stringify(records, null, 2)}\n`, { encoding: "utf8", mode: 0o640 });
  await rename(temporary, path);
}

function mutate<T>(operation: () => Promise<T>) {
  const result = writeQueue.then(operation, operation);
  writeQueue = result.then(() => undefined, () => undefined);
  return result;
}

function validEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i.test(value) && value.length <= 254;
}

export async function POST(request: Request) {
  const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  const previous = recentRequests.get(forwarded) ?? 0;
  if (Date.now() - previous < 20_000) return Response.json({ error: "Подождите перед повторной отправкой." }, { status: 429 });

  const body = await request.json().catch(() => ({})) as Record<string, unknown>;
  const email = typeof body.email === "string" ? body.email.trim().toLocaleLowerCase("ru") : "";
  const regionCode = typeof body.regionCode === "string" ? body.regionCode.trim().padStart(2, "0") : "";
  const regionName = typeof body.regionName === "string" ? body.regionName.trim().slice(0, 120) : "";
  const website = typeof body.website === "string" ? body.website.trim() : "";
  if (website) return Response.json({ ok: true });
  if (!validEmail(email)) return Response.json({ error: "Укажите корректный адрес электронной почты." }, { status: 400 });
  if (!/^\d{2}$/.test(regionCode) || !regionName) return Response.json({ error: "Выберите регион." }, { status: 400 });
  if (body.consent !== true) return Response.json({ error: "Нужно согласие на обработку адреса электронной почты." }, { status: 400 });

  const result = await mutate(async () => {
    const records = await readSubscriptions();
    const now = new Date().toISOString();
    const existing = records.find((item) => item.email === email && item.regionCode === regionCode);
    if (existing) {
      if (existing.status !== "active") existing.status = "pending";
      existing.regionName = regionName;
      existing.updatedAt = now;
      await saveSubscriptions(records);
      return existing;
    }
    const created: Subscription = {
      id: randomUUID(), email, regionCode, regionName, status: "pending", createdAt: now, updatedAt: now,
      unsubscribeToken: randomUUID().replaceAll("-", "") + randomUUID().replaceAll("-", ""),
    };
    records.push(created);
    await saveSubscriptions(records);
    return created;
  });
  let confirmationSent = result.status === "active";
  const apiKey = process.env.RESEND_API_KEY; const from = process.env.NOTIFICATION_FROM_EMAIL;
  if (!confirmationSent && apiKey && from) {
    const confirmationUrl = `https://xn--80aahefb7ar1b.xn--p1ai/notifications/confirm?token=${result.unsubscribeToken}`;
    const response = await fetch("https://api.resend.com/emails", { method:"POST", headers:{ authorization:`Bearer ${apiKey}`, "content-type":"application/json" }, body:JSON.stringify({ from, to:[email], subject:`Подтвердите подписку — ${result.regionName}`, html:`<div style="font-family:Arial,sans-serif;line-height:1.6;color:#172536"><h1 style="font-size:22px">Подтвердите подписку</h1><p>Вы запросили уведомления об изменениях камер в регионе «${result.regionName.replace(/[&<>]/g,"") }».</p><p><a href="${confirmationUrl}" style="display:inline-block;padding:12px 18px;border-radius:8px;background:#1769e0;color:#fff;text-decoration:none;font-weight:bold">Подтвердить подписку</a></p><p style="font-size:12px;color:#738091">Если вы не оформляли подписку, просто проигнорируйте письмо.</p></div>` }) });
    confirmationSent = response.ok;
  }
  recentRequests.set(forwarded, Date.now());
  return Response.json({ ok: true, regionName: result.regionName, confirmationSent, active: result.status === "active", unsubscribeUrl: `/notifications/unsubscribe?token=${result.unsubscribeToken}` });
}

export async function PUT(request: Request) {
  const token = new URL(request.url).searchParams.get("token")?.trim() ?? "";
  if (token.length < 32) return Response.json({ error: "Некорректная ссылка." }, { status: 400 });
  const changed = await mutate(async () => {
    const records = await readSubscriptions(); const record = records.find((item) => item.unsubscribeToken === token);
    if (!record) return false; record.status = "active"; record.updatedAt = new Date().toISOString(); await saveSubscriptions(records); return true;
  });
  return changed ? Response.json({ ok:true }) : Response.json({ error:"Подписка не найдена." }, { status:404 });
}

export async function DELETE(request: Request) {
  const token = new URL(request.url).searchParams.get("token")?.trim() ?? "";
  if (token.length < 32) return Response.json({ error: "Некорректная ссылка." }, { status: 400 });
  const changed = await mutate(async () => {
    const records = await readSubscriptions();
    const record = records.find((item) => item.unsubscribeToken === token);
    if (!record) return false;
    record.status = "unsubscribed";
    record.updatedAt = new Date().toISOString();
    await saveSubscriptions(records);
    return true;
  });
  return changed ? Response.json({ ok: true }) : Response.json({ error: "Подписка не найдена." }, { status: 404 });
}
