import { mkdir, readFile, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { randomUUID } from "node:crypto";
export const runtime = "nodejs";

type Vote = "working" | "missing";
type VoteFile = Record<string, Record<string, Vote>>;
type Adjustment = { working?: number; missing?: number; label?: "auto" | "working" | "uncertain" | "missing"; note?: string; updatedAt?: string };

async function json<T>(path: string, fallback: T): Promise<T> { try { return JSON.parse(await readFile(path, "utf8")) as T; } catch { return fallback; } }
function safeKey(value: unknown) { const key = String(value ?? ""); return /^\d{2,3}:\d{1,10}$/.test(key) ? key : ""; }
function summary(votes: VoteFile, adjustments: Record<string, Adjustment>, key: string) {
  const values = Object.values(votes[key] ?? {}), adjustment = adjustments[key] ?? {};
  const rawWorking = values.filter(x => x === "working").length, rawMissing = values.filter(x => x === "missing").length;
  const working = typeof adjustment.working === "number" ? Math.max(0, adjustment.working) : rawWorking;
  const missing = typeof adjustment.missing === "number" ? Math.max(0, adjustment.missing) : rawMissing;
  const total = working + missing;
  const automatic = total < 3 ? "uncertain" : missing >= 3 && missing >= working * 2 ? "missing" : working >= 2 ? "working" : "uncertain";
  return { working, missing, total, status: adjustment.label && adjustment.label !== "auto" ? adjustment.label : automatic, moderatorNote: adjustment.note ?? "" };
}

export async function GET(request: Request) {
  const storage = process.env.FEEDBACK_STORAGE_DIR || "/var/lib/gdekamera/feedback", url = new URL(request.url), prefix = url.searchParams.get("region") ?? "";
  const [votes, adjustments] = await Promise.all([json<VoteFile>(join(storage, "camera-status-votes.json"), {}), json<Record<string, Adjustment>>(join(storage, "camera-status-adjustments.json"), {})]);
  const keys = new Set([...Object.keys(votes), ...Object.keys(adjustments)]);
  return Response.json({ statuses: Object.fromEntries([...keys].filter(key => !prefix || key.startsWith(`${prefix}:`)).map(key => [key, summary(votes, adjustments, key)])) }, { headers: { "cache-control": "no-store" } });
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({})) as { cameraKey?: string; vote?: Vote }, key = safeKey(body.cameraKey);
  if (!key || !["working", "missing"].includes(body.vote ?? "")) return Response.json({ error: "Некорректный голос." }, { status: 400 });
  const storage = process.env.FEEDBACK_STORAGE_DIR || "/var/lib/gdekamera/feedback"; await mkdir(storage, { recursive: true });
  const path = join(storage, "camera-status-votes.json"), adjustmentPath = join(storage, "camera-status-adjustments.json");
  const cookie = request.headers.get("cookie")?.match(/(?:^|;\s*)roadcam_voter=([^;]+)/)?.[1], voter = cookie && /^[a-f0-9-]{20,50}$/i.test(cookie) ? cookie : randomUUID();
  const [votes, adjustments] = await Promise.all([json<VoteFile>(path, {}), json<Record<string, Adjustment>>(adjustmentPath, {})]);
  votes[key] ??= {}; votes[key][voter] = body.vote as Vote;
  await writeFile(path, `${JSON.stringify(votes, null, 2)}\n`, { encoding: "utf8", mode: 0o640 });
  return Response.json(summary(votes, adjustments, key), { headers: { "set-cookie": `roadcam_voter=${voter}; Path=/; Max-Age=31536000; SameSite=Lax; HttpOnly; Secure`, "cache-control": "no-store" } });
}
