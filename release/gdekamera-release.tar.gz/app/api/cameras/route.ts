import { readFile } from "node:fs/promises";
import { join } from "node:path";
import regionsSummary from "../../../public/official-regions-summary.json";
export const runtime = "nodejs";
type PublishedCamera = { requestId: string; region?: string; cameraAddress?: string; coordinates?: string; cameraType?: string; cameraCode?: string; violations?: string; speedLimit?: string; direction?: string; publishedAt: string };
function numericId(value: string) { let hash = 2166136261; for (const character of value) hash = Math.imul(hash ^ character.charCodeAt(0), 16777619); return 900_000_000 + (Math.abs(hash) % 99_999_999); }
export async function GET(request: Request) {
  const region = new URL(request.url).searchParams.get("region")?.trim(); if (!region) return Response.json({ cameras: [] }); const storage = process.env.FEEDBACK_STORAGE_DIR || "/var/lib/gdekamera/feedback";
  const [published,overrides,hidden] = await Promise.all([
    readFile(join(storage, "published-cameras.json"), "utf8").then((value) => JSON.parse(value) as Record<string, PublishedCamera>).catch(() => ({})),
    readFile(join(storage,"camera-overrides.json"),"utf8").then(value=>JSON.parse(value) as Record<string,unknown>).catch(()=>({})),
    readFile(join(storage,"camera-hidden.json"),"utf8").then(value=>JSON.parse(value) as Record<string,boolean>).catch(()=>({})),
  ]);
  const cameras = Object.values(published).filter((item) => item.region === region).flatMap((item) => { const [lat, lng] = (item.coordinates ?? "").split(",").map(Number); if (!Number.isFinite(lat) || !Number.isFinite(lng)) return []; const type = item.cameraType === "Передвижная" ? "portable" : item.cameraType === "Муляж" ? "dummy" : item.cameraType === "Не знаю" ? "unspecified" : "stationary"; return [{ id: numericId(item.requestId), address: item.cameraAddress || "Камера, добавленная пользователем", lat, lng, violations: (item.violations ?? "").split(/[,;\n]+/).map((value) => value.trim()).filter(Boolean), speedLimit: Number(item.speedLimit) || undefined, cameraCodes: item.cameraCode ? [item.cameraCode] : undefined, directions: item.direction ? [item.direction] : undefined, cameraType: type, verification: "community", sourceKind: "community", sourceName: "Добавлено пользователем, проверено модератором; в официальном перечне не подтверждено", sourceDate: item.publishedAt.slice(0, 10) }]; });
  const regionCode = region === "Московская область" ? "50" : region === "Пензенская область" ? "58" : Object.values(regionsSummary).find((item) => item.name === region)?.code;
  const publicOverrides = Object.fromEntries(Object.entries(overrides).flatMap(([key, raw]) => {
    if (!regionCode || !key.startsWith(`${regionCode}:`) || !raw || typeof raw !== "object") return [];
    const value = raw as Record<string, unknown>;
    return [[key, { address: value.address, lat: value.lat, lng: value.lng, violations: value.violations, cameraType: value.cameraType, speedLimit: value.speedLimit }]];
  }));
  const hiddenIds = Object.keys(hidden).filter((key) => hidden[key] && Boolean(regionCode) && key.startsWith(`${regionCode}:`));
  return Response.json({ cameras, overrides: publicOverrides, hiddenIds }, { headers: { "cache-control": "no-store" } });
}
