import { appendFile, mkdir, writeFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { extname, join } from "node:path";

export const runtime = "nodejs";

const MAX_FILE_SIZE = 10 * 1024 * 1024;
const allowedTypes = new Set(["image/jpeg", "image/png", "image/webp", "application/pdf"]);
const recentRequests = new Map<string, number>();

function text(form: FormData, key: string, max = 2000) {
  const value = form.get(key);
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

function html(value: string) {
  return value.replace(/[&<>]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[character] ?? character);
}

function extension(file: File) {
  const original = extname(file.name).toLowerCase().replace(/[^.a-z0-9]/g, "");
  if (original && original.length <= 6) return original;
  return file.type === "application/pdf" ? ".pdf" : file.type === "image/png" ? ".png" : file.type === "image/webp" ? ".webp" : ".jpg";
}

async function notifyTelegram(message: string, file: File | null, requestId: string) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) return false;

  const messageResponse = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ chat_id: chatId, text: message, parse_mode: "HTML", disable_web_page_preview: true }),
  });
  if (!messageResponse.ok) throw new Error("Telegram notification failed");

  if (file && file.size) {
    const upload = new FormData();
    upload.set("chat_id", chatId);
    upload.set("caption", `Вложение к обращению ${requestId}`);
    upload.set("document", file, file.name);
    const fileResponse = await fetch(`https://api.telegram.org/bot${token}/sendDocument`, { method: "POST", body: upload });
    if (!fileResponse.ok) throw new Error("Telegram attachment failed");
  }
  return true;
}

export async function POST(request: Request) {
  try {
    const forwarded = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
    const lastRequest = recentRequests.get(forwarded) ?? 0;
    if (Date.now() - lastRequest < 30_000) return Response.json({ error: "Подождите перед повторной отправкой." }, { status: 429 });

    const form = await request.formData();
    if (text(form, "website")) return Response.json({ ok: true });
    if (text(form, "captcha") !== "11") return Response.json({ error: "Неверный ответ на проверочный вопрос." }, { status: 400 });

    const kind = text(form, "kind", 30);
    const isPhoto = kind === "camera-photo";
    const isReport = kind === "camera-report";
    const isCameraAdd = kind === "camera-add";
    const isSuggestion = kind === "service-suggestion";
    if (!isPhoto && !isReport && !isCameraAdd && !isSuggestion) return Response.json({ error: "Неизвестный тип обращения." }, { status: 400 });

    const attachmentValue = form.get(isPhoto ? "photo" : "attachment");
    const attachment = attachmentValue instanceof File && attachmentValue.size ? attachmentValue : null;
    if (isPhoto && !attachment) return Response.json({ error: "Выберите фотографию." }, { status: 400 });
    if (attachment && (attachment.size > MAX_FILE_SIZE || !allowedTypes.has(attachment.type))) {
      return Response.json({ error: "Разрешены JPG, PNG, WebP или PDF размером до 10 МБ." }, { status: 400 });
    }

    const description = text(form, isPhoto ? "comment" : "description", 1000);
    const problemType = isPhoto ? "Фотография камеры" : isCameraAdd ? "Новая камера" : text(form, "type", 120);
    if (isReport && (!problemType || !description)) return Response.json({ error: "Укажите тип проблемы и описание." }, { status: 400 });
    if (isSuggestion && (!problemType || description.length < 10)) return Response.json({ error: "Выберите тему и опишите предложение подробнее." }, { status: 400 });
    if (isCameraAdd && (!text(form, "cameraAddress", 500) || !text(form, "coordinates", 80) || !text(form, "violations", 1000))) {
      return Response.json({ error: "Укажите место камеры, координаты и фиксируемые нарушения." }, { status: 400 });
    }

    const requestId = `${new Date().toISOString().slice(0, 10).replaceAll("-", "")}-${randomUUID().slice(0, 8)}`;
    const record = {
      id: requestId,
      createdAt: new Date().toISOString(),
      status: "new",
      kind,
      problemType,
      description,
      email: text(form, "email", 254),
      region: text(form, "region", 160),
      cameraId: text(form, "cameraId", 80),
      cameraAddress: text(form, "cameraAddress", 500),
      coordinates: text(form, "coordinates", 80),
      cameraType: text(form, "cameraType", 80),
      cameraCode: text(form, "cameraCode", 120),
      violations: text(form, "violations", 1000),
      speedLimit: text(form, "speedLimit", 20),
      direction: text(form, "direction", 300),
      observedAt: text(form, "observedAt", 30),
      possibleDuplicates: text(form, "possibleDuplicates", 1000),
      attachment: attachment ? `${requestId}${extension(attachment)}` : null,
    };

    const storage = process.env.FEEDBACK_STORAGE_DIR || "/var/lib/gdekamera/feedback";
    await mkdir(join(storage, "files"), { recursive: true });
    if (attachment && record.attachment) await writeFile(join(storage, "files", record.attachment), Buffer.from(await attachment.arrayBuffer()));
    await appendFile(join(storage, "inbox.jsonl"), `${JSON.stringify(record)}\n`, "utf8");

    const message = [
      `📨 <b>Новое обращение ${html(requestId)}</b>`,
      `<b>Тип:</b> ${html(problemType)}`,
      `<b>Регион:</b> ${html(record.region || "не указан")}`,
      `<b>Камера:</b> ${html(record.cameraId)} — ${html(record.cameraAddress)}`,
      `<b>Координаты:</b> ${html(record.coordinates)}`,
      record.cameraType ? `<b>Тип камеры:</b> ${html(record.cameraType)}` : "",
      record.cameraCode ? `<b>Номер комплекса:</b> ${html(record.cameraCode)}` : "",
      record.violations ? `<b>Фиксирует:</b> ${html(record.violations)}` : "",
      record.speedLimit ? `<b>Ограничение:</b> ${html(record.speedLimit)} км/ч` : "",
      record.direction ? `<b>Направление:</b> ${html(record.direction)}` : "",
      record.possibleDuplicates ? `<b>Возможные дубли:</b> ${html(record.possibleDuplicates)}` : "",
      description ? `<b>Описание:</b> ${html(description)}` : "",
      record.email ? `<b>Ответить:</b> ${html(record.email)}` : "",
      "Статус: #новое",
    ].filter(Boolean).join("\n");

    let telegramSent = false;
    try { telegramSent = await notifyTelegram(message, attachment, requestId); } catch (error) { console.error(error); }
    recentRequests.set(forwarded, Date.now());
    return Response.json({ ok: true, requestId, telegramSent });
  } catch (error) {
    console.error("Feedback submission failed", error);
    return Response.json({ error: "Не удалось сохранить обращение. Попробуйте позже." }, { status: 500 });
  }
}
