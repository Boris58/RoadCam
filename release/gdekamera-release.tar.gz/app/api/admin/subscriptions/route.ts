import { appendFile, mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { join } from "node:path";

export const runtime = "nodejs";
type Subscription = { id:string; email:string; regionCode:string; regionName:string; status:"pending"|"active"|"unsubscribed"; createdAt:string; updatedAt:string; unsubscribeToken:string; lastNotifiedAt?:string };

function authorized(request: Request) { const expected=process.env.ADMIN_FEEDBACK_TOKEN; const supplied=request.headers.get("authorization")?.replace(/^Bearer\s+/i,""); return Boolean(expected&&supplied&&supplied===expected); }
function storage() { return process.env.FEEDBACK_STORAGE_DIR || "/var/lib/gdekamera/feedback"; }
async function records() { try { return JSON.parse(await readFile(join(storage(),"subscriptions.json"),"utf8")) as Subscription[]; } catch { return []; } }
async function save(items:Subscription[]) { await mkdir(storage(),{recursive:true}); const target=join(storage(),"subscriptions.json"); const temporary=`${target}.${process.pid}.${randomUUID()}.tmp`; await writeFile(temporary,`${JSON.stringify(items,null,2)}\n`,{encoding:"utf8",mode:0o640}); await rename(temporary,target); }
function clean(value:unknown,max=500) { return typeof value==="string"?value.trim().slice(0,max):""; }
function escapeHtml(value:string) { return value.replace(/[&<>"']/g,(character)=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[character]!); }

export async function GET(request:Request) {
  if(!process.env.ADMIN_FEEDBACK_TOKEN)return Response.json({error:"Доступ администратора ещё не настроен."},{status:503});
  if(!authorized(request))return Response.json({error:"Неверный пароль."},{status:401});
  const items=await records();
  return Response.json({records:items.map((item)=>({id:item.id,email:item.email,regionCode:item.regionCode,regionName:item.regionName,status:item.status,createdAt:item.createdAt,updatedAt:item.updatedAt,lastNotifiedAt:item.lastNotifiedAt})),mailConfigured:Boolean(process.env.RESEND_API_KEY&&process.env.NOTIFICATION_FROM_EMAIL)},{headers:{"cache-control":"no-store"}});
}

export async function PATCH(request:Request) {
  if(!authorized(request))return Response.json({error:"Неверный пароль."},{status:401});
  const body=await request.json().catch(()=>({})) as {id?:string;status?:string};
  if(!body.id||!["active","unsubscribed"].includes(body.status??""))return Response.json({error:"Некорректные параметры."},{status:400});
  const items=await records(); const item=items.find((record)=>record.id===body.id);
  if(!item)return Response.json({error:"Подписка не найдена."},{status:404});
  item.status=body.status as Subscription["status"]; item.updatedAt=new Date().toISOString(); await save(items);
  return Response.json({ok:true,status:item.status});
}

export async function POST(request:Request) {
  if(!authorized(request))return Response.json({error:"Неверный пароль."},{status:401});
  const apiKey=process.env.RESEND_API_KEY; const from=process.env.NOTIFICATION_FROM_EMAIL;
  if(!apiKey||!from)return Response.json({error:"Почтовый канал не настроен. Добавьте RESEND_API_KEY и NOTIFICATION_FROM_EMAIL в /etc/gdekamera-feedback.env."},{status:503});
  const body=await request.json().catch(()=>({})) as Record<string,unknown>;
  const regionCode=clean(body.regionCode,2).padStart(2,"0"); const subject=clean(body.subject,160); const message=clean(body.message,4000);
  if(!/^\d{2}$/.test(regionCode)||!subject||message.length<10)return Response.json({error:"Выберите регион, укажите тему и текст уведомления."},{status:400});
  const items=await records(); const recipients=items.filter((item)=>item.status==="active"&&item.regionCode===regionCode);
  if(!recipients.length)return Response.json({error:"В этом регионе пока нет активных подписчиков."},{status:400});
  let sent=0; const failed:string[]=[]; const now=new Date().toISOString();
  for(let offset=0;offset<recipients.length;offset+=10){
    const batch=recipients.slice(offset,offset+10);
    await Promise.all(batch.map(async(item)=>{
      const unsubscribe=`https://xn--80aahefb7ar1b.xn--p1ai/notifications/unsubscribe?token=${item.unsubscribeToken}`;
      const response=await fetch("https://api.resend.com/emails",{method:"POST",headers:{authorization:`Bearer ${apiKey}`,"content-type":"application/json"},body:JSON.stringify({from,to:[item.email],subject,html:`<div style="font-family:Arial,sans-serif;line-height:1.6;color:#172536"><h1 style="font-size:22px">${escapeHtml(subject)}</h1><p>${escapeHtml(message).replaceAll("\n","<br>")}</p><p><a href="https://xn--80aahefb7ar1b.xn--p1ai/region/${regionCode}">Открыть карту региона</a></p><hr><p style="font-size:12px;color:#738091">Вы получили письмо, потому что подписались на обновления региона «${escapeHtml(item.regionName)}». <a href="${unsubscribe}">Отписаться</a>.</p></div>`})});
      if(response.ok){sent++;item.lastNotifiedAt=now;item.updatedAt=now;}else failed.push(item.email);
    }));
  }
  await save(items); await appendFile(join(storage(),"notification-history.jsonl"),`${JSON.stringify({at:now,regionCode,subject,sent,failed:failed.length})}\n`,"utf8");
  return Response.json({ok:true,sent,failed:failed.length});
}
