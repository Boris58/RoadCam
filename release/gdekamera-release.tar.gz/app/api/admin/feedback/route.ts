import { appendFile, mkdir, readFile, writeFile } from "node:fs/promises";
import { basename, join } from "node:path";

export const runtime = "nodejs";
type FeedbackRecord = { id: string; status: string; attachment?: string | null; [key: string]: unknown };
type EditableFields = { region?: string; cameraAddress?: string; coordinates?: string; cameraType?: string; cameraCode?: string; violations?: string; speedLimit?: string; direction?: string; description?: string; moderatorNote?: string };
type PublishedCamera = EditableFields & { requestId: string; publishedAt: string; updatedAt: string };
const allowedStatuses = new Set(["new", "reviewing", "confirmed", "rejected"]);
const editableKeys: Array<keyof EditableFields> = ["region", "cameraAddress", "coordinates", "cameraType", "cameraCode", "violations", "speedLimit", "direction", "description", "moderatorNote"];

function authorized(request: Request) { const expected = process.env.ADMIN_FEEDBACK_TOKEN; const supplied = request.headers.get("authorization")?.replace(/^Bearer\s+/i, ""); return Boolean(expected && supplied && supplied === expected); }
async function readJson<T>(path: string, fallback: T): Promise<T> { try { return JSON.parse(await readFile(path, "utf8")) as T; } catch { return fallback; } }
function cleanFields(value: unknown): EditableFields { const input = value && typeof value === "object" ? value as Record<string, unknown> : {}; return Object.fromEntries(editableKeys.map((key) => [key, typeof input[key] === "string" ? String(input[key]).trim().slice(0, key === "violations" || key === "description" || key === "moderatorNote" ? 1500 : 500) : ""])) as EditableFields; }
function validCoordinates(value?: string) { const parts = (value ?? "").split(",").map(Number); return parts.length === 2 && parts.every(Number.isFinite) && Math.abs(parts[0]) <= 90 && Math.abs(parts[1]) <= 180; }

async function loadRecords(storage: string) {
  const [inbox, statuses, edits, published] = await Promise.all([readFile(join(storage, "inbox.jsonl"), "utf8").catch(() => ""), readJson<Record<string, string>>(join(storage, "statuses.json"), {}), readJson<Record<string, EditableFields>>(join(storage, "edits.json"), {}), readJson<Record<string, PublishedCamera>>(join(storage, "published-cameras.json"), {})]);
  return inbox.split("\n").filter(Boolean).map((line) => JSON.parse(line) as FeedbackRecord).map((record) => ({ ...record, ...(edits[record.id] ?? {}), status: statuses[record.id] ?? record.status, published: Boolean(published[record.id]) })).reverse();
}
async function writeHistory(storage: string, id: string, action: string, fields?: EditableFields) { await appendFile(join(storage, "history.jsonl"), `${JSON.stringify({ id, action, fields, at: new Date().toISOString() })}\n`, "utf8"); }

export async function GET(request: Request) {
  if (!process.env.ADMIN_FEEDBACK_TOKEN) return Response.json({ error: "Доступ администратора ещё не настроен." }, { status: 503 });
  if (!authorized(request)) return Response.json({ error: "Неверный пароль." }, { status: 401 });
  const storage = process.env.FEEDBACK_STORAGE_DIR || "/var/lib/gdekamera/feedback"; const url = new URL(request.url); const attachment = url.searchParams.get("attachment");
  if (attachment) { const safeName = basename(attachment); const file = await readFile(join(storage, "files", safeName)).catch(() => null); if (!file) return Response.json({ error: "Файл не найден." }, { status: 404 }); return new Response(file, { headers: { "content-type": "application/octet-stream", "content-disposition": `attachment; filename="${safeName}"` } }); }
  return Response.json({ records: await loadRecords(storage) }, { headers: { "cache-control": "no-store" } });
}

export async function PATCH(request: Request) {
  if (!authorized(request)) return Response.json({ error: "Неверный пароль." }, { status: 401 });
  const body = await request.json() as { id?: string; status?: string; action?: string; fields?: unknown }; if (!body.id) return Response.json({ error: "Не указана заявка." }, { status: 400 });
  const storage = process.env.FEEDBACK_STORAGE_DIR || "/var/lib/gdekamera/feedback"; await mkdir(storage, { recursive: true }); const fields = cleanFields(body.fields);
  const editsPath = join(storage, "edits.json"); const statusesPath = join(storage, "statuses.json"); const publishedPath = join(storage, "published-cameras.json");
  const edits = await readJson<Record<string, EditableFields>>(editsPath, {}); const statuses = await readJson<Record<string, string>>(statusesPath, {}); const published = await readJson<Record<string, PublishedCamera>>(publishedPath, {});
  if (body.action === "save" || body.action === "publish") { edits[body.id] = fields; await writeFile(editsPath, `${JSON.stringify(edits, null, 2)}\n`, { encoding: "utf8", mode: 0o640 }); }
  if (body.action === "publish") {
    if (!fields.region || !fields.cameraAddress || !validCoordinates(fields.coordinates) || !fields.violations) return Response.json({ error: "Для публикации нужны регион, адрес, корректные координаты и нарушения." }, { status: 400 });
    const now = new Date().toISOString(); published[body.id] = { ...fields, requestId: body.id, publishedAt: published[body.id]?.publishedAt ?? now, updatedAt: now }; statuses[body.id] = "confirmed";
    await Promise.all([writeFile(publishedPath, `${JSON.stringify(published, null, 2)}\n`, { encoding: "utf8", mode: 0o640 }), writeFile(statusesPath, `${JSON.stringify(statuses, null, 2)}\n`, { encoding: "utf8", mode: 0o640 })]); await writeHistory(storage, body.id, "published", fields); return Response.json({ ok: true, status: "confirmed", published: true });
  }
  if (body.action === "unpublish") { delete published[body.id]; statuses[body.id] = "reviewing"; await Promise.all([writeFile(publishedPath, `${JSON.stringify(published, null, 2)}\n`, { encoding: "utf8", mode: 0o640 }), writeFile(statusesPath, `${JSON.stringify(statuses, null, 2)}\n`, { encoding: "utf8", mode: 0o640 })]); await writeHistory(storage, body.id, "unpublished"); return Response.json({ ok: true, status: "reviewing", published: false }); }
  if (body.action === "save") { statuses[body.id] = "reviewing"; await writeFile(statusesPath, `${JSON.stringify(statuses, null, 2)}\n`, { encoding: "utf8", mode: 0o640 }); await writeHistory(storage, body.id, "saved", fields); return Response.json({ ok: true, status: "reviewing" }); }
  if (!body.status || !allowedStatuses.has(body.status)) return Response.json({ error: "Некорректное действие." }, { status: 400 }); statuses[body.id] = body.status; await writeFile(statusesPath, `${JSON.stringify(statuses, null, 2)}\n`, { encoding: "utf8", mode: 0o640 }); await writeHistory(storage, body.id, `status:${body.status}`); return Response.json({ ok: true, status: body.status });
}
