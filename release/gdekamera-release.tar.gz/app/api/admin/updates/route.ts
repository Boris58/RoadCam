import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { randomUUID } from "node:crypto";
import { join } from "node:path";

export const runtime = "nodejs";

type Subscription = { id:string; email:string; regionCode:string; regionName:string; status:"pending"|"active"|"unsubscribed"; unsubscribeToken:string };
type UpdateRecord = { id:string; regionCode:string; regionName:string; added:number; changed:number; removed:number; sourceDate:string; sourceName:string; sourceUrl:string; note:string; status:"draft"|"sending"|"published"|"partial"; createdAt:string; publishedAt?:string; sent:number; failed:number; deliveredSubscriptionIds:string[] };
let writeQueue=Promise.resolve();
function authorized(request:Request){const expected=process.env.ADMIN_FEEDBACK_TOKEN;const supplied=request.headers.get("authorization")?.replace(/^Bearer\s+/i,"");return Boolean(expected&&supplied&&supplied===expected)}
function storage(){return process.env.FEEDBACK_STORAGE_DIR||"/var/lib/gdekamera/feedback"}
async function readJson<T>(path:string,fallback:T):Promise<T>{try{return JSON.parse(await readFile(path,"utf8")) as T}catch{return fallback}}
async function atomicJson(path:string,value:unknown){await mkdir(storage(),{recursive:true});const temporary=`${path}.${process.pid}.${randomUUID()}.tmp`;await writeFile(temporary,`${JSON.stringify(value,null,2)}\n`,{encoding:"utf8",mode:0o640});await rename(temporary,path)}
function mutate<T>(operation:()=>Promise<T>){const result=writeQueue.then(operation,operation);writeQueue=result.then(()=>undefined,()=>undefined);return result}
function clean(value:unknown,max:number){return typeof value==="string"?value.trim().slice(0,max):""}
function count(value:unknown){const number=Number(value);return Number.isInteger(number)&&number>=0?Math.min(number,100_000):-1}
function safeUrl(value:unknown){const text=clean(value,1000);if(!text)return "";try{const url=new URL(text);return ["http:","https:"].includes(url.protocol)?url.toString():""}catch{return ""}}
function escapeHtml(value:string){return value.replace(/[&<>"']/g,(character)=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[character]!)}
function summary(record:UpdateRecord){const parts:string[]=[];if(record.added)parts.push(`добавлено ${record.added}`);if(record.changed)parts.push(`изменено ${record.changed}`);if(record.removed)parts.push(`удалено ${record.removed}`);return parts.length?parts.join(", "):"перечень проверен, количественных изменений нет"}
function emailHtml(record:UpdateRecord,subscription:Subscription){const mapUrl=`https://xn--80aahefb7ar1b.xn--p1ai/region/${record.regionCode}`,unsubscribeUrl=`https://xn--80aahefb7ar1b.xn--p1ai/notifications/unsubscribe?token=${subscription.unsubscribeToken}`;const rows=[record.added?`<li><b>Добавлено:</b> ${record.added} камер</li>`:"",record.changed?`<li><b>Изменено:</b> ${record.changed} камер</li>`:"",record.removed?`<li><b>Удалено:</b> ${record.removed} комплексов</li>`:""].filter(Boolean).join("");const source=record.sourceUrl?`<a href="${escapeHtml(record.sourceUrl)}">${escapeHtml(record.sourceName)}</a>`:escapeHtml(record.sourceName);return `<div style="font-family:Arial,sans-serif;line-height:1.6;color:#172536;max-width:640px;margin:auto"><h1 style="font-size:24px">Обновление камер — ${escapeHtml(record.regionName)}</h1><p>Опубликованы проверенные изменения базы камер.</p>${rows?`<ul>${rows}</ul>`:"<p>Перечень проверен, количественных изменений нет.</p>"}<p><b>Дата перечня:</b> ${escapeHtml(record.sourceDate)}</p><p><b>Источник:</b> ${source}</p>${record.note?`<p>${escapeHtml(record.note).replaceAll("\n","<br>")}</p>`:""}<p><a href="${mapUrl}" style="display:inline-block;padding:12px 18px;border-radius:8px;background:#1769e0;color:#fff;text-decoration:none;font-weight:bold">Открыть карту региона</a></p><hr><p style="font-size:12px;color:#738091">Вы получили письмо, потому что подписались на обновления региона «${escapeHtml(record.regionName)}». <a href="${unsubscribeUrl}">Отписаться</a>.</p></div>`}

export async function GET(request:Request){if(!authorized(request))return Response.json({error:"Неверный пароль."},{status:401});const updates=await readJson<UpdateRecord[]>(join(storage(),"region-updates.json"),[]);return Response.json({updates:updates.sort((a,b)=>b.createdAt.localeCompare(a.createdAt))},{headers:{"cache-control":"no-store"}})}

export async function POST(request:Request){if(!authorized(request))return Response.json({error:"Неверный пароль."},{status:401});const body=await request.json().catch(()=>({})) as Record<string,unknown>;const regionCode=clean(body.regionCode,3).padStart(2,"0"),regionName=clean(body.regionName,120),added=count(body.added),changed=count(body.changed),removed=count(body.removed),sourceDate=clean(body.sourceDate,40),sourceName=clean(body.sourceName,250),sourceUrl=safeUrl(body.sourceUrl),rawSourceUrl=clean(body.sourceUrl,1000);if(!/^\d{2,3}$/.test(regionCode)||!regionName)return Response.json({error:"Выберите регион."},{status:400});if([added,changed,removed].some(value=>value<0))return Response.json({error:"Количество изменений должно быть целым числом от нуля."},{status:400});if(!sourceDate||!sourceName)return Response.json({error:"Укажите дату и официальный источник."},{status:400});if(rawSourceUrl&&!sourceUrl)return Response.json({error:"Ссылка на источник должна начинаться с http:// или https://."},{status:400});const now=new Date().toISOString(),record:UpdateRecord={id:randomUUID(),regionCode,regionName,added,changed,removed,sourceDate,sourceName,sourceUrl,note:clean(body.note,2000),status:"draft",createdAt:now,sent:0,failed:0,deliveredSubscriptionIds:[]};await mutate(async()=>{const path=join(storage(),"region-updates.json"),updates=await readJson<UpdateRecord[]>(path,[]);updates.push(record);await atomicJson(path,updates)});return Response.json({ok:true,update:record})}

export async function PATCH(request:Request){
  if(!authorized(request))return Response.json({error:"Неверный пароль."},{status:401});
  const apiKey=process.env.RESEND_API_KEY,from=process.env.NOTIFICATION_FROM_EMAIL;
  if(!apiKey||!from)return Response.json({error:"Почтовый канал не настроен."},{status:503});
  const body=await request.json().catch(()=>({})) as {id?:string;action?:string};
  if(!body.id||body.action!=="publish")return Response.json({error:"Некорректное действие."},{status:400});
  const path=join(storage(),"region-updates.json");
  const claimed=await mutate(async()=>{
    const updates=await readJson<UpdateRecord[]>(path,[]),record=updates.find(item=>item.id===body.id);
    if(!record)return {error:"Обновление не найдено.",status:404} as const;
    if(record.status==="published")return {error:"Это обновление уже опубликовано и разослано.",status:409} as const;
    if(record.status==="sending")return {error:"Рассылка этого обновления уже выполняется.",status:409} as const;
    record.deliveredSubscriptionIds??=[];
    record.status="sending";
    await atomicJson(path,updates);
    return {record} as const;
  });
  if("error" in claimed)return Response.json({error:claimed.error},{status:claimed.status});
  const record=claimed.record;
  const subscriptions=await readJson<Subscription[]>(join(storage(),"subscriptions.json"),[]);
  const recipients=subscriptions.filter(item=>item.status==="active"&&item.regionCode===record.regionCode&&!record.deliveredSubscriptionIds.includes(item.id));
  let sentNow=0,failedNow=0;
  for(let offset=0;offset<recipients.length;offset+=10){
    const batch=recipients.slice(offset,offset+10);
    await Promise.all(batch.map(async subscription=>{try{const response=await fetch("https://api.resend.com/emails",{method:"POST",headers:{authorization:`Bearer ${apiKey}`,"content-type":"application/json"},body:JSON.stringify({from,to:[subscription.email],subject:`Обновление камер — ${record.regionName}: ${summary(record)}`,html:emailHtml(record,subscription)})});if(response.ok){sentNow++;record.deliveredSubscriptionIds.push(subscription.id)}else failedNow++}catch{failedNow++}}));
  }
  const finalRecord=await mutate(async()=>{
    const updates=await readJson<UpdateRecord[]>(path,[]),current=updates.find(item=>item.id===record.id);
    if(!current)throw new Error("Обновление исчезло во время отправки.");
    current.deliveredSubscriptionIds=[...new Set([...(current.deliveredSubscriptionIds??[]),...record.deliveredSubscriptionIds])];
    current.sent=current.deliveredSubscriptionIds.length;
    current.failed=failedNow;
    current.publishedAt??=new Date().toISOString();
    current.status=failedNow?"partial":"published";
    await atomicJson(path,updates);
    return current;
  });
  return Response.json({ok:true,sent:sentNow,failed:failedNow,totalSent:finalRecord.sent,status:finalRecord.status});
}
