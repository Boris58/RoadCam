import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { appealTemplates, findAppealTemplate } from "../../appeal-templates";
import { jsonLd } from "../../seo";

type PageProps = { params: Promise<{ slug: string }> };
export function generateStaticParams() { return appealTemplates.map(({ slug }) => ({ slug })); }

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const item = findAppealTemplate((await params).slug);
  if (!item) return { title: "Шаблон не найден" };
  return { title: `${item.title} — образец`, description: item.description, alternates: { canonical: `/obzhalovanie/${item.slug}` }, openGraph: { type: "article", locale: "ru_RU", url: `/obzhalovanie/${item.slug}`, title: item.title, description: item.description }, twitter: { card: "summary", title: item.title, description: item.description } };
}

export default async function AppealTemplatePage({ params }: PageProps) {
  const item = findAppealTemplate((await params).slug); if (!item) notFound();
  const absenceRequest = item.documentTitle
    ? "Прошу рассмотреть настоящее ходатайство и приложенную жалобу в моё отсутствие. О дате, времени и месте рассмотрения прошу известить меня по указанным контактным данным, а копию принятого решения направить по адресу: [ПОЧТОВЫЙ АДРЕС] и/или на электронную почту [EMAIL]."
    : "Прошу рассмотреть настоящую жалобу в моё отсутствие. О дате, времени и месте рассмотрения прошу известить меня по указанным контактным данным, а копию принятого решения направить по адресу: [ПОЧТОВЫЙ АДРЕС] и/или на электронную почту [EMAIL].";
  const schema = { "@context": "https://schema.org", "@type": "Article", headline: item.title, description: item.description, inLanguage: "ru-RU", isPartOf: { "@type": "WebSite", name: "Где камера", url: "https://xn--80aahefb7ar1b.xn--p1ai" } };
  return <main className="appeal-page"><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd(schema) }} />
    <header className="legal-topbar"><Link className="brand" href="/"><span className="brand-mark" aria-hidden="true"><span /></span><span className="brand-name">Где <span>камера</span></span></Link><Link href="/obzhalovanie">Все шаблоны</Link></header>
    <article className="appeal-article appeal-template-page"><nav className="legal-breadcrumbs"><Link href="/">Главная</Link><span>›</span><Link href="/obzhalovanie">Обжалование штрафа</Link><span>›</span><span>{item.shortTitle}</span></nav>
      <span className="legal-kicker">Образец для адаптации</span><h1>{item.title}</h1><p className="legal-lead">{item.description}</p>
      <aside className="legal-alert"><strong>Сначала проверьте факты</strong><span>{item.basis} Укажите только достоверные обстоятельства и удалите из образца всё, что к вашему делу не относится.</span></aside>
      <section><h2>Какие доказательства приложить</h2><ul className="evidence-list">{item.evidence.map((value) => <li key={value}>{value}</li>)}</ul></section>
      <section><h2>{item.documentTitle ? "Текст ходатайства" : "Текст жалобы"}</h2><div className="appeal-copy-template"><p>В [НАИМЕНОВАНИЕ ОРГАНА ИЛИ СУДА]</p><p>от [ФИО, АДРЕС, ТЕЛЕФОН, EMAIL]</p><h3>{item.documentTitle ?? "Жалоба на постановление по делу об административном правонарушении"}</h3>{item.text.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}<p><strong>{absenceRequest}</strong></p><p>Приложения: [ПЕРЕЧИСЛИТЕ КАЖДЫЙ ДОКУМЕНТ].</p><p>[ДАТА] __________________ / [ФИО]</p></div><p className="legal-note">Скопируйте текст, замените фрагменты в квадратных скобках и добавьте номер статьи КоАП, указанный в вашем постановлении. Не удаляйте конкретное описание фактов и доказательств.</p></section>
      <section><h2>Перед подачей</h2><ol className="compact-steps"><li>Сверьте номер постановления, дату, время, место и госномер.</li><li>Приложите копию постановления и доказательство даты его получения.</li><li>Пронумеруйте приложения и сошлитесь на них в тексте.</li><li>Сохраните подтверждение отправки жалобы.</li></ol></section>
      <aside className="legal-disclaimer">Шаблон носит информационный характер и не заменяет консультацию юриста. Жалоба оценивается вместе с доказательствами; одного общего несогласия обычно недостаточно.</aside>
      <footer className="legal-sources"><h2>Правовая основа и подача</h2><a href="https://www.consultant.ru/document/cons_doc_LAW_34661/fe56a31c33d64ee209a7de64c1850457e9b86d3c/" target="_blank" rel="noreferrer">Статья 2.6.1 КоАП РФ</a><a href="https://www.consultant.ru/document/cons_doc_LAW_34661/9ae21ddd95d2541114102cce9c92efe6fc637266/" target="_blank" rel="noreferrer">Срок и его восстановление: статья 30.3</a><a href="https://www.consultant.ru/document/cons_doc_LAW_34661/0147088a5497571bd1de83d7a7f6ce9ea7504a22/" target="_blank" rel="noreferrer">Участие и рассмотрение в отсутствие: статья 25.1</a><a href="https://www.gosuslugi.ru/help/faq/appeal_car_penalty/100916" target="_blank" rel="noreferrer">Подача через Госуслуги</a></footer>
    </article>
  </main>;
}
