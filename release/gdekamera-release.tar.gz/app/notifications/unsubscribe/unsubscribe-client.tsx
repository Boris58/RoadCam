"use client";
import { useState } from "react";

export default function UnsubscribeClient({ token }: { token: string }) {
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const unsubscribe = async () => {
    setState("sending");
    const response = await fetch(`/api/subscriptions?token=${encodeURIComponent(token)}`, { method: "DELETE" });
    setState(response.ok ? "done" : "error");
  };
  return <section className="unsubscribe-card"><h1>Отключить уведомления</h1>{state === "done" ? <p>Подписка отключена. Новые письма по этому региону больше не придут.</p> : <><p>Нажмите кнопку, чтобы прекратить рассылку уведомлений «Где камера».</p><button type="button" disabled={!token || state === "sending"} onClick={() => void unsubscribe()}>{state === "sending" ? "Отключаем…" : "Отписаться"}</button>{state === "error" && <span>Ссылка недействительна или подписка уже удалена.</span>}</>}</section>;
}
