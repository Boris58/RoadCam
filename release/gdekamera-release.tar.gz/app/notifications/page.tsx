import type { Metadata } from "next";
import Link from "next/link";
import officialRegionsData from "../../public/official-regions-summary.json";
import SubscriptionForm from "./subscription-form";

export const metadata: Metadata = {
  title: "Уведомления о новых камерах по регионам",
  description: "Подпишитесь на уведомления о добавленных, изменённых и удалённых дорожных камерах в выбранном регионе России.",
  alternates: { canonical: "/notifications" },
};

const names = Object.values(officialRegionsData as Record<string, { code: string; name: string }>).map(({ code, name }) => ({ code, name }));
const regions = [...names, { code: "50", name: "Московская область" }, { code: "58", name: "Пензенская область" }]
  .filter((item, index, list) => list.findIndex((candidate) => candidate.code === item.code) === index)
  .sort((a, b) => Number(a.code) - Number(b.code));

export default function NotificationsPage() {
  return <main className="notifications-page">
    <header className="legal-topbar"><Link className="brand" href="/"><span className="brand-mark" aria-hidden="true"><span /></span><span className="brand-name">Где <span>камера</span></span></Link><Link href="/">К карте регионов</Link></header>
    <section className="notifications-hero">
      <div><span className="eyebrow">Изменения базы</span><h1>Узнавайте о новых камерах в своём регионе</h1><p>Мы сообщим, когда в выбранном регионе появятся новые камеры, изменятся адреса или виды фиксируемых нарушений.</p></div>
      <SubscriptionForm regions={regions} />
    </section>
    <section className="notifications-details">
      <article><b>01</b><h2>Только выбранный регион</h2><p>Вы получите письмо только по тому субъекту России, который выбрали при подписке.</p></article>
      <article><b>02</b><h2>Без лишних писем</h2><p>Уведомления отправляются при содержательном обновлении базы, а не при каждом техническом изменении сайта.</p></article>
      <article><b>03</b><h2>Простая отписка</h2><p>В каждом письме будет персональная ссылка, которая сразу отключает рассылку.</p></article>
    </section>
    <p className="notifications-privacy">Подписываясь, вы соглашаетесь с <Link href="/privacy">условиями обработки данных</Link>. Адрес электронной почты не публикуется и не передаётся рекламным сервисам.</p>
  </main>;
}
