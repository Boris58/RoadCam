"use client";

import { FormEvent, useState } from "react";

type Region = { code: string; name: string };

export default function SubscriptionForm({ regions }: { regions: Region[] }) {
  const [email, setEmail] = useState("");
  const [regionCode, setRegionCode] = useState("58");
  const [consent, setConsent] = useState(false);
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [message, setMessage] = useState("");
  const [unsubscribeUrl, setUnsubscribeUrl] = useState("");

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setStatus("sending"); setMessage("");
    const region = regions.find((item) => item.code === regionCode);
    try {
      const response = await fetch("/api/subscriptions", {
        method: "POST", headers: { "content-type": "application/json" },
        body: JSON.stringify({ email, regionCode, regionName: region?.name, consent, website: "" }),
      });
      const result = await response.json() as { error?: string; regionName?: string; unsubscribeUrl?: string; confirmationSent?:boolean; active?:boolean };
      if (!response.ok) throw new Error(result.error || "Не удалось оформить подписку.");
      setStatus("sent");
      setMessage(result.active ? `Подписка на обновления региона «${result.regionName}» уже активна.` : result.confirmationSent ? `На ${email} отправлено письмо. Перейдите по ссылке в письме, чтобы подтвердить подписку.` : `Заявка на подписку сохранена. Почтовый канал пока настраивается; администратор сможет активировать её вручную.`);
      setUnsubscribeUrl(result.unsubscribeUrl ?? "");
    } catch (error) {
      setStatus("error"); setMessage(error instanceof Error ? error.message : "Не удалось оформить подписку.");
    }
  };

  return <form className="subscription-form" onSubmit={submit}>
    <label>Электронная почта<input type="email" required autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="name@example.ru" /></label>
    <label>Регион<select required value={regionCode} onChange={(event) => setRegionCode(event.target.value)}>{regions.map((region) => <option value={region.code} key={region.code}>{region.code} — {region.name}</option>)}</select></label>
    <input className="subscription-honeypot" name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" />
    <label className="subscription-consent"><input type="checkbox" checked={consent} onChange={(event) => setConsent(event.target.checked)} required /><span>Согласен на обработку электронной почты для отправки уведомлений. Отписаться можно в любое время.</span></label>
    <button type="submit" disabled={status === "sending"}>{status === "sending" ? "Сохраняем…" : "Подписаться на обновления"}</button>
    {message && <div className={`subscription-message ${status}`} role="status"><b>{status === "sent" ? "✓" : "!"}</b><span>{message}{status === "sent" && unsubscribeUrl && <> Сохраните <a href={unsubscribeUrl}>ссылку для отписки</a>.</>}</span></div>}
  </form>;
}
