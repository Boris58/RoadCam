"use client";
import { useEffect, useState } from "react";

export default function ConfirmClient({token}:{token:string}) {
  const [state,setState]=useState<"loading"|"done"|"error">(token ? "loading" : "error");
  useEffect(()=>{
    if(!token) return;
    fetch(`/api/subscriptions?token=${encodeURIComponent(token)}`,{method:"PUT"})
      .then(response=>setState(response.ok?"done":"error"))
      .catch(()=>setState("error"));
  },[token]);
  return <section className="unsubscribe-card"><h1>{state==="loading"?"Подтверждаем подписку…":state==="done"?"Подписка подтверждена":"Ссылка недействительна"}</h1><p>{state==="loading"?"Подождите несколько секунд.":state==="done"?"Теперь вы будете получать уведомления о содержательных изменениях базы выбранного региона.":"Возможно, ссылка устарела или подписка была удалена."}</p></section>;
}
