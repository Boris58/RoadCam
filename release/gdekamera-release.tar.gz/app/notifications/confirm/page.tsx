import Link from "next/link";
import ConfirmClient from "./confirm-client";
export default async function ConfirmPage({searchParams}:{searchParams:Promise<{token?:string|string[]}>}){const params=await searchParams;const token=Array.isArray(params.token)?params.token[0]:params.token;return <main className="unsubscribe-page"><Link href="/">← Где камера</Link><ConfirmClient token={token??""}/></main>}
