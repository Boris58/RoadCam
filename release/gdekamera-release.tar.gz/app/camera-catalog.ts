import cameraIndexData from "../public/camera-search-index.json";

export type CatalogCamera = { c: string; r: string; i: number; a: string; x: number; y: number; v: string[] };
export const cameraCatalog = cameraIndexData as CatalogCamera[];

export const cities = [
  { slug: "moskva", name: "Москва", regionCode: "77", terms: ["москва"] },
  { slug: "sankt-peterburg", name: "Санкт-Петербург", regionCode: "78", terms: ["санкт-петербург", "спб"] },
  { slug: "penza", name: "Пенза", regionCode: "58", terms: ["пенза"] },
  { slug: "kazan", name: "Казань", regionCode: "16", terms: ["казань"] },
  { slug: "ufa", name: "Уфа", regionCode: "02", terms: ["уфа"] },
  { slug: "novosibirsk", name: "Новосибирск", regionCode: "54", terms: ["новосибирск"] },
  { slug: "ekaterinburg", name: "Екатеринбург", regionCode: "66", terms: ["екатеринбург"] },
  { slug: "nizhniy-novgorod", name: "Нижний Новгород", regionCode: "52", terms: ["нижний новгород"] },
  { slug: "krasnoyarsk", name: "Красноярск", regionCode: "24", terms: ["красноярск"] },
  { slug: "chelyabinsk", name: "Челябинск", regionCode: "74", terms: ["челябинск"] },
  { slug: "samara", name: "Самара", regionCode: "63", terms: ["самара"] },
  { slug: "omsk", name: "Омск", regionCode: "55", terms: ["омск"] },
  { slug: "rostov-na-donu", name: "Ростов-на-Дону", regionCode: "61", terms: ["ростов-на-дону", "ростов на дону"] },
  { slug: "krasnodar", name: "Краснодар", regionCode: "23", terms: ["краснодар"] },
  { slug: "voronezh", name: "Воронеж", regionCode: "36", terms: ["воронеж"] },
  { slug: "perm", name: "Пермь", regionCode: "59", terms: ["пермь"] },
  { slug: "volgograd", name: "Волгоград", regionCode: "34", terms: ["волгоград"] },
  { slug: "saratov", name: "Саратов", regionCode: "64", terms: ["саратов"] },
  { slug: "tyumen", name: "Тюмень", regionCode: "72", terms: ["тюмень"] },
  { slug: "tula", name: "Тула", regionCode: "71", terms: ["тула"] },
] as const;

export function findCamera(regionCode: string, id: number) {
  return cameraCatalog.find((camera) => camera.c === regionCode && camera.i === id);
}

export function camerasForCity(city: (typeof cities)[number]) {
  const terms = city.terms as readonly string[];
  return cameraCatalog.filter((camera) => camera.c === city.regionCode && terms.some((term) => camera.a.toLocaleLowerCase("ru").includes(term)));
}
