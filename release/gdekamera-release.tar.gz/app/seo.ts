import type { Camera } from "./roadcam-app";

export const SITE_URL = "https://гдекамера.рф";

export function jsonLd(value: unknown) {
  return JSON.stringify(value).replace(/</g, "\\u003c");
}

export function cameraCountText(count: number) {
  const mod100 = count % 100;
  const mod10 = count % 10;
  const word = mod100 >= 11 && mod100 <= 14 ? "камер" : mod10 === 1 ? "камера" : mod10 >= 2 && mod10 <= 4 ? "камеры" : "камер";
  return `${count.toLocaleString("ru-RU")} ${word}`;
}

export function regionLocative(name: string) {
  if (name === "Москва") return "Москве";
  if (name === "Санкт-Петербург") return "Санкт-Петербурге";
  if (name === "Еврейская автономная область") return "Еврейской автономной области";
  if (name.startsWith("Республика ")) return `Республике ${name.slice("Республика ".length)}`;
  if (name.endsWith("ская Республика")) return `${name.slice(0, -"ская Республика".length)}ской Республике`;
  if (name.endsWith("ая область")) return `${name.slice(0, -"ая область".length)}ой области`;
  if (name.endsWith("яя область")) return `${name.slice(0, -"яя область".length)}ей области`;
  if (name.endsWith("ий край")) return `${name.slice(0, -"ий край".length)}ом крае`;
  return `регионе «${name}»`;
}

export function regionJsonLd({
  name,
  path,
  cameras,
  totalCount,
}: {
  name: string;
  path: string;
  cameras: Pick<Camera, "address" | "lat" | "lng">[];
  totalCount?: number;
}) {
  const pageUrl = `${SITE_URL}${path}`;
  return {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "BreadcrumbList",
        itemListElement: [
          { "@type": "ListItem", position: 1, name: "Главная", item: `${SITE_URL}/` },
          { "@type": "ListItem", position: 2, name, item: pageUrl },
        ],
      },
      {
        "@type": "ItemList",
        name: `Камеры ГИБДД — ${name}`,
        description: `Карта стационарных, передвижных и мобильных камер фотовидеофиксации: ${name}`,
        url: pageUrl,
        numberOfItems: totalCount ?? cameras.length,
        itemListElement: cameras.slice(0, 20).map((camera, index) => ({
          "@type": "ListItem",
          position: index + 1,
          item: {
            "@type": "Place",
            name: `Камера: ${camera.address}`,
            geo: {
              "@type": "GeoCoordinates",
              latitude: camera.lat,
              longitude: camera.lng,
            },
            address: {
              "@type": "PostalAddress",
              streetAddress: camera.address,
              addressRegion: name,
              addressCountry: "RU",
            },
          },
        })),
      },
    ],
  };
}
