import OfficialRegionApp from "../../official-region-app";
import RoadCamApp from "../../roadcam-app";
import type { Metadata } from "next";
import officialRegionsData from "../../../public/official-regions-summary.json";
import officialRegionsSeoData from "../../../public/official-regions-seo.json";
import moscowCameras from "../../../public/cameras-moscow-oblast.json";
import penzaCameras from "../../../public/cameras-penza.json";
import { notFound } from "next/navigation";
import { cameraCountText, jsonLd, regionJsonLd, regionLocative } from "../../seo";
import RegionBreadcrumbs from "../../region-breadcrumbs";
import RegionSeoContent from "../../region-seo-content";

type RegionSummary = Record<string, { code: string; name: string; count: number; sourceDate: string }>;
const regions = officialRegionsData as RegionSummary;
const specialRegions: RegionSummary = {
  "50": { code: "50", name: "Московская область", count: moscowCameras.length, sourceDate: "август 2026" },
  "58": { code: "58", name: "Пензенская область", count: penzaCameras.length, sourceDate: "24 сентября 2026" },
};
type RegionSeo = Record<string, { cameras: Array<{ address: string; lat: number; lng: number }>; sourceDate?:string; sourceUrl?:string; types?:{stationary?:number;portable?:number;dummy?:number;unspecified?:number}; topViolations?:Array<{name:string;count:number}> }>;
const regionsSeo = officialRegionsSeoData as RegionSeo;

function summarize(cameras: Array<{cameraType?:string;violations?:string[]}>) {
  const types={stationary:0,portable:0,dummy:0,unspecified:0}; const counts=new Map<string,number>();
  for(const camera of cameras){const type=camera.cameraType??"stationary";if(type in types)types[type as keyof typeof types]++;for(const violation of camera.violations??[])counts.set(violation,(counts.get(violation)??0)+1);}
  return {types,topViolations:[...counts.entries()].sort((a,b)=>b[1]-a[1]).slice(0,6).map(([name,count])=>({name,count}))};
}

export function generateStaticParams() {
  return [...new Set([...Object.keys(regions), ...Object.keys(specialRegions)])].map((code) => ({ code }));
}

export async function generateMetadata({ params }: { params: Promise<{ code: string }> }): Promise<Metadata> {
  const { code: rawCode } = await params;
  const code = rawCode.padStart(2, "0");
  const region = regions[code] ?? specialRegions[code];
  const name = region?.name;
  const count = region?.count;
  if (!name) return { title: "Регион не найден", robots: { index: false, follow: false } };
  const title = `Камеры ГИБДД в ${regionLocative(name)}`;
  const description = `Карта камер фотовидеофиксации: ${name}.${count ? ` В базе ${cameraCountText(count)}.` : ""} Адреса, координаты и фиксируемые нарушения.`;
  return {
    title,
    description,
    alternates: { canonical: `/region/${code}` },
    openGraph: { type: "website", locale: "ru_RU", url: `/region/${code}`, title: `${title}${count ? ` — ${cameraCountText(count)} на карте` : ""}`, description },
    twitter: { card: "summary", title, description },
  };
}

export default async function OfficialRegionPage({ params, searchParams }: { params: Promise<{ code: string }>; searchParams: Promise<{ camera?: string | string[] }> }) {
  const { code: rawCode } = await params;
  const query = await searchParams;
  const rawCameraId = Array.isArray(query.camera) ? query.camera[0] : query.camera;
  const focusCameraId = rawCameraId && /^\d+$/.test(rawCameraId) ? Number(rawCameraId) : undefined;
  const code = rawCode.padStart(2, "0");
  const region = regions[code] ?? specialRegions[code];
  if (!region) notFound();
  const cameras = code === "50" ? moscowCameras : code === "58" ? penzaCameras : regionsSeo[code]?.cameras ?? [];
  const seoStats = code === "50" ? summarize(moscowCameras) : code === "58" ? summarize(penzaCameras) : regionsSeo[code];
  const structuredData = regionJsonLd({ name: region.name, path: `/region/${code}`, cameras, totalCount: region.count });
  return <div className="region-page-wrap">
    <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd(structuredData) }} />
    <div className="map-heading region-server-heading">
      <RegionBreadcrumbs regionName={region.name} />
      <span className="eyebrow">{region.name}</span>
      <h1 className="map-seo-heading">{`Камеры ГИБДД в ${regionLocative(region.name)}`}</h1>
    </div>
    {code === "50" ? <RoadCamApp cameras={moscowCameras} regionName={region.name} regionCode={code} mapCenter={[55.55, 37.75]} mapZoom={8} sourceDate={region.sourceDate} showSeoHeading={false} focusCameraId={focusCameraId} />
      : code === "58" ? <RoadCamApp cameras={penzaCameras} regionName={region.name} regionCode={code} mapCenter={[53.12, 45.15]} mapZoom={8} sourceDate={region.sourceDate} showSeoHeading={false} focusCameraId={focusCameraId} />
      : <OfficialRegionApp code={code} focusCameraId={focusCameraId} />}
    <RegionSeoContent name={region.name} code={code} count={region.count} sourceDate={region.sourceDate} stats={seoStats} />
  </div>;
}
