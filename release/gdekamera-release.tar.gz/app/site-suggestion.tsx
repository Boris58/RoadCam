"use client";

import { FormEvent, useState } from "react";

export default function SiteSuggestion() {
  const [open, setOpen] = useState(false);
  const [status, setStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [message, setMessage] = useState("");

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setStatus("sending"); setMessage("");
    const response = await fetch("/api/feedback", { method: "POST", body: new FormData(event.currentTarget) });
    const result = await response.json() as { error?: string; requestId?: string };
    if (!response.ok) { setStatus("error"); setMessage(result.error ?? "Не удалось отправить предложение."); return; }
    setStatus("sent"); setMessage(`Спасибо! Предложение ${result.requestId ?? ""} передано администратору.`);
  };

  return <>
    <button className="suggestion-button" type="button" onClick={() => { setOpen(true); setStatus("idle"); setMessage(""); }} aria-label="Предложить улучшение"><span aria-hidden="true">✦</span><b>Предложить улучшение</b></button>
    {open && <div className="suggestion-backdrop" role="presentation" onPointerDown={event => { if (event.currentTarget === event.target) setOpen(false); }}><section className="suggestion-dialog" role="dialog" aria-modal="true" aria-labelledby="suggestion-title"><button className="support-close" onClick={() => setOpen(false)} aria-label="Закрыть">×</button>
      {status === "sent" ? <div className="suggestion-success"><span>✓</span><h2 id="suggestion-title">Предложение отправлено</h2><p>{message}</p><button onClick={() => setOpen(false)}>Готово</button></div> : <><span className="legal-kicker">Обратная связь</span><h2 id="suggestion-title">Помогите улучшить сервис</h2><p>Расскажите об идее, неудобстве, ошибке или предложите сотрудничество. Сообщение появится в административной очереди.</p><form onSubmit={submit}><input type="hidden" name="kind" value="service-suggestion"/><input className="bot-field" tabIndex={-1} autoComplete="off" name="website"/><label>Тема<select name="type" required><option value="">Выберите тему</option><option>Предложение по улучшению</option><option>Неудобство или ошибка</option><option>Сотрудничество</option><option>Другое</option></select></label><label>Ваше предложение<textarea name="description" minLength={10} maxLength={1500} required placeholder="Опишите, что стоит изменить или добавить"/></label><label>Email для ответа <em>необязательно</em><input name="email" type="email" maxLength={254} placeholder="name@example.ru"/></label><label>Проверка: сколько будет 5 + 6?<input name="captcha" inputMode="numeric" required/></label>{message&&<p className="suggestion-error">{message}</p>}<button className="primary-submit" disabled={status === "sending"}>{status === "sending" ? "Отправляем…" : "Отправить предложение"}</button></form></>}
    </section></div>}
  </>;
}
