export const METRIKA_COUNTER_ID = 112081610;

type GoalParams = Record<string, string | number | boolean>;
type YmFunction = (id: number, method: "reachGoal", goal: string, params?: GoalParams) => void;

export function reachMetrikaGoal(goal: string, params?: GoalParams) {
  if (typeof window === "undefined") return;
  const metrikaWindow = window as typeof window & { ym?: YmFunction };
  metrikaWindow.ym?.(METRIKA_COUNTER_ID, "reachGoal", goal, params);
}
