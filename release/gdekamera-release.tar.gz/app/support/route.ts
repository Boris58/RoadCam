import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

const allowedAmounts = new Set(["100", "300", "500", "other"]);
const defaultSupportUrl = "https://pay.cloudtips.ru/p/3cfb3e14";

export function GET(request: NextRequest) {
  const amount = request.nextUrl.searchParams.get("amount") ?? "other";
  const safeAmount = allowedAmounts.has(amount) ? amount : "other";
  const specificUrl = process.env[`SUPPORT_URL_${safeAmount.toUpperCase()}`];
  const destination = specificUrl || process.env.SUPPORT_URL || defaultSupportUrl;

  try {
    const url = new URL(destination);
    if (url.protocol !== "https:") throw new Error("Only HTTPS support links are allowed");
    return NextResponse.redirect(url, 302);
  } catch {
    return NextResponse.json({ error: "Ссылка поддержки настроена неверно" }, { status: 503 });
  }
}
