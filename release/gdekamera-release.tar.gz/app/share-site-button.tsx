"use client";

import { useState } from "react";
import { reachMetrikaGoal } from "./metrika-goal";

export default function ShareSiteButton() {
  const [copied, setCopied] = useState(false);

  const share = async () => {
    const data = {
      title: "Где камера — карта дорожных камер России",
      text: "Карта дорожных камер: адреса, координаты и виды фиксируемых нарушений.",
      url: "https://гдекамера.рф/",
    };
    try {
      if (navigator.share) await navigator.share(data);
      else {
        await navigator.clipboard.writeText(data.url);
        setCopied(true);
        window.setTimeout(() => setCopied(false), 2500);
      }
      reachMetrikaGoal("share_site", { surface: "home" });
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      setCopied(false);
    }
  };

  return <button className="share-site-button" type="button" onClick={() => void share()} aria-label="Поделиться сайтом «Где камера»">
    <span aria-hidden="true">↗</span>{copied ? "Ссылка скопирована" : "Поделиться сайтом"}
  </button>;
}
