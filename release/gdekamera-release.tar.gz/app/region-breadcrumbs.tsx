import Link from "next/link";

export default function RegionBreadcrumbs({ regionName }: { regionName: string }) {
  return (
    <nav className="region-breadcrumbs" aria-label="Хлебные крошки">
      <ol>
        <li><Link href="/">Главная</Link></li>
        <li aria-current="page">{regionName}</li>
      </ol>
    </nav>
  );
}
