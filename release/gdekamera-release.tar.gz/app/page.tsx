import RegionHome from "./region-home";

export default async function Home({ searchParams }: { searchParams: Promise<{ search?: string | string[] }> }) {
  const params = await searchParams;
  const search = Array.isArray(params.search) ? params.search[0] : params.search;
  return <RegionHome initialQuery={search ?? ""} />;
}
