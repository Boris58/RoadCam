import Link from "next/link";

export default function NotFound() {
  return (
    <main className="not-found-page">
      <Link className="brand" href="/" aria-label="Где камера — главная"><span className="brand-mark" aria-hidden="true"><span /></span><span className="brand-name">Где <span>камера</span></span></Link>
      <p className="not-found-code">404</p>
      <h1>Такой страницы нет</h1>
      <p>Адрес мог измениться. Вернитесь на главную или откройте карту популярного региона.</p>
      <nav aria-label="Популярные регионы">
        <Link href="/region/77">Москва</Link>
        <Link href="/region/50">Московская область</Link>
        <Link href="/region/58">Пензенская область</Link>
      </nav>
      <Link className="not-found-home" href="/">Выбрать регион на карте России</Link>
    </main>
  );
}
