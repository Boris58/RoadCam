import type { Metadata } from "next";
import { Geist, Geist_Mono, Unbounded } from "next/font/google";
import "./globals.css";
import LocationOffer from "./location-offer";
import YandexMetrika from "./yandex-metrika";
import { jsonLd, SITE_URL } from "./seo";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const unbounded = Unbounded({
  variable: "--font-unbounded",
  subsets: ["cyrillic", "latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://гдекамера.рф"),
  title: {
    default: "Где камера — карта дорожных камер России",
    template: "%s | Где камера",
  },
  description: "Карта стационарных, передвижных и мобильных комплексов фотовидеофиксации России: адреса, координаты и виды нарушений.",
  alternates: {
    canonical: "/",
  },
  openGraph: {
    type: "website",
    locale: "ru_RU",
    url: "/",
    siteName: "Где камера",
    title: "Где камера — карта дорожных камер России",
    description: "Адреса, координаты и виды нарушений, фиксируемых дорожными камерами России.",
    images: [{ url: "/og.png", width: 1200, height: 630, alt: "Где камера — карта дорожных камер России" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Где камера — карта дорожных камер России",
    description: "Карта стационарных, передвижных и мобильных камер фотовидеофиксации России.",
    images: ["/og.png"],
  },
  robots: {
    index: true,
    follow: true,
  },
  icons: {
    icon: [
      { url: "/favicon.svg", type: "image/svg+xml" },
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
    ],
    shortcut: "/favicon.svg",
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  manifest: "/site.webmanifest",
};

const websiteJsonLd = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: "Где камера",
  url: SITE_URL,
  description: "Карта дорожных камер ГИБДД России",
  inLanguage: "ru-RU",
  potentialAction: {
    "@type": "SearchAction",
    target: `${SITE_URL}/?search={search_term_string}`,
    "query-input": "required name=search_term_string",
  },
};

const organizationJsonLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "Где камера",
  url: SITE_URL,
  logo: `${SITE_URL}/og.png`,
  description: "Общественно полезный справочник дорожных камер фотовидеофиксации России на основе открытых и пользовательских данных.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru">
      <head><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd([websiteJsonLd, organizationJsonLd]) }} /></head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${unbounded.variable} antialiased`}
      >
        {children}
        <LocationOffer />
        <YandexMetrika />
        {/* The noscript tracking pixel is required by Yandex Metrika. */}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <noscript><div><img src="https://mc.yandex.ru/watch/112081610" style={{ position: "absolute", left: "-9999px" }} alt="" /></div></noscript>
      </body>
    </html>
  );
}
