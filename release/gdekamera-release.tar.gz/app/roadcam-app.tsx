"use client";

import { FormEvent, useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { LayerGroup, LeafletMouseEvent, Map as LeafletMap, Marker } from "leaflet";
import Link from "next/link";
import RegionBreadcrumbs from "./region-breadcrumbs";
import { regionLocative } from "./seo";
import { reachMetrikaGoal } from "./metrika-goal";
import { VIOLATION_GROUPS, groupAvailableViolations, normalizeViolationList } from "./violation-catalog";

type WeightControl = { controlType: "АПВГК" | "СПВК"; status?: "active" | "testing"; lastVerified: string; sourceName: string; sourceUrl: string; geoPrecision?: "exact" | "approximate"; operator?: string; highway?: string; km?: string };
type CameraStatus = { working: number; missing: number; total: number; status: "working" | "uncertain" | "missing"; moderatorNote?: string };
export type Camera = { id: number; address: string; violations: string[]; lat: number; lng: number; speedLimit?: number; truckSpeedLimit?: number; cameraCodes?: string[]; cameraModel?: string; cameraType?: "stationary" | "portable" | "dummy" | "unspecified"; cameraSubtype?: "traffic" | "parking"; operator?: string; article?: string; violationCodes?: string[]; directions?: string[]; schedule?: string; sourceDate?: string; recordCount?: number; verification?: "official" | "pending" | "community"; sourceKind?: "official-current" | "official-previous" | "community"; sourceName?: string; sourceUrl?: string; weightControl?: WeightControl };
export type MobileSegment = { id: number; name: string; coordinates: [number, number][]; geometry?: "polygon" | "polyline"; schedule: string; violations: string[] };
export type MobileRoute = { id: number; name: string; segments: MobileSegment[] };
type CameraSection = "photo" | "history" | "route" | "report";
type RoadCamAppProps = { cameras: Camera[]; mobileRoutes?: MobileRoute[]; regionName: string; regionCode?: string; mapCenter: [number, number]; mapZoom?: number; sourceDate: string; sourceName?: string; sourceUrl?: string; showSeoHeading?: boolean; focusCameraId?: number };

function supportLink(amount: 100 | 300 | 500 | "other") {
  return `/support?amount=${amount}`;
}

const violationVisuals = [
  { key: "speed", match: /скорост/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><path class="icon-stroke" d="M15 72a35 35 0 0170 0"/><path class="icon-stroke ticks" d="M22 64l10-3M33 43l7 9M50 36v13M67 43l-7 9"/><path class="icon-red-stroke needle" d="M50 75l23-28"/></svg>', label: "Скорость" },
  { key: "oncoming", match: /встречн/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><path class="icon-stroke" d="M18 8v84M82 8v84M50 8v84" stroke-dasharray="9 8"/><path class="icon-fill" d="M34 18l-12 16h8v26h8V34h8zM66 82l12-16h-8V40h-8v26h-8z"/></svg>', label: "Встречная полоса" },
  { key: "solid", match: /сплошн|разметк.*1\.1/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><path class="icon-stroke thick" d="M50 8v84"/><path class="icon-red-stroke" d="M18 68l25-25M18 68l17 2M18 68l2-17"/></svg>', label: "Сплошная линия" },
  { key: "light", match: /светофор|запрещающ.*сигнал/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><rect class="icon-fill" x="27" y="5" width="46" height="90" rx="12"/><circle class="icon-red" cx="50" cy="25" r="14"/><circle class="icon-yellow" cx="50" cy="51" r="14"/><circle class="icon-green-stroke" cx="50" cy="77" r="11"/></svg>', label: "Красный и жёлтый сигнал" },
  { key: "belt", match: /рем(?:е|ё)?н/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><circle class="icon-fill" cx="50" cy="18" r="13"/><path class="icon-fill" d="M21 94V58q0-25 29-25t29 25v36z"/><circle class="icon-cut" cx="41" cy="54" r="8"/><circle class="icon-cut" cx="59" cy="54" r="8"/><path class="icon-red-stroke belt" d="M27 17l46 77"/></svg>', label: "Ремень безопасности" },
  { key: "phone", match: /телефон/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><rect class="icon-stroke" x="24" y="5" width="52" height="90" rx="13"/><circle class="icon-stroke" cx="39" cy="24" r="9"/><circle class="icon-stroke" cx="61" cy="24" r="9"/><circle class="icon-stroke" cx="39" cy="46" r="9"/><circle class="icon-fill" cx="61" cy="46" r="4"/></svg>', label: "Телефон" },
  { key: "daylights", match: /светлое время|внешн.*светов/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><path class="icon-fill" d="M12 28h39q23 0 23 22T51 72H12z"/><path class="icon-cut" d="M46 35q17 3 17 15T46 65z"/><path class="icon-yellow-stroke" d="M79 31l12-7M82 50h14M79 69l12 7"/><circle class="icon-yellow" cx="20" cy="18" r="8"/><path class="icon-yellow-stroke" d="M20 3v7M5 18h7M28 18h7M10 8l5 5M30 8l-5 5"/></svg>', label: "Фары / ДХО" },
  { key: "headlights", match: /фар.*темное время/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><path class="icon-fill" d="M12 28h39q23 0 23 22T51 72H12z"/><path class="icon-cut" d="M46 35q17 3 17 15T46 65z"/><path class="icon-blue-stroke" d="M79 31l12-7M82 50h14M79 69l12 7"/><path class="icon-blue" d="M25 5a15 15 0 1015 23A12 12 0 0125 5z"/></svg>', label: "Фары ночью" },
  { key: "stop-sign", match: /знак[а-яё]*\s*2[.,]5|без\s+(?:полной\s+)?остановк.*(?:2[.,]5|stop)/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><path class="stop-sign-shape" d="M31 5h38l26 26v38L69 95H31L5 69V31z"/><text class="stop-sign-text" x="50" y="59" text-anchor="middle">STOP</text></svg>', label: "Знак 2.5 STOP" },
  { key: "stop", match: /стоп.?лини/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><rect class="icon-stroke thick" x="5" y="24" width="90" height="52" rx="6"/><text class="icon-text" x="50" y="59" text-anchor="middle">СТОП</text></svg>', label: "Стоп-линия" },
  { key: "pedestrian", match: /пешеход/i, icon: '<svg class="rc-icon pedestrian-icon" viewBox="0 0 100 100"><rect class="sign-white" x="2" y="2" width="96" height="96" rx="8"/><rect class="sign-blue" x="7" y="7" width="86" height="86" rx="5"/><path class="sign-white" d="M50 12L89 85q2 4-3 4H14q-5 0-3-4l35-71q2-4 4-2z"/><path class="sign-black" d="M22 80l8-12h9l-4 12zm24 0l2-12h8l2 12zm22 0l-6-12h9l8 12z"/><circle class="sign-black" cx="50" cy="31" r="7"/><path class="sign-black" d="M47 40l7-4 13 8q4 2 3 6l-1 11q-1 4-5 2V50l-6-3v13l10 18q2 4-2 6t-6-2l-9-16-6 6-3 11q-1 4-5 3t-3-5l4-15 10-10v-9l-6 5-5 7q-3 4-6 1t0-6l8-11z"/></svg>', label: "Пешеходный переход" },
  { key: "lane", match: /полос.*маршрут|обществен.*транспорт/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><rect class="icon-stroke" x="14" y="7" width="72" height="86" rx="5"/><path class="icon-stroke" d="M50 8v84" stroke-dasharray="9 8"/><rect class="icon-stroke" x="55" y="30" width="24" height="38" rx="5"/><text class="icon-text small" x="67" y="57" text-anchor="middle">А</text></svg>', label: "Выделенная полоса" },
  { key: "parking", match: /остановк|стоянк|парков/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><circle class="sign-blue" cx="50" cy="50" r="42"/><circle class="icon-red-stroke thick" cx="50" cy="50" r="42"/><path class="icon-red-stroke thick" d="M23 23l54 54M77 23L23 77"/></svg>', label: "Остановка запрещена" },
  { key: "island", match: /островок.*безопас/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><path class="icon-stroke" d="M12 88L50 12l38 76z"/><path class="icon-red-stroke" d="M30 77l31-49M43 82l27-42M56 86l22-34"/></svg>', label: "Островок безопасности" },
  { key: "turn", match: /поворот|разворот/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><path class="icon-stroke turn-arrow" d="M76 82V56c0-16-11-27-27-27H27M43 13L27 29l16 16"/></svg>', label: "Поворот / разворот" },
  { key: "lane-direction", match: /направлени.*движени.*полос|движени.*по полос/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><path class="icon-stroke" d="M12 92V8M88 92V8M50 92V8" stroke-dasharray="8 7"/><path class="icon-blue-stroke direction-arrow" d="M31 82V29M20 40l11-12 11 12M69 82V48M58 59l11-12 11 12"/></svg>', label: "Направление по полосам" },
  { key: "sign-direction", match: /движени.*нарушени.*требовани.*знак|требовани.*знак.*размет/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><circle class="sign-blue" cx="50" cy="50" r="44"/><path class="sign-white-stroke direction-arrow" d="M50 78V25M34 42l16-17 16 17"/><circle class="icon-red" cx="78" cy="78" r="16"/><text class="sign-white icon-text small" x="78" y="85" text-anchor="middle">!</text></svg>', label: "Знаки и разметка" },
  { key: "truck", match: /грузов|масc|весогабарит/i, icon: '<svg class="rc-icon" viewBox="0 0 100 100"><path class="icon-fill" d="M5 23h57v48H5zM62 39h20l13 17v15H62z"/><path class="icon-cut" d="M69 44h10l8 12H69z"/><circle class="icon-wheel" cx="25" cy="76" r="11"/><circle class="icon-wheel" cx="78" cy="76" r="11"/></svg>', label: "Грузовой транспорт" },
] as const;

export default function RoadCamApp({ cameras, mobileRoutes = [], regionName, regionCode, mapCenter, mapZoom = 8, sourceDate, sourceName, sourceUrl, showSeoHeading = true, focusCameraId }: RoadCamAppProps) {
  const mapElement = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletMap | null>(null);
  const markersRef = useRef<LayerGroup | null>(null);
  const markerByIdRef = useRef<Map<number, Marker>>(new Map());
  const locationLayerRef = useRef<LayerGroup | null>(null);
  const guidanceLayerRef = useRef<LayerGroup | null>(null);
  const highlightedCameraIdRef = useRef<number | null>(null);
  const locationWatchRef = useRef<number | null>(null);
  const alertLevelRef = useRef<Map<number, number>>(new Map());
  const previousDistanceRef = useRef<Map<number, number>>(new Map());
  const autoDriveStartedRef = useRef(false);
  const pendingFocusCameraIdRef = useRef<number | null>(focusCameraId ?? null);
  const handledFocusCameraIdRef = useRef<number | null>(null);
  const [query, setQuery] = useState("");
  const [selectedViolation, setSelectedViolation] = useState("Все нарушения");
  const [selectedCameraType, setSelectedCameraType] = useState<"all" | "stationary" | "portable" | "mobile" | "dummy" | "unspecified">("all");
  const [selectedSpeedLimit, setSelectedSpeedLimit] = useState<number | "all" | "unknown">("all");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [supportOpen, setSupportOpen] = useState(false);
  const [addCameraOpen, setAddCameraOpen] = useState(false);
  const [cameraPickMode, setCameraPickMode] = useState(false);
  const [draftPoint, setDraftPoint] = useState<{ lat: number; lng: number } | null>(null);
  const [addCameraStatus, setAddCameraStatus] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [addCameraRequestId, setAddCameraRequestId] = useState("");
  const [addCameraFileName, setAddCameraFileName] = useState("");
  const [addViolationPickerOpen, setAddViolationPickerOpen] = useState(false);
  const [selectedAddViolations, setSelectedAddViolations] = useState<string[]>([]);
  const [listOpen, setListOpen] = useState(true);
  const [mapReady, setMapReady] = useState(false);
  const [selectedCamera, setSelectedCamera] = useState<Camera | null>(null);
  const [activeSection, setActiveSection] = useState<CameraSection>("photo");
  const [photoFileName, setPhotoFileName] = useState("");
  const [reportFileName, setReportFileName] = useState("");
  const [photoStatus, setPhotoStatus] = useState<"idle" | "sending" | "sent" | "captcha" | "error">("idle");
  const [reportStatus, setReportStatus] = useState<"idle" | "sending" | "sent" | "captcha" | "error">("idle");
  const [communityCameras, setCommunityCameras] = useState<Camera[]>([]);
  const [cameraOverrides, setCameraOverrides] = useState<Record<string, Partial<Camera>>>({});
  const [hiddenCameraIds, setHiddenCameraIds] = useState<string[]>([]);
  const [locationMessage, setLocationMessage] = useState("");
  const [warningActive, setWarningActive] = useState(false);
  const [nearestWarning, setNearestWarning] = useState<{ camera: Camera; distance: number } | null>(null);
  const [truckMode, setTruckMode] = useState(false);
  const [weightControls, setWeightControls] = useState<Record<number, WeightControl>>({});
  const [weightControlCameras, setWeightControlCameras] = useState<Camera[]>([]);
  const [cameraStatuses, setCameraStatuses] = useState<Record<string, CameraStatus>>({});
  const [statusSending, setStatusSending] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");

  useEffect(() => {
    const saved = window.localStorage.getItem("roadcam-vehicle-mode");
    const timer = window.setTimeout(() => setTruckMode(saved === "truck"), 0);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!regionCode) return;
    let active = true;
    fetch(`/weight-control/${regionCode}.json`).then(response => response.ok ? response.json() : null).then((data: { lastVerified?: string; sourceName?: string; sourceUrl?: string; controls?: Array<{ cameraId: number; controlType: "АПВГК" | "СПВК"; status?: "active" | "testing" }>; cameras?: Camera[] } | null) => {
      if (!active || !data) return;
      setWeightControls(Object.fromEntries((data.controls ?? []).map(item => [item.cameraId, { controlType: item.controlType, status: item.status ?? "active", lastVerified: data.lastVerified ?? "", sourceName: data.sourceName ?? "", sourceUrl: data.sourceUrl ?? "" }])));
      setWeightControlCameras(data.cameras ?? []);
    }).catch(() => { if (active) { setWeightControls({}); setWeightControlCameras([]); } });
    return () => { active = false; };
  }, [regionCode]);

  useEffect(() => {
    if (!regionCode) return;
    fetch(`/api/camera-status?region=${encodeURIComponent(regionCode)}`, { cache: "no-store" }).then(r => r.ok ? r.json() : { statuses: {} }).then((data: { statuses?: Record<string, CameraStatus> }) => setCameraStatuses(data.statuses ?? {})).catch(() => setCameraStatuses({}));
  }, [regionCode]);

  const voteCameraStatus = async (vote: "working" | "missing") => {
    if (!selectedCamera || !regionCode || statusSending) return;
    setStatusSending(true); setStatusMessage("");
    const key = `${regionCode}:${selectedCamera.id}`;
    try { const response = await fetch("/api/camera-status", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ cameraKey: key, vote }) }); const data = await response.json() as CameraStatus & { error?: string }; if (!response.ok) throw new Error(data.error); setCameraStatuses(items => ({ ...items, [key]: data })); setStatusMessage("Спасибо, ваш ответ учтён. Повторный выбор на этом устройстве изменит предыдущий голос."); reachMetrikaGoal("camera_status_vote", { vote, region: regionName }); } catch { setStatusMessage("Не удалось сохранить ответ. Попробуйте ещё раз."); } finally { setStatusSending(false); }
  };

  const selectVehicleMode = (truck: boolean) => {
    setTruckMode(truck); window.localStorage.setItem("roadcam-vehicle-mode", truck ? "truck" : "car");
    reachMetrikaGoal("vehicle_mode", { mode: truck ? "truck" : "car", region: regionName });
  };

  useEffect(() => {
    let active = true;
    fetch(`/api/cameras?region=${encodeURIComponent(regionName)}`, { cache: "no-store" })
      .then((response) => response.ok ? response.json() as Promise<{ cameras?: Camera[]; overrides?: Record<string, Partial<Camera>>; hiddenIds?: string[] }> : { cameras: [] })
      .then((result) => { if (active) { setCommunityCameras(result.cameras ?? []); setCameraOverrides(result.overrides ?? {}); setHiddenCameraIds(result.hiddenIds ?? []); } })
      .catch(() => { if (active) setCommunityCameras([]); });
    return () => { active = false; };
  }, [regionName]);

  const allCameras = useMemo(() => { const base=[...cameras.filter((camera) => !hiddenCameraIds.some((key) => key.endsWith(`:${camera.id}`))).map((camera) => {
    const override = Object.entries(cameraOverrides).find(([key]) => key.endsWith(`:${camera.id}`))?.[1];
    const current = override ? { ...camera, ...override } : camera;
    const merged = weightControls[camera.id] ? { ...current, weightControl: weightControls[camera.id] } : current;
    return { ...merged, violations: normalizeViolationList(merged.violations) };
  }), ...communityCameras.map((camera) => ({ ...camera, violations: normalizeViolationList(camera.violations) }))]; const newWeight=truckMode?weightControlCameras.filter(point=>!hiddenCameraIds.some(key=>key.endsWith(`:${point.id}`))).map(point=>{const override=Object.entries(cameraOverrides).find(([key])=>key.endsWith(`:${point.id}`))?.[1];const merged=override?{...point,...override}:point;return {...merged,violations:normalizeViolationList(merged.violations)}}).filter(point=>!base.some(camera=>distanceMeters(point.lat,point.lng,camera.lat,camera.lng)<70)):[]; return [...base,...newWeight]; }, [cameras, communityCameras, cameraOverrides, hiddenCameraIds, weightControls, weightControlCameras, truckMode]);

  const normalizedMobileRoutes = useMemo(() => mobileRoutes.map((route) => ({
    ...route,
    segments: route.segments.map((segment) => ({ ...segment, violations: normalizeViolationList(segment.violations) })),
  })), [mobileRoutes]);

  const allViolations = useMemo(
    () => [...new Set([...allCameras.flatMap((camera) => camera.violations), ...normalizedMobileRoutes.flatMap((route) => route.segments.flatMap((segment) => segment.violations))])],
    [allCameras, normalizedMobileRoutes],
  );
  const availableViolationGroups = useMemo(() => groupAvailableViolations(allViolations), [allViolations]);
  const availableSpeedLimits = useMemo(
    () => [...new Set(allCameras.flatMap((camera) => typeof camera.speedLimit === "number" ? [camera.speedLimit] : []))].sort((a, b) => a - b),
    [allCameras],
  );
  const filteredCameras = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase("ru");
    return allCameras.filter((camera) => {
      const matchesQuery = !normalized || camera.address.toLocaleLowerCase("ru").includes(normalized) || camera.cameraCodes?.some((code) => code.toLocaleLowerCase("ru").includes(normalized)) || camera.directions?.some((direction) => direction.toLocaleLowerCase("ru").includes(normalized));
      const matchesViolation = selectedViolation === "Все нарушения" || camera.violations.includes(selectedViolation);
      const matchesType = selectedCameraType !== "mobile" && (selectedCameraType === "all" || (camera.cameraType ?? "stationary") === selectedCameraType);
      const matchesSpeed = selectedSpeedLimit === "all" || (selectedSpeedLimit === "unknown" ? typeof camera.speedLimit !== "number" : camera.speedLimit === selectedSpeedLimit);
      return matchesQuery && matchesViolation && matchesType && matchesSpeed;
    });
  }, [allCameras, query, selectedViolation, selectedCameraType, selectedSpeedLimit]);
  const filteredMobileRoutes = useMemo(() => {
    if (selectedCameraType !== "mobile") return [];
    const normalized = query.trim().toLocaleLowerCase("ru");
    return normalizedMobileRoutes.map((route) => ({
      ...route,
      segments: route.segments.filter((segment) => {
        const matchesQuery = !normalized || segment.name.toLocaleLowerCase("ru").includes(normalized) || route.name.toLocaleLowerCase("ru").includes(normalized);
        const matchesViolation = selectedViolation === "Все нарушения" || segment.violations.includes(selectedViolation);
        return matchesQuery && matchesViolation;
      }),
    })).filter((route) => route.segments.length > 0);
  }, [normalizedMobileRoutes, query, selectedCameraType, selectedViolation]);
  const cameraTypeCounts = useMemo(() => ({
    stationary: allCameras.filter((camera) => (camera.cameraType ?? "stationary") === "stationary").length,
    portable: allCameras.filter((camera) => camera.cameraType === "portable").length,
    mobile: mobileRoutes.length,
    dummy: allCameras.filter((camera) => camera.cameraType === "dummy").length,
    unspecified: allCameras.filter((camera) => camera.cameraType === "unspecified").length,
  }), [allCameras, mobileRoutes]);

  const cameraTypeLabel = (camera: Camera) => camera.cameraType === "portable" ? "Передвижной комплекс" : camera.cameraType === "dummy" ? "Муляж камеры" : camera.cameraType === "unspecified" ? "Тип комплекса не указан" : camera.cameraSubtype === "parking" ? "Стационарный парковочный комплекс" : "Стационарный комплекс";

  const openCameraDetails = useCallback((camera: Camera) => {
    mapRef.current?.closePopup();
    setSelectedCamera(camera);
    setActiveSection("photo");
    setPhotoFileName("");
    setReportFileName("");
    setPhotoStatus("idle");
    setReportStatus("idle");
    setStatusMessage("");
  }, []);

  useEffect(() => {
    if (!mapElement.current || mapRef.current) return;
    let cancelled = false;
    const markerIndex = markerByIdRef.current;
    import("leaflet").then(({ default: L }) => {
      if (cancelled || !mapElement.current) return;
      const map = L.map(mapElement.current, { zoomControl: false }).setView(mapCenter, mapZoom);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '<a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer" aria-label="Источник карты OpenStreetMap">© OSM</a>',
        maxZoom: 18,
      }).addTo(map);
      map.attributionControl.setPrefix(false);
      L.control.zoom({ position: "bottomright" }).addTo(map);
      mapRef.current = map;
      markersRef.current = L.layerGroup().addTo(map);
      setMapReady(true);
    });
    return () => {
      cancelled = true;
      mapRef.current?.remove();
      mapRef.current = null;
      markersRef.current = null;
      locationLayerRef.current = null;
      guidanceLayerRef.current = null;
      markerIndex.clear();
    };
  }, [mapCenter, mapZoom]);

  useEffect(() => () => {
    if (locationWatchRef.current !== null) navigator.geolocation?.clearWatch(locationWatchRef.current);
  }, []);

  const showUserLocation = useCallback(async (latitude: number, longitude: number, accuracy: number, follow = true) => {
    const map = mapRef.current;
    if (!map) return;
    const { default: L } = await import("leaflet");
    locationLayerRef.current?.remove();
    locationLayerRef.current = L.layerGroup([
      L.circle([latitude, longitude], { radius: Math.min(Math.max(accuracy, 12), 250), color: "#1769e0", weight: 1, fillColor: "#2f80ed", fillOpacity: .12, interactive: false }),
      L.circleMarker([latitude, longitude], { radius: 9, color: "#fff", weight: 3, fillColor: "#1769e0", fillOpacity: 1, interactive: false }),
    ]).addTo(map);
    if (follow) map.flyTo([latitude, longitude], Math.max(map.getZoom(), 15), { duration: .6 });
  }, []);

  const playCameraAlert = useCallback((message: string) => {
    window.speechSynthesis?.cancel();
    const speech = new SpeechSynthesisUtterance(message);
    speech.lang = "ru-RU"; speech.rate = 1.02; speech.pitch = 1.08;
    const russianVoice = window.speechSynthesis?.getVoices().find(voice => voice.lang.toLocaleLowerCase().startsWith("ru"));
    if (russianVoice) speech.voice = russianVoice;
    window.speechSynthesis?.speak(speech);
    if (document.hidden && "Notification" in window && Notification.permission === "granted") new Notification("Где камера", { body: message, tag: "roadcam-warning" });
  }, []);

  const clearCameraGuidance = useCallback(() => {
    guidanceLayerRef.current?.remove(); guidanceLayerRef.current = null;
    if (highlightedCameraIdRef.current !== null) markerByIdRef.current.get(highlightedCameraIdRef.current)?.getElement()?.classList.remove("approaching-camera-marker");
    highlightedCameraIdRef.current = null;
  }, []);

  const updateCameraGuidance = useCallback(async (latitude: number, longitude: number, camera?: Camera) => {
    const map = mapRef.current; if (!map) return;
    clearCameraGuidance(); if (!camera) return;
    const { default: L } = await import("leaflet");
    if (!mapRef.current) return;
    guidanceLayerRef.current = L.layerGroup([
      L.polyline([[latitude, longitude], [camera.lat, camera.lng]], { color: "#1769e0", weight: 5, opacity: .84, dashArray: "10 8", interactive: false }),
      L.circleMarker([camera.lat, camera.lng], { radius: 25, color: "#ff3b52", weight: 4, opacity: .95, fillColor: "#ffcfda", fillOpacity: .22, interactive: false, className: "approaching-camera-ring" }),
    ]).addTo(mapRef.current);
    highlightedCameraIdRef.current = camera.id;
    markerByIdRef.current.get(camera.id)?.getElement()?.classList.add("approaching-camera-marker");
  }, [clearCameraGuidance]);

  const spokenViolations = useCallback((camera: Camera) => {
    const names = camera.violations.map(violation => violationVisuals.find(item => item.match.test(violation))?.label ?? violation)
      .map(name => name.toLocaleLowerCase("ru").replace("ремень безопасности", "ремней").replace("телефон", "телефонов").replace("скорость", "скорости"));
    return [...new Set(names)].slice(0, 4).join(", ");
  }, []);

  const handleTrackedPosition = useCallback((position: GeolocationPosition, follow = false) => {
    const { latitude, longitude, accuracy } = position.coords;
    void showUserLocation(latitude, longitude, accuracy, follow);
    const candidates = allCameras.filter(camera => camera.cameraType !== "dummy").map(camera => ({ camera, distance: distanceMeters(latitude, longitude, camera.lat, camera.lng) })).filter(item => item.distance <= 1000).sort((a,b) => a.distance-b.distance);
    setNearestWarning(candidates[0] ?? null);
    void updateCameraGuidance(latitude, longitude, candidates[0]?.camera);
    candidates.slice(0, 1).forEach(({ camera, distance }) => {
      const previous = previousDistanceRef.current.get(camera.id), level = alertLevelRef.current.get(camera.id) ?? 0;
      const approaching = previous === undefined || distance <= previous + 3;
      if (approaching && distance <= 100 && level < 2) { alertLevelRef.current.set(camera.id, 2); playCameraAlert(camera.weightControl && truckMode ? "Через 100 метров весогабаритный контроль" : "Через 100 метров камера"); }
      else if (approaching && distance <= 300 && level < 1) { const violations = spokenViolations(camera); alertLevelRef.current.set(camera.id, 1); playCameraAlert(camera.weightControl && truckMode ? `Через 300 метров ${camera.weightControl.controlType === "СПВК" ? "стационарный пункт" : "автоматический пункт"} весогабаритного контроля` : `Через 300 метров камера${violations ? ` фиксации: ${violations}` : ""}`); }
      previousDistanceRef.current.set(camera.id, distance);
    });
    for (const [id] of alertLevelRef.current) if (!candidates.some(item => item.camera.id === id && item.distance <= 900)) { alertLevelRef.current.delete(id); previousDistanceRef.current.delete(id); }
    setLocationMessage(`Геолокация работает · точность около ${Math.round(accuracy)} м`);
  }, [allCameras, playCameraAlert, showUserLocation, spokenViolations, truckMode, updateCameraGuidance]);

  const findMyLocation = () => {
    reachMetrikaGoal("my_location", { surface: "region", region: regionName });
    if (!navigator.geolocation) return setLocationMessage("Геолокация не поддерживается браузером.");
    setLocationMessage("Определяем местоположение…");
    navigator.geolocation.getCurrentPosition(position => { void showUserLocation(position.coords.latitude, position.coords.longitude, position.coords.accuracy); setLocationMessage(`Ваше местоположение · точность около ${Math.round(position.coords.accuracy)} м`); }, () => setLocationMessage("Разрешите сайту доступ к местоположению."), { enableHighAccuracy: true, timeout: 15000, maximumAge: 5000 });
  };

  const toggleCameraWarnings = async () => {
    if (warningActive) {
      if (locationWatchRef.current !== null) navigator.geolocation.clearWatch(locationWatchRef.current);
      locationWatchRef.current = null; clearCameraGuidance(); setWarningActive(false); setNearestWarning(null); setLocationMessage("Предупреждения остановлены."); return;
    }
    if (!navigator.geolocation) return setLocationMessage("Геолокация не поддерживается браузером.");
    reachMetrikaGoal("camera_alerts", { surface: "region", region: regionName });
    if ("Notification" in window && Notification.permission === "default") void Notification.requestPermission();
    alertLevelRef.current.clear(); previousDistanceRef.current.clear(); setWarningActive(true); setLocationMessage("Предупреждения включены. Не закрывайте страницу.");
    let firstPosition = true;
    locationWatchRef.current = navigator.geolocation.watchPosition(position => { handleTrackedPosition(position, firstPosition); firstPosition = false; }, () => { clearCameraGuidance(); setLocationMessage("Не удаётся получать местоположение. Проверьте разрешение GPS."); setWarningActive(false); }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 3000 });
  };

  useEffect(() => {
    if (!mapReady || autoDriveStartedRef.current) return;
    const url = new URL(window.location.href), mode = url.searchParams.get("drive");
    if (mode !== "locate" && mode !== "warning") return;
    autoDriveStartedRef.current = true; url.searchParams.delete("drive"); window.history.replaceState({}, "", url.pathname + url.search + url.hash);
    const timer = window.setTimeout(() => { if (mode === "locate") findMyLocation(); else void toggleCameraWarnings(); }, 0);
    return () => window.clearTimeout(timer);
    // The one-time action intentionally runs only after the map is ready.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mapReady]);

  useEffect(() => {
    if (!mapReady || !mapRef.current || !markersRef.current) return;
    const renderMarkers = async () => {
      const { default: L } = await import("leaflet");
      const layer = markersRef.current;
      if (!layer) return;
      layer.clearLayers();
      markerByIdRef.current.clear();
      if (selectedCameraType === "mobile") {
        const colors = ["#7c3aed", "#2563eb", "#0891b2", "#059669", "#ca8a04", "#ea580c", "#dc2626", "#be185d"];
        filteredMobileRoutes.forEach((route, routeIndex) => {
          const color = colors[routeIndex % colors.length];
          route.segments.forEach((segment) => {
            const popup = `<div class="mobile-route-popup"><span>Мобильный комплекс на автомобиле</span><strong>${escapeHtml(route.name)}</strong><b>${escapeHtml(segment.name)}</b><p>${escapeHtml(segment.schedule)}</p><p><em>Фиксирует:</em> ${escapeHtml(segment.violations.join(", "))}</p><small>Автомобиль может находиться на любом участке опубликованного маршрута.</small></div>`;
            const routeLayer = segment.geometry === "polyline"
              ? L.polyline(segment.coordinates, { color, weight: 5, opacity: .86, dashArray: "10 7", lineCap: "round" })
              : L.polygon(segment.coordinates, { color, weight: 3, opacity: .86, fillColor: color, fillOpacity: .16 });
            routeLayer
              .bindPopup(popup, { closeButton: true, autoClose: true })
              .addTo(layer);
          });
        });
        return;
      }
      filteredCameras.forEach((camera) => {
        const primaryVisual = violationVisual(camera.violations[0] ?? "");
        const isWeightControl = truckMode && Boolean(camera.weightControl);
        const icon = L.divIcon({
          className: "roadcam-marker-wrap",
          html: `<span class="roadcam-marker ${isWeightControl ? "weight-control" : camera.cameraType === "portable" ? "portable" : camera.cameraType === "dummy" ? "dummy" : camera.cameraType === "unspecified" ? "unspecified" : ""} violation-${primaryVisual.key}" title="${escapeHtml(isWeightControl ? `${camera.weightControl?.controlType}: весогабаритный контроль` : camera.cameraType === "dummy" ? "Муляж камеры" : primaryVisual.label)}"><span>${isWeightControl ? '<b class="truck-marker-symbol">ГР</b>' : primaryVisual.icon}</span>${!isWeightControl && camera.violations.length > 1 ? `<b class="marker-violation-count">+${camera.violations.length - 1}</b>` : ""}</span>`,
          iconSize: [44, 46], iconAnchor: [17, 38], popupAnchor: [0, -36],
        });
        const popup = L.DomUtil.create("div", "camera-popup");
        const sourceBadge = camera.sourceKind === "official-current" ? '<span class="camera-source-badge source-official">В актуальном перечне ГИБДД</span>' : camera.sourceKind === "official-previous" ? '<span class="camera-source-badge source-previous">Нет в актуальном перечне</span>' : camera.sourceKind === "community" ? '<span class="camera-source-badge source-community">Добавлено пользователем</span>' : "";
        popup.innerHTML = `${isWeightControl ? `<span class="weight-control-badge">${camera.weightControl?.controlType} · весогабаритный контроль</span>` : ""}<span class="popup-camera-type ${camera.cameraType === "dummy" ? "dummy" : ""}">${cameraTypeLabel(camera)}</span>${sourceBadge}${camera.verification === "pending" ? '<span class="verification-badge">Данные требуют проверки</span>' : ''}${camera.cameraCodes?.length ? `<span class="camera-code-line">${camera.cameraCodes.length > 1 ? "Комплексы" : "Комплекс"}: ${camera.cameraCodes.map(escapeHtml).join(", ")}</span>` : ''}${typeof camera.speedLimit === "number" ? `<span class="speed-limit-inline"><b>${camera.speedLimit}</b>${typeof camera.truckSpeedLimit === "number" ? ` / ${camera.truckSpeedLimit} груз.` : ""} км/ч</span>` : ''}<strong>${escapeHtml(camera.address)}</strong>${isWeightControl ? `<small class="weight-source">Проверено: ${escapeHtml(camera.weightControl?.lastVerified ?? "")}</small>` : ""}<span class="popup-fixes">${camera.cameraType === "dummy" ? "Статус объекта:" : "Фиксирует нарушения:"}</span><div class="popup-violation-list">${camera.violations.map((violation) => violationChipHtml(violation)).join("")}</div>`;
        const detailsButton = L.DomUtil.create("button", "camera-popup-details", popup);
        detailsButton.type = "button";
        detailsButton.textContent = "Дополнительная информация";
        detailsButton.setAttribute("aria-label", `Открыть дополнительную информацию: ${camera.address}`);
        L.DomEvent.on(detailsButton, "click", (event) => {
          L.DomEvent.preventDefault(event);
          L.DomEvent.stopPropagation(event);
          openCameraDetails(camera);
        });
        const marker = L.marker([camera.lat, camera.lng], { icon })
          .bindPopup(popup, { closeButton: true, autoClose: true, closeOnClick: true })
          .addTo(layer);
        markerByIdRef.current.set(camera.id, marker);
      });
    };
    void renderMarkers();
  }, [filteredCameras, filteredMobileRoutes, mapReady, openCameraDetails, selectedCameraType, truckMode]);

  useEffect(() => {
    if (!mapReady || !mapRef.current || allCameras.length === 0) return;
    const urlId = Number(new URLSearchParams(window.location.search).get("camera"));
    const requestedId = pendingFocusCameraIdRef.current ?? (Number.isFinite(urlId) && urlId > 0 ? urlId : null);
    if (requestedId === null || handledFocusCameraIdRef.current === requestedId) return;
    const camera = allCameras.find((item) => item.id === requestedId);
    if (!camera) return;

    handledFocusCameraIdRef.current = requestedId;
    pendingFocusCameraIdRef.current = null;
    setQuery("");
    setSelectedViolation("Все нарушения");
    setSelectedCameraType("all");
    setSelectedSpeedLimit("all");
    setListOpen(true);
    openCameraDetails(camera);

    const focus = () => {
      const map = mapRef.current;
      if (!map) return;
      map.invalidateSize();
      map.setView([camera.lat, camera.lng], 17, { animate: false });
      markerByIdRef.current.get(camera.id)?.openPopup();
    };
    focus();
    const first = window.setTimeout(focus, 100);
    const second = window.setTimeout(focus, 450);
    return () => { window.clearTimeout(first); window.clearTimeout(second); };
  }, [allCameras, mapReady, openCameraDetails]);

  const openCameraPreview = (camera: Camera) => {
    setSelectedCamera(null);
    mapRef.current?.flyTo([camera.lat, camera.lng], 15, { duration: 0.8 });
    markerByIdRef.current.get(camera.id)?.openPopup();
  };

  const openMobileRoute = (route: MobileRoute) => {
    const coordinates = route.segments.flatMap((segment) => segment.coordinates);
    if (coordinates.length) mapRef.current?.fitBounds(coordinates, { padding: [42, 42], maxZoom: 15 });
  };

  useEffect(() => {
    if (!selectedCamera) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSelectedCamera(null);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [selectedCamera]);

  useEffect(() => {
    if (!supportOpen) return;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSupportOpen(false);
    };
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, [supportOpen]);

  useEffect(() => {
    const map = mapRef.current;
    if (!cameraPickMode || !map) return;
    const pick = (event: LeafletMouseEvent) => {
      setDraftPoint({ lat: event.latlng.lat, lng: event.latlng.lng });
      setCameraPickMode(false);
      setAddCameraOpen(true);
    };
    map.on("click", pick);
    return () => { map.off("click", pick); };
  }, [cameraPickMode]);

  const nearbyCameras = useMemo(() => !draftPoint ? [] : allCameras
    .map((camera) => ({ camera, distance: distanceMeters(draftPoint.lat, draftPoint.lng, camera.lat, camera.lng) }))
    .filter((item) => item.distance <= 150)
    .sort((a, b) => a.distance - b.distance)
    .slice(0, 3), [allCameras, draftPoint]);

  const useCurrentLocation = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(({ coords }) => {
      setDraftPoint({ lat: coords.latitude, lng: coords.longitude });
      mapRef.current?.flyTo([coords.latitude, coords.longitude], 17);
    });
  };

  const submitNewCamera = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!draftPoint || selectedAddViolations.length === 0) return setAddCameraStatus("error");
    const form = event.currentTarget;
    const data = new FormData(form);
    data.set("violations", selectedAddViolations.join(", "));
    data.set("kind", "camera-add");
    data.set("captcha", String(data.get("addCameraCaptcha") ?? ""));
    data.set("region", regionName);
    data.set("coordinates", `${draftPoint.lat.toFixed(6)}, ${draftPoint.lng.toFixed(6)}`);
    data.set("possibleDuplicates", nearbyCameras.map(({ camera, distance }) => `${camera.id}: ${camera.address} (${Math.round(distance)} м)`).join("; "));
    setAddCameraStatus("sending");
    try {
      const response = await fetch("/api/feedback", { method: "POST", body: data });
      const result = await response.json() as { requestId?: string; error?: string };
      if (!response.ok) throw new Error(result.error || "submit failed");
      setAddCameraRequestId(result.requestId ?? "");
      setAddCameraStatus("sent");
      reachMetrikaGoal("add_camera_submit", { region: regionName });
      form.reset(); setAddCameraFileName(""); setSelectedAddViolations([]); setAddViolationPickerOpen(false);
    } catch { setAddCameraStatus("error"); }
  };

  const sendContribution = async (form: HTMLFormElement, kind: "camera-photo" | "camera-report") => {
    const data = new FormData(form);
    const captchaField = kind === "camera-photo" ? "photoCaptcha" : "reportCaptcha";
    if (data.get(captchaField) !== "11") {
      if (kind === "camera-photo") setPhotoStatus("captcha"); else setReportStatus("captcha");
      return;
    }
    data.set("kind", kind);
    data.set("captcha", String(data.get(captchaField) ?? ""));
    data.set("region", regionName);
    data.set("cameraId", String(selectedCamera?.id ?? ""));
    data.set("cameraAddress", selectedCamera?.address ?? "");
    data.set("coordinates", selectedCamera ? `${selectedCamera.lat.toFixed(6)}, ${selectedCamera.lng.toFixed(6)}` : "");
    if (kind === "camera-photo") setPhotoStatus("sending"); else setReportStatus("sending");
    try {
      const response = await fetch("/api/feedback", { method: "POST", body: data });
      const result = await response.json() as { error?: string };
      if (!response.ok) throw new Error(result.error || "submit failed");
      form.reset();
      if (kind === "camera-photo") { setPhotoFileName(""); setPhotoStatus("sent"); }
      else { setReportFileName(""); setReportStatus("sent"); }
    } catch {
      if (kind === "camera-photo") setPhotoStatus("error"); else setReportStatus("error");
    }
  };

  const submitPhoto = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    void sendContribution(event.currentTarget, "camera-photo");
  };

  const submitReport = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    void sendContribution(event.currentTarget, "camera-report");
  };

  return (
    <main className="app-shell">
      <header className="topbar">
        <Link className="brand" href="/" aria-label="Где камера — главная">
          <span className="brand-mark" aria-hidden="true"><span /></span>
          <span className="brand-name">Где <span>камера</span></span>
        </Link>
        <nav className="nav" aria-label="Основная навигация">
          <button className="nav-active">Карта камер</button><Link href="/spravochnik">Справочник</Link><Link href="/obzhalovanie">Обжаловать штраф</Link><button type="button" onClick={() => { reachMetrikaGoal("support_click", { surface: "navigation" }); setSupportOpen(true); }}>Поддержать проект</button>
        </nav>
        <Link className="header-guide-button" href="/spravochnik" aria-label="Справочник водителя"><span aria-hidden="true">?</span></Link>
        <Link className="header-appeal-button" href="/obzhalovanie" aria-label="Обжаловать штраф"><span aria-hidden="true">⚖</span><b>Обжаловать</b></Link>
        <button className="support-button" type="button" onClick={() => { reachMetrikaGoal("support_click", { surface: "header" }); setSupportOpen(true); }} aria-label="Поддержать проект"><span className="support-heart-icon" aria-hidden="true">♥</span> Поддержать</button>
        <Link className="region-button" href="/" aria-label="Выбрать регион"><span className="location-dot" /> {regionName} <span className="chevron">⌄</span></Link>
      </header>

      <section className="map-stage">
        <div ref={mapElement} className="map-canvas" aria-label={`Карта камер: ${regionName}`} />
        {showSeoHeading && <div className="map-heading">
          <RegionBreadcrumbs regionName={regionName} />
          <span className="eyebrow">{regionName}</span>
          <h1 className="map-seo-heading">{`Камеры ГИБДД в ${regionLocative(regionName)}`}</h1>
        </div>}
        <div className={`driving-controls ${warningActive ? "warning-active" : ""}`} aria-label="Помощник водителя">
          {!warningActive && <button type="button" onClick={findMyLocation}><span aria-hidden="true">⌖</span><b>Моё местоположение</b></button>}
          <button type="button" className={warningActive ? "warning-on" : ""} onClick={() => void toggleCameraWarnings()} aria-label={warningActive ? "Остановить предупреждения о камерах" : "Предупреждать о камерах"}><span aria-hidden="true">{warningActive ? "■" : "◉"}</span><b>{warningActive ? (nearestWarning ? `Камера через ${Math.round(nearestWarning.distance)} м` : "Предупреждения включены") : "Предупреждать о камерах"}</b></button>
          {!warningActive && locationMessage && <div className="driving-status" role="status"><b>Местоположение</b><span>{locationMessage}</span></div>}
        </div>

        <aside className={`control-panel ${listOpen ? "" : "panel-minimized"} ${filtersOpen ? "filters-open" : ""}`}>
          <div className="panel-header">
            <div className="panel-summary"><span className="panel-label">Найдено на карте:</span><strong>{selectedCameraType === "mobile" ? filteredMobileRoutes.length : filteredCameras.length} <small>{selectedCameraType === "mobile" ? `маршрутов · ${filteredMobileRoutes.reduce((sum, route) => sum + route.segments.length, 0)} участков` : `из ${allCameras.length}`}</small></strong></div>
            <button
              className="icon-button panel-collapse-button"
              type="button"
              onClick={() => {
                if (listOpen) setFiltersOpen(false);
                setListOpen((value) => !value);
              }}
              aria-expanded={listOpen}
              aria-label={listOpen ? "Свернуть настройки карты" : "Развернуть настройки карты"}
              title={listOpen ? "Свернуть настройки" : "Развернуть настройки"}
            >
              <span aria-hidden="true">{listOpen ? "−" : "☰"}</span>
              <b>{listOpen ? "Свернуть" : "Настройки"}</b>
            </button>
          </div>
          {listOpen && <>
            <label className="search-field">
              <span aria-hidden="true" />
              <input value={query} onChange={(event) => { const value=event.target.value; setQuery(value); if(value.trim().length===3) reachMetrikaGoal("camera_search", { surface: "region", region: regionName }); }} placeholder="Найти улицу или населённый пункт" />
              {query && <button onClick={() => setQuery("")} aria-label="Очистить поиск">×</button>}
            </label>
            <div className="vehicle-mode" aria-label="Выбор типа автомобиля">
              <button className={!truckMode ? "selected" : ""} onClick={() => selectVehicleMode(false)}><span aria-hidden="true">🚗</span><b>Легковой</b></button>
              <button className={truckMode ? "selected truck" : ""} onClick={() => selectVehicleMode(true)}><span aria-hidden="true">🚛</span><b>Грузовой</b></button>
            </div>
            <button type="button" className={`filter-toggle ${filtersOpen ? "is-open" : ""}`} onClick={() => setFiltersOpen((value) => !value)}>
              <span className="filter-icon">≡</span>
              <span className="filter-toggle-copy"><b>{selectedViolation === "Все нарушения" ? "Фильтр по нарушениям" : selectedViolation}</b><span className="filter-toggle-icons" aria-hidden="true">
                {(selectedViolation === "Все нарушения" ? ["Превышение скорости", "Нарушение правил применения ремней безопасности", "Проезд на запрещающий сигнал светофора", "Использование телефона водителем"] : [selectedViolation]).map((violation) => { const visual=violationVisual(violation); return <i className={`violation-${visual.key}`} key={violation} dangerouslySetInnerHTML={{__html:visual.icon}}/>; })}
              </span></span>
              <span className="filter-count">{selectedViolation === "Все нарушения" ? allViolations.length : 1}</span>
            </button>
            {filtersOpen && <div className="filter-menu">
              <button type="button" className={`filter-violation-option ${selectedViolation === "Все нарушения" ? "selected" : ""}`} onClick={() => { setSelectedViolation("Все нарушения"); setFiltersOpen(false); }}><span className="filter-option-all" aria-hidden="true">✦</span><b>Все нарушения</b></button>
              {availableViolationGroups.map((group) => <section className="filter-violation-group" key={group.id}>
                <h3>{group.title}</h3>
                {group.items.map((item) => (
                  <button type="button" key={item} className={`filter-violation-option ${selectedViolation === item ? "selected" : ""}`} onClick={() => { setSelectedViolation(item); setFiltersOpen(false); }}>{(() => { const visual=violationVisual(item); return <><span className={`filter-option-icon violation-${visual.key}`} aria-hidden="true" dangerouslySetInnerHTML={{__html:visual.icon}}/><b>{item}</b></>; })()}</button>
                ))}
              </section>)}
            </div>}
            <div className="camera-type-filter" aria-label="Фильтр по типу комплекса">
              <button className={selectedCameraType === "all" ? "selected" : ""} onClick={() => setSelectedCameraType("all")}>Все <span>{allCameras.length}</span></button>
              <button className={selectedCameraType === "stationary" ? "selected" : ""} onClick={() => setSelectedCameraType("stationary")}>Стационарные <span>{cameraTypeCounts.stationary}</span></button>
              <button className={selectedCameraType === "portable" ? "selected" : ""} onClick={() => setSelectedCameraType("portable")}>Передвижные <span>{cameraTypeCounts.portable}</span></button>
              {mobileRoutes.length > 0 && <button className={selectedCameraType === "mobile" ? "selected mobile-selected" : ""} onClick={() => setSelectedCameraType("mobile")}>Мобильные <span>{cameraTypeCounts.mobile}</span></button>}
              <button className={selectedCameraType === "dummy" ? "selected" : ""} onClick={() => setSelectedCameraType("dummy")}>Муляжи <span>{cameraTypeCounts.dummy}</span></button>
              <button className={selectedCameraType === "unspecified" ? "selected" : ""} onClick={() => setSelectedCameraType("unspecified")}>Тип не указан <span>{cameraTypeCounts.unspecified}</span></button>
            </div>
            {availableSpeedLimits.length > 0 && selectedCameraType !== "mobile" && <div className="speed-limit-filter" aria-label="Фильтр по ограничению скорости">
              <span>Ограничение скорости</span>
              <div>
                <button className={selectedSpeedLimit === "all" ? "selected" : ""} onClick={() => setSelectedSpeedLimit("all")}>Все</button>
                {availableSpeedLimits.map((limit) => <button key={limit} className={selectedSpeedLimit === limit ? "selected" : ""} onClick={() => setSelectedSpeedLimit(limit)}><b>{limit}</b></button>)}
                <button className={selectedSpeedLimit === "unknown" ? "selected unknown" : "unknown"} onClick={() => setSelectedSpeedLimit("unknown")}>Без данных</button>
              </div>
            </div>}
            <div className="camera-list">
              {selectedCameraType === "mobile" ? filteredMobileRoutes.map((route) => (
                <button className="camera-card mobile-route-card" key={route.id} onClick={() => openMobileRoute(route)}>
                  <span className="mobile-car-icon" aria-hidden="true">🚙</span>
                  <span className="camera-card-copy"><strong>{route.name}</strong><span>{route.segments.length} {route.segments.length === 1 ? "участок" : "участков"} · {route.segments[0]?.schedule}</span></span>
                  <span className="card-arrow">›</span>
                </button>
              )) : filteredCameras.slice(0, 40).map((camera) => (
                // Ref access happens only after the user clicks the card.
                // eslint-disable-next-line react-hooks/refs
                <button className="camera-card" key={camera.id} onClick={() => openCameraPreview(camera)}>
                  <span className="camera-card-pin" aria-hidden="true" />
                  <span className="camera-card-copy"><strong>{camera.address}</strong>{typeof camera.speedLimit === "number" && <span className="speed-limit-inline"><b>{camera.speedLimit}</b> км/ч</span>}<span className="violation-chips">{camera.violations.slice(0, 4).map((violation) => { const visual = violationVisual(violation); return <i className={`violation-chip violation-${visual.key}`} title={violation} key={violation}><b dangerouslySetInnerHTML={{ __html: visual.icon }} />{visual.label}</i>; })}{camera.violations.length > 4 && <i className="more-violations">+{camera.violations.length - 4}</i>}</span></span>
                  <span className="card-arrow">›</span>
                </button>
              ))}
              {(selectedCameraType === "mobile" ? filteredMobileRoutes.length === 0 : filteredCameras.length === 0) && <div className="empty-state">По вашему запросу данных не найдено</div>}
            </div>
          </>}
        </aside>
        <button className={`add-camera-button ${listOpen ? "panel-open" : "panel-closed"}`} type="button" onClick={() => { reachMetrikaGoal("add_camera_open", { region: regionName }); setAddCameraStatus("idle"); setAddCameraOpen(true); }}><span aria-hidden="true">＋</span> Добавить камеру</button>
        {cameraPickMode && <div className="camera-pick-banner"><b>Нажмите на точное место камеры</b><span>Карту можно приблизить и передвинуть</span><button type="button" onClick={() => { setCameraPickMode(false); setAddCameraOpen(true); }}>Отмена</button></div>}
        <div className="map-legend"><span><i className="legend-pin" /> Стационарная</span><span><i className="legend-pin portable" /> Передвижная</span>{mobileRoutes.length > 0 && <span><i className="legend-mobile" /> Мобильный маршрут</span>}<span><i className="legend-pin dummy" /> Муляж</span><span><i className="legend-pin unspecified" /> Тип не указан</span><span className="source-note">Данные: {sourceDate}</span></div>
      </section>

      {addCameraOpen && <div className="add-camera-backdrop" role="presentation" onPointerDown={(event) => { if (event.currentTarget === event.target) setAddCameraOpen(false); }}>
        <section className="add-camera-dialog" role="dialog" aria-modal="true" aria-labelledby="add-camera-title">
          <button className="support-close" type="button" onClick={() => setAddCameraOpen(false)} aria-label="Закрыть">×</button>
          <header><span>＋</span><div><small>Помогите актуализировать карту</small><h2 id="add-camera-title">Добавить новую камеру</h2></div></header>
          {addCameraStatus === "sent" ? <div className="add-camera-success"><span>✓</span><h3>Заявка принята</h3><p>Номер: <b>CAM-{addCameraRequestId}</b></p><small>Камера появится на карте только после проверки модератором и сопоставления с официальными сведениями.</small><button type="button" onClick={() => { setAddCameraOpen(false); setDraftPoint(null); }}>Закрыть</button></div> : <form onSubmit={submitNewCamera}>
            <input className="form-trap" name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" />
            <div className="location-choice"><div><b>Место камеры</b><span>{draftPoint ? `${draftPoint.lat.toFixed(6)}, ${draftPoint.lng.toFixed(6)}` : "Координаты ещё не выбраны"}</span></div><button type="button" onClick={() => { setAddCameraOpen(false); setCameraPickMode(true); }}>Указать на карте</button><button type="button" onClick={useCurrentLocation}>Моё место</button></div>
            {nearbyCameras.length > 0 && <div className="duplicate-warning"><b>В радиусе 150 м уже есть камеры</b>{nearbyCameras.map(({ camera, distance }) => <span key={camera.id}>{Math.round(distance)} м — {camera.address}</span>)}<small>Продолжайте, только если это другой комплекс.</small></div>}
            <div className="add-camera-grid">
              <label>Адрес или ориентир<input name="cameraAddress" required placeholder="Улица, дом, перекрёсток или км дороги" maxLength={500} /></label>
              <label>Тип камеры<select name="cameraType" required defaultValue=""><option value="" disabled>Выберите тип</option><option>Стационарная</option><option>Передвижная</option><option>Мобильная на автомобиле</option><option>Муляж</option><option>Не знаю</option></select></label>
              <label>Номер комплекса <em>необязательно</em><input name="cameraCode" placeholder="Например, PM3722" maxLength={120} /></label>
              <label>Ограничение скорости <em>необязательно</em><input name="speedLimit" inputMode="numeric" placeholder="Например, 60" maxLength={3} /></label>
              <fieldset className="wide violation-picker">
                <legend>Какие нарушения фиксирует</legend>
                <button className={`violation-picker-trigger ${addViolationPickerOpen ? "is-open" : ""}`} type="button" onClick={() => setAddViolationPickerOpen((value) => !value)} aria-expanded={addViolationPickerOpen}>
                  <span>{selectedAddViolations.length ? `Выбрано: ${selectedAddViolations.length}` : "Выберите одно или несколько нарушений"}</span><b aria-hidden="true">⌄</b>
                </button>
                {selectedAddViolations.length > 0 && <div className="violation-picker-selected">{selectedAddViolations.map((item) => <button type="button" key={item} onClick={() => setSelectedAddViolations((values) => values.filter((value) => value !== item))}>{item}<span aria-hidden="true">×</span></button>)}</div>}
                {addViolationPickerOpen && <div className="violation-picker-menu">
                  {VIOLATION_GROUPS.map((group) => <section key={group.id}>
                    <h3>{group.title}</h3>
                    <div>{group.items.map((item) => <label key={item}>
                      <input type="checkbox" name="violations" value={item} checked={selectedAddViolations.includes(item)} onChange={(event) => setSelectedAddViolations((values) => event.target.checked ? [...values, item] : values.filter((value) => value !== item))} />
                      <span>{item}</span>
                    </label>)}</div>
                  </section>)}
                  <button className="violation-picker-done" type="button" onClick={() => setAddViolationPickerOpen(false)}>Готово</button>
                </div>}
                <small>Частые варианты находятся вверху. Можно отметить несколько пунктов.</small>
              </fieldset>
              <label>Направление контроля <em>необязательно</em><input name="direction" placeholder="В центр, из города, обе стороны" maxLength={300} /></label>
              <label>Когда заметили <em>необязательно</em><input name="observedAt" type="date" /></label>
              <label className="wide">Комментарий <em>необязательно</em><textarea name="description" placeholder="Опишите расположение и другие важные детали" maxLength={1000} /></label>
            </div>
            <label className="compact-upload add-camera-upload"><input name="attachment" type="file" accept="image/jpeg,image/png,image/webp,application/pdf" onChange={(event) => setAddCameraFileName(event.target.files?.[0]?.name ?? "")} /><span>📎 {addCameraFileName || "Фото камеры или постановления"}</span><small>JPG, PNG, WebP или PDF · до 10 МБ</small></label>
            <p className="personal-data-warning">Перед отправкой постановления закройте Ф.И.О., госномер автомобиля, адрес и номер документа. Вложение не публикуется автоматически.</p>
            <label className="add-camera-email">Email для уточнения <em>необязательно</em><input name="email" type="email" placeholder="name@example.ru" /></label>
            <label className="add-camera-consent"><input type="checkbox" required /><span>Я подтверждаю достоверность сведений и право передать приложенные материалы для проверки и публикации.</span></label>
            <label className="captcha-row"><span>Проверка: 7 + 4 =</span><input name="addCameraCaptcha" inputMode="numeric" required aria-label="Ответ на проверочный вопрос" /><small>защита от роботов</small></label>
            {addCameraStatus === "error" && <p className="form-error">Проверьте координаты, обязательные поля и ответ 11. Если всё заполнено, попробуйте немного позже.</p>}
            <button className="primary-submit" type="submit" disabled={!draftPoint || addCameraStatus === "sending"}>{addCameraStatus === "sending" ? "Отправляем…" : "Отправить на проверку"}</button>
          </form>}
        </section>
      </div>}

      {supportOpen && <div className="support-backdrop" role="presentation" onPointerDown={(event) => {
        if (event.currentTarget === event.target) setSupportOpen(false);
      }}>
        <section className="support-dialog" role="dialog" aria-modal="true" aria-labelledby="support-title">
          <button className="support-close" type="button" onClick={() => setSupportOpen(false)} aria-label="Закрыть">×</button>
          <span className="support-heart" aria-hidden="true">♥</span>
          <h2 id="support-title">Поддержать «Где камера»</h2>
          <p>Сервис бесплатный. Поддержка помогает оплачивать сервер, трафик, резервные копии и обновление базы камер.</p>
          <div className="support-amounts">
            {[100, 300, 500].map((amount) => <a key={amount} href={supportLink(amount)} target="_blank" rel="noopener noreferrer" onClick={() => { reachMetrikaGoal("support_click", { surface: "amount", amount }); setSupportOpen(false); }}>{amount} ₽</a>)}
            <a href={supportLink("other")} target="_blank" rel="noopener noreferrer" onClick={() => { reachMetrikaGoal("support_click", { surface: "amount", amount: "other" }); setSupportOpen(false); }}>Другая</a>
          </div>
          <small>Безопасный перевод на странице CloudTips (CloudPayments). Сайт «Где камера» не получает данные банковской карты.</small>
        </section>
      </div>}

      {selectedCamera && <div className="camera-drawer-backdrop" role="presentation" onPointerDown={(event) => {
        if (event.currentTarget === event.target) setSelectedCamera(null);
      }}>
        <section className="camera-drawer" role="dialog" aria-modal="true" aria-labelledby="camera-title">
          <div className="drawer-handle" aria-hidden="true" />
          <header className="drawer-header">
            <div>
              <span className="camera-passport-label">Паспорт камеры · № {selectedCamera.id}</span>
              <h2 id="camera-title">{selectedCamera.address}</h2>
              <p>{cameraTypeLabel(selectedCamera)}{typeof selectedCamera.speedLimit === "number" ? ` · ограничение ${selectedCamera.speedLimit} км/ч${typeof selectedCamera.truckSpeedLimit === "number" ? `, для грузовых ${selectedCamera.truckSpeedLimit} км/ч` : ""}` : ""} · {selectedCamera.lat.toFixed(5)}, {selectedCamera.lng.toFixed(5)}{selectedCamera.schedule ? ` · ${selectedCamera.schedule}` : ""}</p>
              {selectedCamera.cameraCodes?.length && <p className="drawer-source">{selectedCamera.cameraCodes.length > 1 ? "Комплексы" : "Комплекс"}: {selectedCamera.cameraCodes.join(", ")}</p>}
              {selectedCamera.cameraModel && <p className="drawer-source">Модель: {selectedCamera.cameraModel}</p>}
              {selectedCamera.sourceKind === "official-current" && <p className="drawer-data-origin origin-official">✓ Камера присутствует в актуальном официальном перечне Госавтоинспекции.</p>}
              {selectedCamera.sourceKind === "official-previous" && <div className="drawer-data-origin origin-unlisted"><b>В актуальном официальном перечне не найдена</b><span>Камера была в предыдущих официальных данных и оставлена на карте как действующая. Если постановление вынесено этой камерой, зафиксируйте отсутствие сведений и проверьте основания для обжалования.</span><Link href="/obzhalovanie">Как зафиксировать и обжаловать →</Link></div>}
              {selectedCamera.sourceKind === "community" && <div className="drawer-data-origin origin-community"><b>Добавлено пользователем</b><span>Местоположение проверено модератором, но камера не подтверждена актуальным официальным перечнем Госавтоинспекции.</span><Link href="/obzhalovanie">Проверить основания для обжалования →</Link></div>}
              {selectedCamera.verification === "pending" && <p className="drawer-verification">Данные требуют проверки по официальному региональному перечню.</p>}
              {selectedCamera.operator && <p className="drawer-source">Оператор: {selectedCamera.operator}</p>}
              {selectedCamera.article && <p className="drawer-source">Статья КоАП РФ: {selectedCamera.article}{selectedCamera.violationCodes?.length ? ` · коды из источника: ${selectedCamera.violationCodes.join(", ")}` : ""}</p>}
              {(selectedCamera.sourceName || sourceName) && <p className="drawer-source">Источник: {(selectedCamera.sourceUrl || sourceUrl) ? <a href={selectedCamera.sourceUrl ?? sourceUrl} target="_blank" rel="noreferrer">{selectedCamera.sourceName ?? sourceName ?? "открытые данные"}</a> : (selectedCamera.sourceName ?? sourceName ?? "открытые данные")}</p>}
            </div>
            <button className="drawer-close" onClick={() => setSelectedCamera(null)} aria-label="Закрыть карточку камеры">×</button>
          </header>

          <div className="passport-violations">
            <span>Фиксирует:</span>
            <div>{selectedCamera.violations.map((violation) => { const visual = violationVisual(violation); return <i className={`violation-chip violation-${visual.key}`} title={violation} key={violation}><b dangerouslySetInnerHTML={{ __html: visual.icon }} />{visual.label}</i>; })}</div>
          </div>

          {regionCode && (() => { const status = cameraStatuses[`${regionCode}:${selectedCamera.id}`] ?? { working: 0, missing: 0, total: 0, status: "uncertain" as const }; return <section className={`camera-status-panel status-${status.status}`} aria-label="Актуальность камеры">
            <div className="camera-status-heading"><div><span>Актуальность камеры</span><strong>{status.status === "working" ? "По сообщениям, камера работает" : status.status === "missing" ? "Возможно, камеры уже нет" : "Пока недостаточно подтверждений"}</strong></div><small>{status.total ? `Всего отметок: ${status.total}` : "Будьте первым, кто подтвердит состояние"}</small></div>
            <div className="camera-status-buttons"><button type="button" disabled={statusSending} onClick={() => void voteCameraStatus("working")}><b>✓</b><span>Камера работает<small>{status.working} подтверждений</small></span></button><button type="button" disabled={statusSending} onClick={() => void voteCameraStatus("missing")}><b>×</b><span>Камеры нет<small>{status.missing} сообщений</small></span></button></div>
            {statusMessage && <p>{statusMessage}</p>}{status.moderatorNote && <p className="moderator-status-note">Комментарий модератора: {status.moderatorNote}</p>}
          </section>; })()}

          {selectedCamera.directions && selectedCamera.directions.length > 1 && <div className="camera-directions"><span>Направления:</span><div>{selectedCamera.directions.map((direction) => <p key={direction}>{direction}</p>)}</div></div>}

          <nav className="passport-actions" aria-label="Разделы паспорта камеры">
            <button className={activeSection === "photo" ? "active" : ""} onClick={() => setActiveSection("photo")}><b>📷</b><span>Фото<small>Вид камеры</small></span></button>
            <button className={activeSection === "history" ? "active" : ""} onClick={() => setActiveSection("history")}><b>🕒</b><span>История<small>Изменения</small></span></button>
            <button className={activeSection === "route" ? "active" : ""} onClick={() => setActiveSection("route")}><b>📍</b><span>Маршрут<small>Навигатор</small></span></button>
            <button className={activeSection === "report" ? "active" : ""} onClick={() => setActiveSection("report")}><b>📝</b><span>Ошибка<small>Сообщить</small></span></button>
          </nav>

          <div className="passport-content">
            {activeSection === "photo" && <div className="passport-grid">
              <div className="photo-area">
                <div className="empty-photo"><span>📷</span><strong>Фотографий пока нет</strong><p>Помогите другим водителям узнать камеру и место её установки.</p></div>
                <div className="privacy-note"><b>Перед публикацией</b><span>Мы скроем лица и номера автомобилей, проверим соответствие фотографии выбранной камере.</span></div>
              </div>
              <form className="contribution-form" onSubmit={submitPhoto}>
                <input className="form-trap" name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" />
                <div className="form-heading"><div><span>Добавить материал</span><h3>Загрузить фото камеры</h3></div><i>На модерацию</i></div>
                {photoStatus === "sent" ? <div className="success-message"><b>✓ Фото принято</b><p>Оно появится в карточке только после проверки модератором. Это защищает проект от рекламы и неподходящих материалов.</p><button type="button" onClick={() => setPhotoStatus("idle")}>Добавить ещё</button></div> : <>
                  <label className="upload-box"><input name="photo" type="file" accept="image/jpeg,image/png,image/webp" required onChange={(event) => setPhotoFileName(event.target.files?.[0]?.name ?? "")} /><span>＋</span><b>{photoFileName || "Выбрать фотографию"}</b><small>JPG, PNG или WebP · до 10 МБ</small></label>
                  <label className="field-label">Комментарий фотографа<textarea name="comment" placeholder="Например: камера установлена после перекрёстка, направлена в центр" maxLength={500} /></label>
                  <label className="field-label">Email для ответа <em>необязательно</em><input name="email" type="email" placeholder="name@example.ru" /></label>
                  <label className="captcha-row"><span>Проверка: 7 + 4 =</span><input name="photoCaptcha" inputMode="numeric" aria-label="Ответ на проверочный вопрос" /><small>защита от роботов</small></label>
                  {photoStatus === "captcha" && <p className="form-error">Введите правильный ответ на проверочный вопрос.</p>}
                  {photoStatus === "error" && <p className="form-error">Не удалось отправить фото. Попробуйте ещё раз немного позже.</p>}
                  <button className="primary-submit" type="submit" disabled={photoStatus === "sending"}>{photoStatus === "sending" ? "Отправляем…" : "Отправить на проверку"}</button>
                  <p className="form-consent">Отправляя фото, пользователь подтверждает право на публикацию и согласие с правилами проекта.</p>
                </>}
              </form>
            </div>}

            {activeSection === "history" && <div className="history-layout">
              <div className="history-summary"><span className="status-badge">● Данные актуальны</span><h3>История карточки</h3><p>Здесь видно происхождение сведений и каждое подтверждённое изменение.</p></div>
              <ol className="history-timeline">
                <li><time>06.08.2026</time><div><b>Карточка проверена</b><p>Координаты и перечень фиксируемых нарушений подтверждены по исходному реестру.</p><small>Модератор «Где камера»</small></div></li>
                <li><time>{sourceDate}</time><div><b>Камера добавлена на карту</b><p>Импортирована из открытого перечня комплексов региона «{regionName}».</p><small>Открытые данные</small></div></li>
              </ol>
            </div>}

            {activeSection === "route" && <div className="route-layout">
              <div className="route-copy"><span className="route-icon">📍</span><div><h3>Построить маршрут к камере</h3><p>Откройте выбранный навигатор. Точкой назначения станут координаты комплекса, а начальная точка определится на вашем устройстве.</p></div></div>
              <div className="route-destination"><span>Точка назначения</span><b>{selectedCamera.address}</b><small>{selectedCamera.lat.toFixed(6)}, {selectedCamera.lng.toFixed(6)}</small></div>
              <div className="navigator-buttons">
                <a href={`https://yandex.ru/maps/?rtext=~${selectedCamera.lat},${selectedCamera.lng}&rtt=auto`} target="_blank" rel="noreferrer"><b>Я</b><span>Яндекс Карты<small>Открыть маршрут</small></span><i>↗</i></a>
                <a href={`https://www.google.com/maps/dir/?api=1&destination=${selectedCamera.lat},${selectedCamera.lng}`} target="_blank" rel="noreferrer"><b>G</b><span>Google Maps<small>Открыть маршрут</small></span><i>↗</i></a>
              </div>
              <p className="route-warning">Маршрут предназначен для безопасной навигации и проверки расположения объекта. Соблюдайте ПДД независимо от наличия камер.</p>
            </div>}

            {activeSection === "report" && <div className="report-layout">
              <div className="report-intro"><span>📝</span><h3>Что изменилось?</h3><p>Сообщите, если камера демонтирована, перенесена, неверно указаны координаты или виды нарушений.</p><ul><li>Сообщение не публикуется сразу</li><li>Модератор сопоставит данные</li><li>В историю попадёт только подтверждённое изменение</li></ul></div>
              <form className="contribution-form report-form" onSubmit={submitReport}>
                <input className="form-trap" name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" />
                {reportStatus === "sent" ? <div className="success-message"><b>✓ Сообщение принято</b><p>Спасибо. Мы проверим информацию, а подтверждённое изменение отразим в истории карточки.</p><button type="button" onClick={() => setReportStatus("idle")}>Сообщить ещё</button></div> : <>
                  <label className="field-label">Тип проблемы<select name="type" required defaultValue=""><option value="" disabled>Выберите вариант</option><option>Камера демонтирована</option><option>Камера перенесена</option><option>Неверные координаты</option><option>Неверные виды нарушений</option><option>Другая ошибка</option></select></label>
                  <label className="field-label">Описание<textarea name="description" required placeholder="Опишите, что именно нужно исправить" maxLength={1000} /></label>
                  <label className="compact-upload"><input name="attachment" type="file" accept="image/*,.pdf" onChange={(event) => setReportFileName(event.target.files?.[0]?.name ?? "")} /><span>📎 {reportFileName || "Прикрепить фото или PDF"}</span><small>до 10 МБ</small></label>
                  <label className="field-label">Email для уточнения <em>необязательно</em><input name="email" type="email" placeholder="name@example.ru" /></label>
                  <label className="captcha-row"><span>Проверка: 7 + 4 =</span><input name="reportCaptcha" inputMode="numeric" aria-label="Ответ на проверочный вопрос" /><small>защита от роботов</small></label>
                  {reportStatus === "captcha" && <p className="form-error">Введите правильный ответ на проверочный вопрос.</p>}
                  {reportStatus === "error" && <p className="form-error">Не удалось отправить сообщение. Попробуйте ещё раз немного позже.</p>}
                  <button className="primary-submit" type="submit" disabled={reportStatus === "sending"}>{reportStatus === "sending" ? "Отправляем…" : "Отправить сообщение"}</button>
                </>}
              </form>
            </div>}
          </div>
        </section>
      </div>}
    </main>
  );
}

function escapeHtml(value: string) {
  return value.replace(/[&<>"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[character] ?? character);
}

function violationVisual(violation: string) {
  return violationVisuals.find((item) => item.match.test(violation)) ?? { key: "other", icon: '<svg class="rc-icon" viewBox="0 0 100 100"><text class="icon-text large" x="50" y="70" text-anchor="middle">!</text></svg>', label: "Другое нарушение" };
}

function violationChipHtml(violation: string) {
  const visual = violationVisual(violation);
  return `<span class="popup-violation violation-${visual.key}" title="${escapeHtml(violation)}"><b>${visual.icon}</b>${escapeHtml(visual.label)}</span>`;
}

function distanceMeters(lat1: number, lng1: number, lat2: number, lng2: number) {
  const radians = (value: number) => value * Math.PI / 180;
  const dLat = radians(lat2 - lat1);
  const dLng = radians(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(radians(lat1)) * Math.cos(radians(lat2)) * Math.sin(dLng / 2) ** 2;
  return 6_371_000 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
