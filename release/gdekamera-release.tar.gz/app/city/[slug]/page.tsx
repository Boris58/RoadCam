import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { camerasForCity, cities } from "../../camera-catalog";
import { jsonLd } from "../../seo";

type PageProps = { params: Promise<{ slug: string }> };
export function generateStaticParams() { return cities.map(({ slug }) => ({ slug })); }
const locatives: Record<string, string> = { moskva:"Москве", "sankt-peterburg":"Санкт-Петербурге", penza:"Пензе", kazan:"Казани", ufa:"Уфе", novosibirsk:"Новосибирске", ekaterinburg:"Екатеринбурге", "nizhniy-novgorod":"Нижнем Новгороде", krasnoyarsk:"Красноярске", chelyabinsk:"Челябинске", samara:"Самаре", omsk:"Омске", "rostov-na-donu":"Ростове-на-Дону", krasnodar:"Краснодаре", voronezh:"Воронеже", perm:"Перми", volgograd:"Волгограде", saratov:"Саратове", tyumen:"Тюмени", tula:"Туле" };

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params; const city = cities.find((item) => item.slug === slug); if (!city) return { title: "Город не найден" };
  const locative=locatives[city.slug]??city.name; const count = camerasForCity(city).length; const title = `Камеры ГИБДД в ${locative} — карта и адреса`;
  const description = `${count} камер фотовидеофиксации в ${locative}: адреса, координаты и виды нарушений. Найдите камеру и откройте её на карте.`;
  return { title, description, alternates: { canonical: `/city/${slug}` }, openGraph: { type: "website", locale: "ru_RU", url: `/city/${slug}`, title, description }, twitter: { card: "summary", title, description } };
}

export default async function CityPage({ params }: PageProps) {
  const { slug } = await params; const city = cities.find((item) => item.slug === slug); if (!city) notFound(); const cameras = camerasForCity(city); const locative=locatives[city.slug]??city.name;
  const schema = { "@context": "https://schema.org", "@type": "ItemList", name: `Камеры ГИБДД в ${locative}`, numberOfItems: cameras.length, itemListElement: cameras.slice(0, 50).map((camera, index) => ({ "@type": "ListItem", position: index + 1, url: `https://xn--80aahefb7ar1b.xn--p1ai/camera/${camera.c}/${camera.i}`, name: camera.a })) };
  return <main className="seo-detail-page city-camera-page"><script type="application/ld+json" dangerouslySetInnerHTML={{ __html: jsonLd(schema) }} />
    <header className="legal-topbar"><Link className="brand" href="/"><span className="brand-mark" aria-hidden="true"><span /></span><span className="brand-name">Где <span>камера</span></span></Link><Link href={`/region/${city.regionCode}`}>Открыть карту региона</Link></header>
    <article className="seo-detail-article"><nav className="legal-breadcrumbs"><Link href="/">Главная</Link><span>→</span><Link href={`/region/${city.regionCode}`}>Регион</Link><span>→</span><span>{city.name}</span></nav>
      <span className="legal-kicker">Адреса и координаты</span><h1>Камеры ГИБДД в {locative}</h1><p className="seo-detail-lead">На странице найдено {cameras.length.toLocaleString("ru-RU")} камер фотовидеофиксации. Выберите адрес, чтобы посмотреть нарушения и открыть точку на карте.</p>
      <Link className="open-camera-map" href={`/region/${city.regionCode}`}><span>⌖</span><div><b>Открыть все камеры на карте</b><small>{city.name}: стационарные, передвижные и другие комплексы</small></div><strong>→</strong></Link>
      <section><h2>Адреса камер в {locative}</h2>{cameras.length ? <div className="city-camera-list">{cameras.slice(0, 300).map((camera) => <Link key={camera.i} href={`/camera/${camera.c}/${camera.i}`}><span>№ {camera.i}</span><div><b>{camera.a}</b><small>{camera.v.slice(0, 3).join(" · ")}</small></div><strong>→</strong></Link>)}</div> : <p>В опубликованном перечне не удалось выделить камеры с названием города в адресе. Откройте карту региона для полного списка.</p>}</section>
      <p className="seo-data-note">Список формируется из опубликованной базы сайта. Дата и состав официального перечня могут изменяться.</p>
    </article>
  </main>;
}
