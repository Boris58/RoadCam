"use client";

import { useEffect, useState } from "react";
import RoadCamApp, { type Camera, type MobileRoute } from "./roadcam-app";

type RegionData = {
  code: string;
  name: string;
  sourceDate: string;
  sourceFile: string;
  sourceUrl: string;
  mapCenter: [number, number];
  cameras: Camera[];
};

export default function OfficialRegionApp({ code, focusCameraId }: { code: string; focusCameraId?: number }) {
  const [region, setRegion] = useState<RegionData | null>(null);
  const [mobileRoutes, setMobileRoutes] = useState<MobileRoute[]>([]);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let active = true;
    Promise.all([
      fetch(`/official-regions/${code}.json`).then((response) => {
        if (!response.ok) throw new Error("load failed");
        return response.json() as Promise<RegionData>;
      }),
      fetch(`/official-mobile/${code}.json`).then((response) => response.ok ? response.json() as Promise<{ routes: MobileRoute[] }> : null),
    ])
      .then(([data, mobile]) => { if (active) { setRegion(data); setMobileRoutes(mobile?.routes ?? []); } })
      .catch(() => { if (active) setFailed(true); });
    return () => { active = false; };
  }, [code]);

  if (failed) return <main className="region-load-state"><p>Не удалось загрузить данные. Обновите страницу немного позже.</p></main>;
  if (!region) return <main className="region-load-state"><div className="region-loader" /><p>Загружаем официальный перечень камер…</p></main>;

  return <RoadCamApp
    cameras={region.cameras}
    mobileRoutes={mobileRoutes}
    regionName={region.name}
    mapCenter={region.mapCenter}
    mapZoom={6}
    sourceDate={region.sourceDate}
    sourceName="Официальный перечень Госавтоинспекции"
    sourceUrl={region.sourceUrl}
    showSeoHeading={false}
    focusCameraId={focusCameraId}
    regionCode={code}
  />;
}
